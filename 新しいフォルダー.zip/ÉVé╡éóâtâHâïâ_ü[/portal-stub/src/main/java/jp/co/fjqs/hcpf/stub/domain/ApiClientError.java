package jp.co.fjqs.hcpf.stub.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ApiClientError {

    @JsonProperty("api_name")
    private String apiName;

    @JsonProperty("reason_cd")
    private String reasonCd;

    @JsonProperty("reason_name")
    private String reasonName;

    @JsonProperty("status_cd")
    private String statusCd;

    /**
     * @return apiName
     */
    public String getApiName() {
        return apiName;
    }

    /**
     * @param apiName セットする apiName
     */
    public void setApiName(String apiName) {
        this.apiName = apiName;
    }

    /**
     * @return reasonCd
     */
    public String getReasonCd() {
        return reasonCd;
    }

    /**
     * @param reasonCd セットする reasonCd
     */
    public void setReasonCd(String reasonCd) {
        this.reasonCd = reasonCd;
    }

    /**
     * @return reasonName
     */
    public String getReasonName() {
        return reasonName;
    }

    /**
     * @param reasonName セットする reasonName
     */
    public void setReasonName(String reasonName) {
        this.reasonName = reasonName;
    }

    /**
     * @return statusCd
     */
    public String getStatusCd() {
        return statusCd;
    }

    /**
     * @param statusCd セットする statusCd
     */
    public void setStatusCd(String statusCd) {
        this.statusCd = statusCd;
    }

}
