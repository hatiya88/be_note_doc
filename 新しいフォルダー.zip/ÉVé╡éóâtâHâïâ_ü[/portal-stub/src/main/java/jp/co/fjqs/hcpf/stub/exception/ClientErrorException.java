package jp.co.fjqs.hcpf.stub.exception;

import jp.co.fjqs.hcpf.stub.domain.ClientErrorInfo;

public class ClientErrorException extends RuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private int statusCode;

    private ClientErrorInfo clientErrorInfo;

    public ClientErrorException(int statusCode, ClientErrorInfo clientErrorInfo) {
        super();
        this.statusCode = statusCode;
        this.clientErrorInfo = clientErrorInfo;
    }

    /**
     * @return statusCode
     */
    public int getStatusCode() {
        return statusCode;
    }

    /**
     * @return clientErrorInfo
     */
    public ClientErrorInfo getClientErrorInfo() {
        return clientErrorInfo;
    }

}
