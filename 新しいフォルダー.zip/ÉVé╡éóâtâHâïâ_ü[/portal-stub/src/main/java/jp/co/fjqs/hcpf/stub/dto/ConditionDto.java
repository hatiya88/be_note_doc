package jp.co.fjqs.hcpf.stub.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ConditionDto {

	@JsonProperty("GUID")
	private String guid;
	
	@JsonProperty("UserID")
	private String userID;
	
	@JsonProperty("TermID")
	private String termID;
	
	@JsonProperty("Smqn")
	private String smqn;
	
	@JsonProperty("RequestTelegram")
	private String requestTelegram;

	public String getGuid() {
		return guid;
	}

	public void setGuid(String guid) {
		this.guid = guid;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getTermID() {
		return termID;
	}

	public void setTermID(String termID) {
		this.termID = termID;
	}

	public String getSmqn() {
		return smqn;
	}

	public void setSmqn(String smqn) {
		this.smqn = smqn;
	}

	public String getRequestTelegram() {
		return requestTelegram;
	}

	public void setRequestTelegram(String requestTelegram) {
		this.requestTelegram = requestTelegram;
	}
	
}
