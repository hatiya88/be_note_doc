package jp.co.fjqs.hcpf.stub;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.util.MimeTypeUtils;

public class AppUtils {
	
	/**
	 * リクエスト情報をコンソール出力します
	 * @param request
	 * @throws IOException
	 */
	public static void systemOutRequestParam(HttpServletRequest request) throws IOException {
		System.out.println("--- PORTAL STUB RECEIVED REQUEST ---");
		System.out.println("[URI]");
		System.out.println(request.getRequestURI());
		System.out.println("[HEADERS]");
		Enumeration<String> headers = request.getHeaderNames();
		while(headers.hasMoreElements()) {
			String hE = headers.nextElement();
			System.out.println(hE + ":" + request.getHeader(hE));
		}
		Map<String, String[]> paramMap = request.getParameterMap();
		System.out.println("[PARAMETERS]");		
		for (Map.Entry<String, String[]> entry : paramMap.entrySet()) {
			String vals = "";
			int len = entry.getValue() != null ? entry.getValue().length : 0;
			if (len > 0) {
				int i = 0;
				for (String val : entry.getValue()) {
					vals += val;
					i++;
					if (i < len) vals += ",";
				}
			}
			System.out.println(entry.getKey() + "=" + vals);
		}
		
		if (!request.getContentType().equals(MimeTypeUtils.APPLICATION_JSON_VALUE))
			return;
			
		System.out.println("[BODY]");
		System.out.println(systemOutRequestBody(request));
		System.out.println("------------------------------------");
	}

    /**
     * リクエストボディのコンソール出力
     * @param request
     * @throws IOException
     */
    public static String systemOutRequestBody(HttpServletRequest request) throws IOException {
    	StringBuilder sb = new StringBuilder();
    	BufferedReader reader = request.getReader();
    	try  {
    		String line;
    		while ((line = reader.readLine()) != null) {
    			sb.append(line).append('\n');
    		}
    	} finally {
    		reader.close();
    	}
    	return sb.toString();
    }
	
}
