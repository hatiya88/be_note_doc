package jp.co.fjqs.hcpf.stub.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class IdwsfRequestCommonDto {

	@JsonProperty("idwsf_request_common")
	private TargetDto targetDto;
	
	@JsonProperty("user")
	private UserDto userDto;
	
	@JsonProperty("terminal")
	private TerminalDto terminalDto;

	public TargetDto getTargetDto() {
		return targetDto;
	}

	public void setTargetDto(TargetDto targetDto) {
		this.targetDto = targetDto;
	}

	public UserDto getUserDto() {
		return userDto;
	}

	public void setUserDto(UserDto userDto) {
		this.userDto = userDto;
	}

	public TerminalDto getTerminalDto() {
		return terminalDto;
	}

	public void setTerminalDto(TerminalDto terminalDto) {
		this.terminalDto = terminalDto;
	}
}
