package jp.co.fjqs.hcpf.stub.controller;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.nio.charset.Charset;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import jp.co.fjqs.hcpf.stub.AppUtils;
import jp.co.fjqs.hcpf.stub.domain.ClientErrorInfo;
import jp.co.fjqs.hcpf.stub.exception.ClientErrorException;
import jp.co.fjqs.hcpf.stub.util.JsonReadUtil;

@RestController
public class CallStubApiController {

	@RequestMapping(value = "/stub/portal/{apiName}", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public String call(@PathVariable("apiName") String apiName, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		try {
			// エラー設定があればClientErrorException
			JsonReadUtil.existsErrorInfo(apiName);

			URL jsonUrl = JsonReadUtil.class.getResource("/response_json/" + apiName + ".json");
			File file = new File(jsonUrl.getFile());
			FileInputStream fis = null;
			try {
				fis = new FileInputStream(file);
				return IOUtils.toString(fis, Charset.forName("UTF-8"));
			} finally {
				IOUtils.closeQuietly(fis);
			}
		} catch (Exception e) {
			System.err.println("!!Error!! GET /stub/portal/" + apiName);
			throw e;
		}
	}

	@ExceptionHandler(ClientErrorException.class)
	@ResponseBody
	public ClientErrorInfo handlerClientErrorException(ClientErrorException e, HttpServletResponse response) {

		response.setStatus(e.getStatusCode());

		return e.getClientErrorInfo();
	}

	@RequestMapping(value = "/stub/portal/{apiName}", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public String callCollaboration(@PathVariable("apiName") String apiName, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		try {
			AppUtils.systemOutRequestParam(request);

			// エラー設定があればClientErrorException
			JsonReadUtil.existsErrorInfo(apiName);

			URL jsonUrl = JsonReadUtil.class.getResource("/response_json/" + apiName + ".json");
			File file = new File(jsonUrl.getFile());
			FileInputStream fis = null;
			try {
				fis = new FileInputStream(file);
				return IOUtils.toString(fis, Charset.forName("UTF-8"));
			} finally {
				IOUtils.closeQuietly(fis);
			}
		} catch (Exception e) {
			System.err.println("!!Error!! POST /stub/portal/" + apiName);
			throw e;
		}
	}
	
	/**
	 * ポータル WebAPI53① ログインユーザでレスポンスを分岐
	 **/
	@RequestMapping(value = "/personal/webapi/portal/**/phr_patient_list", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public String callGetPhrPatientList(@RequestParam(value = "user_id") String user_id, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		return call("phr_patient_list/" + user_id, request, response);
	}

	/**
	 * ポータル WebAPI34 コンシェルジュ配下サービス・グループ一覧取得
	 **/
	@RequestMapping(value = "/personal/webapi/portal/services/SVC000000000011/groups/GRP000000001016/child_service_group_id_list", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public String callChildServiceGroupIdListGX(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return call("child_service_group_id_list/GRP000000001016", request, response);
	}

	@RequestMapping(value = "/personal/webapi/portal/services/SVC000000000011/groups/GRP000000001130/child_service_group_id_list", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public String callChildServiceGroupIdListHX(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return call("child_service_group_id_list/GRP000000001130", request, response);
	}

	/*
	@RequestMapping(value = "/personal/webapi/portal/services/%s/groups/{group_id}/child_service_group_id_list", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public String callChildServiceGroupIdList(@PathVariable("group_id") String group_id, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		return call("child_service_group_id_list/" + group_id, request, response);
	}
	*/

	/**
	 * ポータル WebAPI25 ログインユーザ と 認証用ユーザでレスポンスを分岐
	 **/
	@RequestMapping(value = "/personal/webapi/portal/**/class_authority", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public String callGetClassAuthority(@RequestParam(value = "user_id") String user_id, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		return call("class_authority/" + user_id, request, response);
	}

	/**
	 * ポータル WebAPI1 ログインユーザ と 認証用ユーザでレスポンスを分岐
	 **/
	@RequestMapping(value = "/personal/webapi/portal/**/user_list", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public String callGetUserList(@RequestParam(value = "key") String key,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		byte[] decrypted = decryptBase64(key);
		String strResult = new String(decrypted, "UTF-8");
		String[] userInfos = strResult.split(",");
		return call("user_list/" + userInfos[0], request, response);
	}

	/**
	 * ユーザ情報の復号
	 *
	 * @param base64encodedBytes	暗号データ
	 * @param secretBytes	秘密鍵 (application.properties#portal.param.encrypt.key)
	 * @return	平文データ
	 * @throws UnsupportedEncodingException 
	 */
	private byte[] decryptBase64(String base64encodedBytes) throws Exception {
		byte[] cipherText = Base64.decodeBase64(base64encodedBytes.getBytes("UTF-8"));
		byte[] secretBytes = "12345678901234567890123456789012".getBytes("UTF-8");
		return decrypt(cipherText, secretBytes);
	}

	/**
	 * 復号する
	 *
	 * @param bytes
	 *            cipher text
	 * @param secretBytes
	 *            the secret
	 * @return plain text
	 */
	private byte[] decrypt(byte[] bytes, byte[] secretBytes) throws Exception{

		final int IV_LENGTH = 128 / 8; //16byte
		final int KEY_LENGTH = 256 / 8; //32byte
		
		if (bytes.length < IV_LENGTH + 2) {
			// 少なくともIV + 2は必要
			throw new RuntimeException("Encrypted data is too short. Data should be equal or larger than IV length");
		}
		int BLOCK_LENGTH = 128 / 8;
		if ((bytes.length - (IV_LENGTH + 2)) % BLOCK_LENGTH != 0) {
			throw new RuntimeException("Bad encrypted data length");
		}
		if (secretBytes.length != KEY_LENGTH) {
			throw new RuntimeException("bad secret length");
		}
		try {
			byte[] iv = Arrays.copyOfRange(bytes, 2, IV_LENGTH + 2);
			byte[] cipherText = Arrays.copyOfRange(bytes, IV_LENGTH + 2, bytes.length);
	
			Cipher cipher = createCipher();
	
			SecretKeySpec key = new SecretKeySpec(secretBytes, "AES");
			IvParameterSpec ivSpec = new IvParameterSpec(iv);
			cipher.init(Cipher.DECRYPT_MODE, key, ivSpec);
	
			ByteArrayOutputStream result = new ByteArrayOutputStream();
			result.write(cipher.update(cipherText));
			result.write(cipher.doFinal());
			return result.toByteArray();
		} catch(Exception e) {
			throw e;
		}
	}

	/**
	 * Cipherを作成する
	 * @return Cipher
	 */
	private Cipher createCipher() throws NoSuchPaddingException, NoSuchAlgorithmException {
		return Cipher.getInstance("AES/CBC/PKCS5Padding");
	}

	@RequestMapping(value = "/personal/webapi/portal/**/{apiName}", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public String callGet(@PathVariable("apiName") String apiName, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		return call(apiName, request, response);
	}

	@RequestMapping(value = "/personal/webapi/portal/**/{apiName}", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public String callPost(@PathVariable("apiName") String apiName, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		if (apiName.equals("phr_patient_list")) {
			return callCollaboration("phr_patient_list_by_team_id", request, response);
		}
		return callCollaboration(apiName, request, response);
	}

	/**
	 * システム連携PF API
	 * 診療科2300,4100,4500
	 * @param apiNum
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/systemconnector/CollaborationProvider/{apiNum}", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public String systemConnectorPost(@PathVariable("apiNum") String apiNum, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		try {
			// エラー設定があればClientErrorException
			JsonReadUtil.existsErrorInfo(apiNum);

			URL jsonUrl = JsonReadUtil.class.getResource("/response_json/systemconnector/" + apiNum + ".json");
			File file = new File(jsonUrl.getFile());
			FileInputStream fis = null;
			try {
				fis = new FileInputStream(file);
				return IOUtils.toString(fis, Charset.forName("UTF-8"));
			} finally {
				IOUtils.closeQuietly(fis);
			}
		} catch (Exception e) {
			System.err.println("!!Error!! GET /systemconnector/CollaborationProvider/" + apiNum);
			throw e;
		}
	}

	/**
	 * リクエストボディ取得
	 * 
	 * @param request
	 * @return
	 * @throws IOException
	 */
	@SuppressWarnings("finally")
	private String readRequestBody(HttpServletRequest request) throws IOException {
		StringBuilder sb = new StringBuilder();
		BufferedReader reader = request.getReader();
		try {
			String line;
			while ((line = reader.readLine()) != null) {
				sb.append(line).append('\n');
			}
		} finally {
			reader.close();
			return sb.toString();
		}
	}
	/**
	 * コンシェルジュ API
	 * 病院オプションメタマスタ （apiName = hospital_option）
	 */
	@RequestMapping(value = "/concierge/services/SVC000000000011/groups/GRP000000001016/hospital_option", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public String HospitalOptionGX(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return call("concierge/hospital_option/GRP000000001016", request, response);
	}
	@RequestMapping(value = "/concierge/services/SVC000000000011/groups/GRP000000001130/hospital_option", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public String HospitalOptionHX(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return call("concierge/hospital_option/GRP000000001130", request, response);
	}

	/*
	@RequestMapping(value = "/concierge/services/%s/groups/%s/hospital_option", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public String HospitalOption(@PathVariable("group_id") String group_id, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		return call("concierge/hospital_option/" + group_id, request, response);
	}
	*/

	/**
	 * コンシェルジュ API
	 * @param apiNum
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/concierge/services/{serviceId}/groups/{groupId}/{apiName}", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public String conciergePost(@PathVariable("apiName") String apiName, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		try {
			// エラー設定があればClientErrorException
			JsonReadUtil.existsErrorInfo(apiName);

			URL jsonUrl = JsonReadUtil.class.getResource("/response_json/concierge/" + apiName + ".json");
			File file = new File(jsonUrl.getFile());
			FileInputStream fis = null;
			try {
				fis = new FileInputStream(file);
				return IOUtils.toString(fis, Charset.forName("UTF-8"));
			} finally {
				IOUtils.closeQuietly(fis);
			}
		} catch (Exception e) {
			System.err.println("!!Error!! GET /concierge/" + apiName);
			throw e;
		}
	}

	/**
	 * コンシェルジュ API
	 * 
	 * @param apiNum
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/concierge/rest/**/{apiName}", produces = "application/json;charset=UTF-8")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public String conciergeRest(@PathVariable("apiName") String apiName, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		try {
			// エラー設定があればClientErrorException
			JsonReadUtil.existsErrorInfo(apiName);

			URL jsonUrl = JsonReadUtil.class.getResource("/response_json/concierge/" + apiName + ".json");
			File file = new File(jsonUrl.getFile());
			FileInputStream fis = null;
			try {
				fis = new FileInputStream(file);
				return IOUtils.toString(fis, Charset.forName("UTF-8"));
			} finally {
				IOUtils.closeQuietly(fis);
			}
		} catch (Exception e) {
			System.err.println("!!Error!! GET /concierge/" + apiName);
			throw e;
		}
	}

	/**
	 * コンシェルジュ API
	 * 
	 * @param apiNum
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/concierge/{apiName}", produces = "application/json;charset=UTF-8")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public String conciergeAny(@PathVariable("apiName") String apiName, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		try {
			// エラー設定があればClientErrorException
			JsonReadUtil.existsErrorInfo(apiName);

			URL jsonUrl = JsonReadUtil.class.getResource("/response_json/concierge/" + apiName + ".json");
			File file = new File(jsonUrl.getFile());
			FileInputStream fis = null;
			String json = null;
			try {
				fis = new FileInputStream(file);
				json = IOUtils.toString(fis, Charset.forName("UTF-8"));
			} finally {
				IOUtils.closeQuietly(fis);
			}
			if (apiName.equals("signup_history")) {
				return this.signupHistory(request, json);
			}
			return json;
		} catch (Exception e) {
			System.err.println("!!Error!! GET /concierge/" + apiName);
			throw e;
		}
	}

	/**
	 * TOTP WebAPI （二要素認証（MFA））
	 * 
	 * 必要に応じて以下を張り替える
	 * 200:HttpStatus.OK
	 * 404:HttpStatus.NOT_FOUND
	 * 500:HttpStatus.INTERNAL_SERVER_ERROR
	 **/
	@RequestMapping(value = "/totp/webapi/v1/{apiName}", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	@ResponseBody
	public String callGetTotp(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return call("totp/otp-wa04", request, response);
	}

	/**
	 * TOTP WebAPI （二要素認証（MFA））
	 * 
	 * 必要に応じて以下を張り替える
	 * 200:HttpStatus.OK
	 * 404:HttpStatus.NOT_FOUND
	 * 500:HttpStatus.INTERNAL_SERVER_ERROR
	 **/
	@RequestMapping(value = "/totp/webapi/v1/{apiName}/**", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	@ResponseBody
	public String callPostTotp(@PathVariable("apiName") String apiName, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		if (apiName.contains("create")) return call("totp/otp-wa01", request, response);
//		if (apiName.contains("totp-authentication")) return call("totp/otp-wa02", request, response);
		if (apiName.contains("revoke")) return call("totp/otp-wa03", request, response);
		throw new Exception();
	}

	/**
	 * 統計情報の変換用の変換処理を行います。
	 * 
	 * @param request リクエスト
	 * @param json JSON
	 * @return 変換後の JSON
	 */
	private String signupHistory(HttpServletRequest request, String json) {
		String groupId = request.getParameter("group_id");
		String endTime = request.getParameter("end_time");
		long today = Long.parseLong(endTime) - (1000 * 60 * 60 * 24); // 当日の0時に登録されたことにする
		return json.replace("GRP000000001016", groupId).replace("1515033719883", String.valueOf(today));
	}
}
