package jp.co.fjqs.hcpf.stub.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TargetDto {

	@JsonProperty("group_id")
	private String groupId;
	
	@JsonProperty("local_id")
	private String localId;
	
	@JsonProperty("portal_group_ids")
	private String portalGroupIds;

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getLocalId() {
		return localId;
	}

	public void setLocalId(String localId) {
		this.localId = localId;
	}

	public String getPortalGroupIds() {
		return portalGroupIds;
	}

	public void setPortalGroupIds(String portalGroupIds) {
		this.portalGroupIds = portalGroupIds;
	}
}
