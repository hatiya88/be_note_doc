package jp.co.fjqs.hcpf.stub.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ClientErrorInfo {

    @JsonProperty("reason_cd")
    private String reasonCd;

    @JsonProperty("reason_name")
    private String reasonName;

    /**
     * @return reasonCd
     */
    public String getReasonCd() {
        return reasonCd;
    }

    /**
     * @param reasonCd セットする reasonCd
     */
    public void setReasonCd(String reasonCd) {
        this.reasonCd = reasonCd;
    }

    /**
     * @return reasonName
     */
    public String getReasonName() {
        return reasonName;
    }

    /**
     * @param reasonName セットする reasonName
     */
    public void setReasonName(String reasonName) {
        this.reasonName = reasonName;
    }

}
