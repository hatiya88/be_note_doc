package jp.co.fjqs.hcpf.stub.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class IdwsfRequestBodyDto {

	@JsonProperty("condition")
	private ConditionDto conditionDto;

	public ConditionDto getConditionDto() {
		return conditionDto;
	}

	public void setConditionDto(ConditionDto conditionDto) {
		this.conditionDto = conditionDto;
	}
}
