package jp.co.fjqs.hcpf.stub.domain;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ApiErrorInfo {
    @JsonProperty("api_client_error")
    private List<ApiClientError> apiClientError;

    /**
     * @return apiClientError
     */
    public List<ApiClientError> getApiClientError() {
        return apiClientError;
    }

    /**
     * @param apiClientError セットする apiClientError
     */
    public void setApiClientError(List<ApiClientError> apiClientError) {
        this.apiClientError = apiClientError;
    }

}
