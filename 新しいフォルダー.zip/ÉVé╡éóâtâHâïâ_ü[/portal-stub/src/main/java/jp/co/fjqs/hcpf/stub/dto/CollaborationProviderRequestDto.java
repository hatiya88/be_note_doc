package jp.co.fjqs.hcpf.stub.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CollaborationProviderRequestDto {

	@JsonProperty("idwsf_request_common")
	private IdwsfRequestCommonDto idwsfRequestCommonDto;
	
	@JsonProperty("idwsf_request_body")
	private IdwsfRequestBodyDto idwsfRequestBodyDto;

	public IdwsfRequestCommonDto getIdwsfRequestCommonDto() {
		return idwsfRequestCommonDto;
	}

	public void setIdwsfRequestCommonDto(IdwsfRequestCommonDto idwsfRequestCommonDto) {
		this.idwsfRequestCommonDto = idwsfRequestCommonDto;
	}

	public IdwsfRequestBodyDto getIdwsfRequestBodyDto() {
		return idwsfRequestBodyDto;
	}

	public void setIdwsfRequestBodyDto(IdwsfRequestBodyDto idwsfRequestBodyDto) {
		this.idwsfRequestBodyDto = idwsfRequestBodyDto;
	}
}
