package jp.co.fjqs.hcpf.stub.util;

import java.io.File;
import java.io.IOException;
import java.net.URL;

import jp.co.fjqs.hcpf.stub.domain.ApiClientError;
import jp.co.fjqs.hcpf.stub.domain.ApiErrorInfo;
import jp.co.fjqs.hcpf.stub.domain.ClientErrorInfo;
import jp.co.fjqs.hcpf.stub.exception.ClientErrorException;

import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonReadUtil {

    public static void existsErrorInfo(String apiName) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            URL jsonUrl = JsonReadUtil.class.getResource("/response_json/api_error_info.json");
            File file = new File(jsonUrl.getFile());
            ApiErrorInfo errorInfo = mapper.readValue(file, ApiErrorInfo.class);
            if (errorInfo != null && !CollectionUtils.isEmpty(errorInfo.getApiClientError())) {
                for (ApiClientError apiClientError : errorInfo.getApiClientError()) {
                    if (apiName.equals(apiClientError.getApiName())
                        && !StringUtils.isEmpty(apiClientError.getStatusCd())) {
                        ClientErrorInfo clientErrorInfo = new ClientErrorInfo();
                        clientErrorInfo.setReasonCd(apiClientError.getReasonCd());
                        clientErrorInfo.setReasonName(apiClientError.getReasonName());
                        throw new ClientErrorException(Integer.valueOf(apiClientError.getStatusCd()), clientErrorInfo);
                    }
                }
            }
        } catch (IOException e) {
            //NOP
        }
    }

}
