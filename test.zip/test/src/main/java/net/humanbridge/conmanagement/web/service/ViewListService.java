package net.humanbridge.conmanagement.web.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.fjqs.f2.springboot.logger.basic.F2Logger;
import net.humanbridge.conmanagement.util.MiscUtils;
import net.humanbridge.conmanagement.util.ThreadLocalUtils;
import net.humanbridge.conmanagement.web.dbflute.exbhv.MTemplateBhv;
import net.humanbridge.conmanagement.web.dbflute.exentity.MTemplate;
import net.humanbridge.conmanagement.web.dto.ViewListDto;
import net.humanbridge.conmanagement.web.dto.UserSessionDto.HospitalConfig;
import net.humanbridge.conmanagement.web.exception.ServiceException;

/**
 * コンテンツ一覧取得サービス
 */
@Service
public class ViewListService {

	private static final F2Logger logger = F2Logger.getLogger();

	@Autowired
	private MTemplateBhv mTemplateBhv;

	/** 共通マスタ登録画面用URL */
	private static final String TEMPLATE_URL = "template";

	/**
	 * テンプレートマスタから機能一覧を取得します。
	 * 
	 * @param serviceId
	 * @return 取得結果一覧
	 * @throws ServiceException サービス一覧取得エラー
	 */
	public List<ViewListDto> search(String serviceId) throws ServiceException {
		List<ViewListDto> resultList = new ArrayList<>();
		
		/** 汎用マスタ取得 */
		HospitalConfig hospitalConfig = ThreadLocalUtils.getHospitalConfig();
		
		/** テンプレートマスタ取得 */
		List<MTemplate> mTemplateList = mTemplateBhv.findByServiceIdPrefixSearch(serviceId);
		logger.log("ICMG0020", mTemplateList.size()); 						// テンプレートマスタ一覧情報取得結果（全件数）

		/** 取得結果リストの作成 **/
		for (MTemplate mTemplate : mTemplateList) {
			// 使用不可サービスIDはスキップ
			if (!hospitalConfig.isAuthorizedSerivce(mTemplate.getServiceId())) 
				continue;
			try {
				F2Logger.getLogger(this.getClass()).debug("テンプレートマスタ情報詳細：" + mTemplate);
				ViewListDto viewDto = new ViewListDto();
				viewDto.setTemplateSeq(mTemplate.getTemplateSeq());				// テンプレートSeq
				viewDto.setServiceId(mTemplate.getServiceId());					// サービスID
				viewDto.setGroupId(mTemplate.getGroupId());						// マスタメンテナンス対象サービスの病院グループID
				viewDto.setContentsLabel(mTemplate.getName());					// 画面表示名称
				viewDto.setContentsUrl(replaceViewUrl(mTemplate.getUrl()));	    // 画面URL
				resultList.add(viewDto);
			} catch (IllegalStateException ignore) {
				logger.log("WCMG9002", ThreadLocalUtils.contractGroupIdDefaultEmpty(), String.format(
						"不正なマスタ定義のため無視します。エラー原因：%s | テンプレートマスタ情報詳細：%s", ignore.getMessage(), mTemplate.toString()));
			}
		}

		return resultList;
	}

	/**
	 * URLを置換します
	 * テンプレートマスタのURLが空白のとき、共通マスタ登録画面用URLに変換する
	 *
	 * @param viewUrl 画面URL
	 * 
	 * @return 変換済みURL
	 */
	String replaceViewUrl(String viewUrl) {
		if (MiscUtils.isEmpty(viewUrl)) {
			return TEMPLATE_URL;
		} else {
			return viewUrl;
		}
	}
}
