package net.humanbridge.conmanagement.web.service.analytics.graph;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.humanbridge.conmanagement.constant.AnalyticsConstants;
import net.humanbridge.conmanagement.web.dbflute.exbhv.TDataAnalyticsSumCntMtCallBhv;
import net.humanbridge.conmanagement.web.dbflute.exentity.TDataAnalyticsSumCntMtCall;

/**
 * 診察状況お知らせ(MediTrend)のグラフデータ作成クラス
 * @author xonogawa.koichi
 *
 */
@Service("Graph_" + AnalyticsConstants.MT_CALL)
public class MtCallMakeGraphData extends AbstractMakeGraphData {

	@Autowired
	TDataAnalyticsSumCntMtCallBhv tDataAnalyticsSumCntMtCallBhv;

	/**
	 * 診察状況お知らせ(MediTrend)のグラフデータ作成
	 * @param searchTargetGroupId
	 * @param fromDate
	 * @param toDate
	 * @param unit
	 * @param deptCode
	 * @return
	 */
	public List<Map<String, Long>> getGraphData(String searchTargetGroupId, Date fromDate, Date toDate, String unit, String deptCode, int fetchAmount) {
		// データ取得し、集計単位に合わせてグルーピングする
		Map<String, Long> groupByMtCallMap =tDataAnalyticsSumCntMtCallBhv.getTDataAnalyticsSumCntMtCall(searchTargetGroupId, fromDate, toDate, deptCode, unit, fetchAmount);
		List<Map<String, Long>> groupByList = new ArrayList<Map<String, Long>>();
		groupByList.add(groupByMtCallMap);
		return groupByList;
	}
	
	/**
	 * 集計単位でGroupingする
	 * @param tDataAnalyticsSumCntMtCall
	 * @param unit
	 * @return
	 */
	public Map<String, Long> groupingTDataAnalyticsSumCntMtCallData(List<TDataAnalyticsSumCntMtCall> tDataAnalyticsSumCntMtCallList, String unit, Map<String, Long> groupByMtCallMap) {
		Map<String, Long> newGroupByMtCallMap = new LinkedHashMap<String, Long>();
		Map<String, Long> margeGroupByMtCallMap = new LinkedHashMap<String, Long>();

		if (!tDataAnalyticsSumCntMtCallList.isEmpty()) {
			SimpleDateFormat yearMonthFormat = new SimpleDateFormat(getGroupingFormat(unit));
			newGroupByMtCallMap = tDataAnalyticsSumCntMtCallList.stream()
					.collect(Collectors.groupingBy(p -> yearMonthFormat.format(p.getExecuteTime()), Collectors.counting()));
		}
		// 今回取得データからMapへ
		for (String key : newGroupByMtCallMap.keySet()) {
			margeGroupByMtCallMap.put(key, newGroupByMtCallMap.getOrDefault(key, 0L));
		}
		// 前回取得分を加算する
		for (String key : groupByMtCallMap.keySet()) {
			margeGroupByMtCallMap.put(key, groupByMtCallMap.getOrDefault(key, 0L) + newGroupByMtCallMap.getOrDefault(key, 0L));
		}
		return margeGroupByMtCallMap;
	}
}
