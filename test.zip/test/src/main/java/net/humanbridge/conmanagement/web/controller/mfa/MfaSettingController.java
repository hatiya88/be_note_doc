package net.humanbridge.conmanagement.web.controller.mfa;

import static net.humanbridge.conmanagement.constant.AppConstants.SESSION_ATTR_NAME;
import static net.humanbridge.conmanagement.constant.MfaConstants.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import net.humanbridge.conmanagement.web.controller.BaseController;
import net.humanbridge.conmanagement.web.controller.MenuController;
import net.humanbridge.conmanagement.web.dto.UserSessionDto;
import net.humanbridge.conmanagement.web.helper.MessageHelper;
import net.humanbridge.conmanagement.web.model.ServiceModel;
import net.humanbridge.conmanagement.web.service.totp.TotpService;

/**
 * 二要素認証設定画面（SST015）
 */
@Controller
@SessionAttributes(SESSION_ATTR_NAME)
@RequestMapping("/hospitals/{contractGroupId}/mfa-setting")
public class MfaSettingController extends BaseController {

	@Autowired
	private 
	MenuController menuController;

	@Autowired
	private TotpService totpService;

	@Autowired
	private MessageHelper messageHelper;

	/**
	 * 二要素認証設定画面（初期表示）
	 * 秘密鍵登録状況の取得失敗時にメニュー画面へ遷移する
	 * 
	 * @param model  モデル
	 * @param serviceModel  サービスモデル
	 * @param contractGroupId  契約グループID
	 * @param userSessionDto  ユーザーセッション情報
	 * @return 遷移先
	 * 
	 * @throws Exception
	 */
	@RequestMapping(method = RequestMethod.GET)
	public String index(
			Model model,
			ServiceModel serviceModel,
			@PathVariable("contractGroupId") String contractGroupId,
			@ModelAttribute(SESSION_ATTR_NAME)
			UserSessionDto userSessionDto) throws Exception {
		boolean isMfaActive = false;
		try {
			// TOTPサーバに問い合わせて二要素認証の秘密鍵の登録状況を取得する
			isMfaActive = totpService.isActive(userSessionDto);
		} catch (Exception e) {
			// エラーメッセージ出力 + 画面再描画
			messageHelper.setCommonErrorMessage(model, e.getMessage());
			return indexMenu(model, serviceModel, contractGroupId, userSessionDto);
		}
		//二要素認証（有効/無効）を返却（ラジオボタン）
		model.addAttribute(IS_MFA_ACTIVE, isMfaActive);
		return indexHtml();
	}

	/**
	 * 病院ごとのメニュー画面へリダイレクト
	 * @throws Exception 
	 */
	private String indexMenu(Model model, ServiceModel serviceModel, String contractGroupId, UserSessionDto userSessionDto) throws Exception {
		return menuController.index(model, serviceModel, contractGroupId, userSessionDto);
	}

	/**
	 * 二要素認証設定画面（更新ボタン押下後の再描画）
	 * 秘密鍵登録状況の取得失敗時に遷移する画面を分岐するため別メソッドとしている
	 * 
	 * @param model  モデル
	 * @param userSessionDto  ユーザーセッション情報
	 * @return 遷移先
	 * @throws Exception
	 */
	private String redraw(
			Model model,
			@ModelAttribute(SESSION_ATTR_NAME)
			UserSessionDto userSessionDto) throws Exception {
		boolean isMfaActive = false;
		try {
			// TOTPサーバに問い合わせて二要素認証の秘密鍵の登録状況を取得する
			isMfaActive = (totpService.isActive(userSessionDto));
		} catch (Exception e) {
			// エラーメッセージ出力 + 画面再描画
			messageHelper.setCommonErrorMessage(model, e.getMessage());
			return indexHtml();
		}
		//二要素認証（有効/無効）を返却（ラジオボタン）
		model.addAttribute(IS_MFA_ACTIVE, isMfaActive);
		return indexHtml();
	}

	/**
	 * 更新ボタン押下時
	 * 
	 * @param model  モデル
	 * @param userSessionDto  ユーザーセッション情報
	 * @param session
	 * @param request
	 * @return 遷移先
	 * 
	 * @throws Exception
	 */
	@RequestMapping(value = "/upload", method = RequestMethod.POST)
	public String update(Model model,
			@ModelAttribute(SESSION_ATTR_NAME)
			UserSessionDto userSessionDto,
			HttpSession session,
			HttpServletRequest request
			) throws Exception {
		String result =request.getParameter(SELECTIONS_MFA_RADIO);
		if (result.equals(MFA_VALID)){
			String accessKey = "";
			try {
				//TOTPサーバに問い合わせて、「TOTPホーム画面呼び出し」に使用するアクセスキーを生成する
				accessKey = totpService.createKey(userSessionDto, session);
			} catch (Exception e) {
				// エラーメッセージ出力 + 画面再描画
				messageHelper.setCommonErrorMessage(model, e.getMessage());
				return redraw(model, userSessionDto);
			}
			//TOTPホーム画面呼び出し（外部サイト）
			return "redirect:" + totpService.transfer(userSessionDto, accessKey);
		}
		try {
			//登録されている秘密鍵を無効化
			totpService.revokeKey(userSessionDto);
		} catch (Exception e) {
			// エラーメッセージ出力 + 画面再描画
			messageHelper.setCommonErrorMessage(model, e.getMessage());
			return redraw(model, userSessionDto);
		}
		// 更新成功メッセージ出力
		messageHelper.setGuidance(model, "CMG999_I0001");
		return redraw(model, userSessionDto);
	}

	@Override
	public String indexHtml() {
		return "mfa_setting/index";
	}

	@Override
	public String redirectPath() {
		return "./";
	}
}
