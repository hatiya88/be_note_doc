package net.humanbridge.conmanagement.web.service.custom;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import net.humanbridge.conmanagement.excel.cbean.SheetCB;
import net.humanbridge.conmanagement.excel.cbean.OrderBy.DataType;
import net.humanbridge.conmanagement.excel.entity.CellDto;
import net.humanbridge.conmanagement.excel.entity.RowDto;
import net.humanbridge.conmanagement.util.ExcelUtils;
import net.humanbridge.conmanagement.web.dto.UserSessionDto;
import net.humanbridge.conmanagement.web.dto.UserSessionDto.ServiceDto;
import net.humanbridge.conmanagement.web.dto.custom.FreeDto;
import net.humanbridge.conmanagement.web.exception.DownloadException;
import net.humanbridge.conmanagement.web.service.ExcelLoadBhv;


/**
 * 自由表示設定サービス
 */
@Service
public class FreeManageService {

	@Autowired
	private ExcelLoadBhv excelLoadBhv;

	/** マスタメンテテーブル */
	private static final String TABLE_LAYOUT_SECTION = "layout_section";
	private static final String TABLE_SECTION_ITEM = "section_item";

	/**
	 * 自由表示設定データ取得
	 * 
	 * @param userSessionDto
	 * @param serviceDto
	 * @return List<FreeManageDto> 画面表示項目DTO
	 * 
	 * @throws Exception
	 */
	public List<FreeDto> getFreeDtoList(UserSessionDto userSessionDto, ServiceDto serviceDto)
			throws Exception {

    	/** section_itemマスタ取得 */
		List<RowDto> sectionItemList = getSectionItemList(userSessionDto, serviceDto);

		/** 自由表示設定データ作成 */
		List<FreeDto> freeDtoList = new ArrayList<>();
		for (RowDto sectionItem : sectionItemList) {
			// section_itemマスタの項目
			FreeDto freeDto = new FreeDto(sectionItem);
			freeDtoList.add(freeDto);
		}
		return freeDtoList;
	}

	/**
	 * section_itemマスタ取得
	 * 
	 * @param userSessionDto
	 * @param serviceDto
	 * @return
	 * @throws DownloadException
	 * @throws IOException
	 */
	public List<RowDto> getSectionItemList(UserSessionDto userSessionDto, ServiceDto serviceDto)
			throws Exception {
    	// layout_sectionマスタからsection_style=infoのデータを取得
		SheetCB cb = new SheetCB(TABLE_LAYOUT_SECTION);
		cb.query().setEqual("section_style", "info");
		Map<String, SheetCB> conditionMap = new HashMap<>();
		conditionMap.put(cb.getTableName(), cb);
		// section_itemからグループIDが一致するレコード全件取得
		cb = new SheetCB(TABLE_SECTION_ITEM);
		conditionMap.put(cb.getTableName(), cb);
		Map<String, List<RowDto>> sectionMap = excelLoadBhv.selectList(serviceDto, userSessionDto, conditionMap);

		// layout_sectionマスタからsection_style=infoの seq取得
		List<RowDto> layoutSectionList = sectionMap.get(TABLE_LAYOUT_SECTION);
		List<String> seqList = layoutSectionList.stream().map((RowDto row) -> {
			CellDto dto = row.get("seq");
			return dto.getValue();
		}).collect(Collectors.toList());

		// layout_sectionマスタにsection_style=infoが存在しない
		if (seqList.isEmpty()){
			return new ArrayList<RowDto>();
		}

		// section_itemよりlayout_section_seqがinfoのlayout_sectionのseqであるリストを抽出
		List<RowDto> sectionItemList = sectionMap.get(TABLE_SECTION_ITEM);		
		cb = new SheetCB(TABLE_SECTION_ITEM);
		cb.query().setInScope("layout_section_seq", seqList);
		cb.query().addOrderBy_Asc_WithDataType("precedence", DataType.NUMBER);
		sectionItemList = ExcelUtils.extractRowDtoList(sectionItemList, cb);
		
		return sectionItemList;
	}

	/**
	 * layout_sectionマスタのseq取得
	 * 
	 * @param userSessionDto
	 * @param serviceDto
	 * @return
	 * @throws Exception
	 */
	public String getLayoutSectionSeq(UserSessionDto userSessionDto, ServiceDto serviceDto)
			throws Exception {
    	// layout_sectionマスタからsection_style=infoのデータを取得
		SheetCB cb = new SheetCB(TABLE_LAYOUT_SECTION);
		cb.query().setEqual("section_style", "info");
		Map<String, SheetCB> conditionMap = new HashMap<>();
		conditionMap.put(cb.getTableName(), cb);
		Map<String, List<RowDto>> sectionMap = excelLoadBhv.selectList(serviceDto, userSessionDto, conditionMap);

		// layout_sectionからsection_style=infoの seq取得
		List<RowDto> layoutSectionList = sectionMap.get(TABLE_LAYOUT_SECTION);
		List<String> seqList = layoutSectionList.stream().map((RowDto row) -> {
			CellDto dto = row.get("seq");
			return dto.getValue();
		}).collect(Collectors.toList());

		// section_style=infoのデータが存在しない場合は空文字
		return !CollectionUtils.isEmpty(seqList) ? seqList.get(0) : "";
	}
}
