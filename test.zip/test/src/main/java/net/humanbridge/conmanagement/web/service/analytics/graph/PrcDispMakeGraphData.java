package net.humanbridge.conmanagement.web.service.analytics.graph;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.humanbridge.conmanagement.constant.AnalyticsConstants;
import net.humanbridge.conmanagement.web.dbflute.exbhv.TDataAnalyticsSumCntPrcDispBhv;
import net.humanbridge.conmanagement.web.dbflute.exentity.TDataAnalyticsSumCntPrcDisp;

/**
 * 予約表示のグラフデータ作成クラス
 * @author xonogawa.koichi
 *
 */
@Service("Graph_" + AnalyticsConstants.PRC_DISP)
public class PrcDispMakeGraphData extends AbstractMakeGraphData {

	/**
	 * 予約表示のグラフデータ作成クラス
	 */
	@Autowired
	TDataAnalyticsSumCntPrcDispBhv tDataAnalyticsSumCntPrcDispBhv;
	
	/**
	 * 予約表示のグラフデータ作成
	 * @param searchTargetGroupId
	 * @param fromDate
	 * @param toDate
	 * @param unit
	 * @param deptCode
	 * @return
	 */
	public List<Map<String, Long>> getGraphData(String searchTargetGroupId, Date fromDate, Date toDate, String unit, String deptCode, int fetchAmount) {
		// データ取得し、集計単位に合わせてグルーピングする
		Map<String, Long> groupByPrcDispMap = tDataAnalyticsSumCntPrcDispBhv.getTDataAnalyticsSumCntPrcDisp(searchTargetGroupId, fromDate, toDate, unit, fetchAmount);
		List<Map<String, Long>> groupByList = new ArrayList<Map<String, Long>>();
		groupByList.add(groupByPrcDispMap);
		return groupByList;
	}

	/**
	 * 集計単位でGroupingする
	 * @param tDataAnalyticsSumCntPrcDisp
	 * @param unit
	 * @return
	 */
	public Map<String, Long> groupingTDataAnalyticsSumCntPrcDispData(List<TDataAnalyticsSumCntPrcDisp> tDataAnalyticsSumCntPrcDispList, String unit, Map<String, Long> groupByPrcDispMap) {
		Map<String, Long> newGroupByPrcDispMap = new LinkedHashMap<String, Long>();
		Map<String, Long> margeGroupByPrcDispMap = new LinkedHashMap<String, Long>();

		if (!tDataAnalyticsSumCntPrcDispList.isEmpty()) {
			SimpleDateFormat yearMonthFormat = new SimpleDateFormat(getGroupingFormat(unit));
			newGroupByPrcDispMap = tDataAnalyticsSumCntPrcDispList.stream()
					.collect(Collectors.groupingBy(p -> yearMonthFormat.format(p.getExecuteTime()), Collectors.summingLong((q -> q.getCount()))));
		}
		// 今回取得データからMapへ
		for (String key : newGroupByPrcDispMap.keySet()) {
			margeGroupByPrcDispMap.put(key, newGroupByPrcDispMap.getOrDefault(key, 0L));
		}
		// 前回取得分を加算する
		for (String key : groupByPrcDispMap.keySet()) {
			margeGroupByPrcDispMap.put(key, groupByPrcDispMap.getOrDefault(key, 0L) + newGroupByPrcDispMap.getOrDefault(key, 0L));
		}
		return margeGroupByPrcDispMap;
	}
}
