package net.humanbridge.conmanagement.totp.call;

import java.io.IOException;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fujitsu.portal.api.exception.HttpRequestException;
import jp.co.fjqs.f2.springboot.http.HttpResponse;
import lombok.var;
import net.humanbridge.conmanagement.external.exception.TOTPApiCallException;
import net.humanbridge.conmanagement.totp.dto.TotpRequestDto;
import net.humanbridge.conmanagement.totp.mapper.TotpAuthenticationMapper;

/**
 * ユーザ認証（OTP-WA02）呼び出しクラス
 */
@Component
public class TotpAuthenticationAPICall extends BaseTotpApiCall {

	/** ユーザ認証（OTP-WA02）パス */
	@Value("${totp.totp-authentication:/totp/webapi/v1/totp-authentication}")
	private String path;

	/** クライアントID */
	@Value("${totp.client.id}")
	private String clientId;

	/** クライアントシークレット */
	@Value("${totp.client.secret}")
	private String clientSecret;

	// スレッドセーフ
	private ObjectMapper mapper = new ObjectMapper();

	/**
	 * ワンタイムパスワード認証設定が完了しているユーザーの認証を行う（OTP-WA02）
	 * 
	 * @param userId  ユーザID
	 * @param totp  トークンアプリに表示された数字6桁（認証コード）
	 * @return TOTPサーバーからの認証結果
	 * 
	 * @throws JsonProcessingException 
	 * @throws HttpRequestException
	 */
	public Pair<Integer, TotpAuthenticationMapper> call(String userId, int totp) throws JsonProcessingException {
		// 要求パラメータ
		var reqParam = new TotpRequestDto();
		reqParam.setUserId(userId);
		reqParam.setClientId(clientId);
		reqParam.setClientSecret(clientSecret);
		reqParam.setTotp(totp);
		var json = new ObjectMapper().writeValueAsString(reqParam);

		HttpResponse response = callPost(path, json.toString());

		TotpAuthenticationMapper authenticationMapper;
		try {
			authenticationMapper = mapper.readValue(response.responseBody, TotpAuthenticationMapper.class);
		} catch (IOException e) {
			logger.log("ECMG0001", e, "TOTPサーバ", e.getMessage());
			throw new TOTPApiCallException("CMG999_E0001");
		}
		return Pair.of(response.responseCode, authenticationMapper);
	}
}