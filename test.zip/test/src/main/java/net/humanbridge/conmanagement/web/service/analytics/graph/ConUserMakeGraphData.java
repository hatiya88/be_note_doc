package net.humanbridge.conmanagement.web.service.analytics.graph;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.humanbridge.conmanagement.constant.AnalyticsConstants;
import net.humanbridge.conmanagement.web.dbflute.exbhv.TDataAnalyticsSumCntConUserBhv;
import net.humanbridge.conmanagement.web.dbflute.exbhv.TDataAnalyticsSumTotalcntBhv;
import net.humanbridge.conmanagement.web.dbflute.exentity.TDataAnalyticsSumCntConUser;
import net.humanbridge.conmanagement.web.dbflute.exentity.TDataAnalyticsSumTotalcnt;

/**
 * アプリ利用者登録数のグラフ作成クラス
 * @author xonogawa.koichi
 *
 */
@Service("Graph_" + AnalyticsConstants.CON_USER)
public class ConUserMakeGraphData extends AbstractMakeGraphData {

	@Autowired
	TDataAnalyticsSumCntConUserBhv tDataAnalyticsSumCntConUserBhv;

	@Autowired
	TDataAnalyticsSumTotalcntBhv tDataAnalyticsSumTotalcntBhv;

	/**
	 * アプリ利用者登録数のグラフデータ作成
	 * @param searchTargetGroupId
	 * @param fromDate
	 * @param toDate
	 * @param unit
	 * @param deptCode
	 * @return
	 */
	public List<Map<String, Long>> getGraphData(String searchTargetGroupId, Date fromDate, Date toDate, String unit, String deptCode, int fetchAmount) {
		List<Map<String, Long>> groupByList = new ArrayList<Map<String, Long>>();

		/** 利用者登録データ取得 */
		// データ取得し、集計単位に合わせてグルーピングする		
		Map<String, Long> groupByConUserMap =tDataAnalyticsSumCntConUserBhv.getTDataAnalyticsSumCntConUser(searchTargetGroupId, fromDate, toDate, unit, fetchAmount);
		groupByList.add(groupByConUserMap);

		/** 利用者登録累計データ取得 */
		List<TDataAnalyticsSumTotalcnt> tDataAnalyticsSumTotalcntList = tDataAnalyticsSumTotalcntBhv.getTDataAnalyticsSumTotalcnt(searchTargetGroupId, fromDate, toDate, fetchAmount);
		// 累計データ取得
		Map<String, Long> groupByTotalcntMap = groupingTDataAnalyticsSumTotalcntData(tDataAnalyticsSumTotalcntList, unit, fromDate, toDate);
		groupByList.add(groupByTotalcntMap);

		return groupByList;
	}
	
	/**
	 * アプリ利用者登録数データを集計単位でGroupingする
	 * @param tDataAnalyticsSumCntConUser
	 * @param unit
	 * @param groupByConUserMap
	 * @return
	 */
	public Map<String, Long> groupingTDataAnalyticsSumCntConUserData(List<TDataAnalyticsSumCntConUser> tDataAnalyticsSumCntConUserList, String unit, Map<String, Long> groupByConUserMap) {
		Map<String, Long> newGroupByConUserMap = new LinkedHashMap<String, Long>();
		Map<String, Long> margeGroupByConUserMap = new LinkedHashMap<String, Long>();
		
		if (!tDataAnalyticsSumCntConUserList.isEmpty()) {
			SimpleDateFormat yearMonthFormat = new SimpleDateFormat(getGroupingFormat(unit));
			newGroupByConUserMap = tDataAnalyticsSumCntConUserList.stream()
					.collect(Collectors.groupingBy(p -> yearMonthFormat.format(p.getExecuteTime()), Collectors.counting()));
		}
		// 今回取得データからMapへ
		for (String key : newGroupByConUserMap.keySet()) {
			margeGroupByConUserMap.put(key, newGroupByConUserMap.getOrDefault(key, 0L));
		}
		// 前回取得分を加算する
		for (String key : groupByConUserMap.keySet()) {
			margeGroupByConUserMap.put(key, groupByConUserMap.getOrDefault(key, 0L) + newGroupByConUserMap.getOrDefault(key, 0L));
		}
		return margeGroupByConUserMap;
	}
	
	/**
	 * 利用状況累計データを取得
	 * 日にちごとに累計人数が入っているので、日ごとのときは利用者状況累計管理の値そのまま。
	 * 月ごとのときは、その月の末日のレコードの値が累計人数になる。
	 * @param tDataAnalyticsSumTotalcntList
	 * @param unit
	 * @param fromDate
	 * @param toDate
	 * @return
	 */
	public Map<String, Long> groupingTDataAnalyticsSumTotalcntData(List<TDataAnalyticsSumTotalcnt> tDataAnalyticsSumTotalcntList, String unit, Date fromDate, Date toDate) {
		SimpleDateFormat yearMonthFormat = new SimpleDateFormat(getGroupingFormat(unit));
		SimpleDateFormat yearMonthDateFormat = new SimpleDateFormat(getGroupingFormat(AnalyticsConstants.UNIT_DAY));
		Map<String, Long> totalcntMap = new LinkedHashMap<String, Long>();

		if (tDataAnalyticsSumTotalcntList.isEmpty()) {
			return totalcntMap;
		}
			
		switch (unit) {
		case AnalyticsConstants.UNIT_DAY:
			// 日ごとの場合はデータそのまま。日付のフォーマットは行う。
			totalcntMap = tDataAnalyticsSumTotalcntList.stream()
					.collect(Collectors.toMap(
							p -> yearMonthFormat.format(p.getDate()),
							p -> p.getCount()));
			break;

		case AnalyticsConstants.UNIT_MONTH:
			// 月末日のレコードがその月の累計登録者数になるので、月ごとのときは月末のレコードを取得して表示する
			Map<String, Long> dayOfTotalcntMap = new LinkedHashMap<String, Long>();
			// フォーマットした日付(yyyyMMdd)にしてMapに変換する
			dayOfTotalcntMap = tDataAnalyticsSumTotalcntList.stream()
					.collect(Collectors.toMap(
							p -> yearMonthDateFormat.format(p.getDate()),
							p -> p.getCount()));

			// 検索対象期間の年月にそのときの末日の値をセットする。当月は処理日の前日とする。
			Calendar calendarWhileDate = Calendar.getInstance();
			calendarWhileDate.setTime(fromDate);
			while (calendarWhileDate.getTime().before(toDate)) {
				String targetDay = "";
				String key = yearMonthFormat.format(calendarWhileDate.getTime());
				if (key.equals(yearMonthFormat.format(DateTime.now().toDate()))) {
					// 当月は前日を取得する
					Calendar calendarDate = Calendar.getInstance();
					calendarDate.setTime(DateTime.now().toDate());
					calendarDate.add(Calendar.DATE, -1);
					DateTime dateTimeFromDate = new DateTime(calendarDate);
					targetDay =yearMonthDateFormat.format(dateTimeFromDate.toDate());
				} else {
					// 月末を取得する
					DateTime dateTimeFromDate = new DateTime(calendarWhileDate);
					dateTimeFromDate = dateTimeFromDate.dayOfMonth().withMaximumValue();	// 月末
					targetDay =yearMonthDateFormat.format(dateTimeFromDate.toDate());
				}
				Long cntValue = 0L;
				if (dayOfTotalcntMap.containsKey(targetDay)) {
					cntValue = dayOfTotalcntMap.get(targetDay);
				}
				totalcntMap.put(key, cntValue);
				calendarWhileDate.add(Calendar.MONTH, 1);
			}
			break;
		}
		return totalcntMap;
	}
}
