package net.humanbridge.conmanagement.web.service.analytics;

import static net.humanbridge.conmanagement.web.dbflute.exbhv.MDataAnalyticsGrpGeneralBhv.ALLOWED_SERVICE_ID_KEY;
import static net.humanbridge.conmanagement.web.dbflute.exbhv.MDataAnalyticsSvcGeneralBhv.CSV_OUTPUT_PATTERN;
import static net.humanbridge.conmanagement.web.dbflute.exbhv.MDataAnalyticsSvcGeneralBhv.SEARCH_ITEM_DEPT;
import static net.humanbridge.conmanagement.web.dbflute.exbhv.MDataAnalyticsSvcGeneralBhv.SEARCH_ITEM_SUM_UNIT;
import static net.humanbridge.conmanagement.web.dbflute.exbhv.MDataAnalyticsUsrGeneralBhv.CSV_OUTPUT_KEY;
import static net.humanbridge.conmanagement.web.dbflute.exbhv.MDataAnalyticsUsrGeneralBhv.DEPT_CODE_KEY;
import static net.humanbridge.conmanagement.web.dbflute.exbhv.MDataAnalyticsUsrGeneralBhv.PERIOD_END_KEY;
import static net.humanbridge.conmanagement.web.dbflute.exbhv.MDataAnalyticsUsrGeneralBhv.PERIOD_START_KEY;
import static net.humanbridge.conmanagement.web.dbflute.exbhv.MDataAnalyticsUsrGeneralBhv.UNIT_KEY;
import static net.humanbridge.conmanagement.web.dbflute.exbhv.MDataAnalyticsUsrGeneralBhv.UNIT_VALUE;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.tuple.Pair;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;

import jp.co.fjqs.f2.springboot.logger.basic.F2Logger;
import lombok.val;
import net.humanbridge.conmanagement.api.dxo.request.ApiRequestDxo;
import net.humanbridge.conmanagement.constant.AnalyticsConstants;
import net.humanbridge.conmanagement.constant.AppConstants;
import net.humanbridge.conmanagement.systemconnector.call.ApiCall;
import net.humanbridge.conmanagement.util.AppUtils;
import net.humanbridge.conmanagement.web.dbflute.exbhv.MDataAnalyticsCsvPatternBhv;
import net.humanbridge.conmanagement.web.dbflute.exbhv.MDataAnalyticsSvcGeneralBhv;
import net.humanbridge.conmanagement.web.dbflute.exbhv.MDataAnalyticsUsrGeneralBhv;
import net.humanbridge.conmanagement.web.dbflute.exentity.MDataAnalyticsCsvPattern;
import net.humanbridge.conmanagement.web.dbflute.exentity.MDataAnalyticsUsrGeneral;
import net.humanbridge.conmanagement.web.dto.UserSessionDto;
import net.humanbridge.conmanagement.web.dto.UserSessionDto.MDataAnalyticsGrpGeneralConfig;
import net.humanbridge.conmanagement.web.dto.UserSessionDto.MDataAnalyticsSvcGeneralConfig;
import net.humanbridge.conmanagement.web.dto.analytics.CsvPatternDto;
import net.humanbridge.conmanagement.web.dto.analytics.DepartmentDto;
import net.humanbridge.conmanagement.web.dto.analytics.DisplayDataDto;
import net.humanbridge.conmanagement.web.dto.analytics.GeneraltDto;
import net.humanbridge.conmanagement.web.dto.analytics.GraphDataDto;
import net.humanbridge.conmanagement.web.dto.analytics.SearchItemDto;
import net.humanbridge.conmanagement.web.dto.analytics.SpreadsheetDataDto;
import net.humanbridge.conmanagement.web.dto.analytics.SumUnitDto;
import net.humanbridge.conmanagement.web.exception.InvalidMasterConfigException;
import net.humanbridge.conmanagement.web.service.analytics.csv.IMakeCsvData;
import net.humanbridge.conmanagement.web.service.analytics.csv.IMakeCsvDataFactory;
import net.humanbridge.conmanagement.web.service.analytics.graph.IMakeGraphData;
import net.humanbridge.conmanagement.web.service.analytics.graph.IMakeGraphDataFactory;

/**
 * 利用状況サービスクラス
 * @author xonogawa.koichi
 *
 */
@Service
public class AnalyticsService {

	/** イベントロガー */
	private static final F2Logger logger = F2Logger.getLogger();

	/** データ保持期間（単位：月） */
	@Value("${cron.task.data-analytics.ttl}")
	private int analyticsTtl;

	@Autowired
	private Environment environment;

	@Autowired
	private MDataAnalyticsUsrGeneralBhv mDataAnalyticsUsrGeneralBhv;

	@Autowired
	private MDataAnalyticsSvcGeneralBhv mDataAnalyticsSvcGeneralBhv;

	@Autowired
	private MDataAnalyticsCsvPatternBhv mDataAnalyticsCsvPatternBhv;

	@Autowired
	private ApiCall apiCall;

	/** グラフデータ作成サービスのファクトリー */
	@Autowired
	private IMakeGraphDataFactory iMakeGraphDataFactory;

	/** CSVデータ作成サービスのファクトリー */
	@Autowired
	private IMakeCsvDataFactory iMakeCsvDataFactory;

	private Map<String, String> serviceNameMap = new HashMap<>();
	private Map<String, String> serviceGraphTitleMap = new HashMap<>();
	private Map<String, String> serviceKindMap = new HashMap<>();
	private Map<String, String> serviceIdMap = new HashMap<>();

	/** CSVパターンマスタの画面名称、ファイル名称の置換文字列 */
	static private final String TARGET = "{target}";	// 集計単位
	static private final String KIND = "{kind}";		// サービス種別
	static private final String SYSDATE = "{sysdate}";	// システム日付

	/**
	 * 初期処理
	 * 
	 * @param mDataAnalyticsGrpGeneralConfig
	 * @return
	 * @throws IllegalStateException
	 */
	public void init() {
		// Application.preperties設定値
		// key:サービスID、value:名称
		serviceNameMap.put(
				AnalyticsConstants.AC_CHECKIN,
				environment.getRequiredProperty(AnalyticsConstants.CONCIERGE_ANALYTIES + "." + AnalyticsConstants.AC_CHECKIN.toLowerCase() + AnalyticsConstants.SERVICE_NAME));
		serviceNameMap.put(
				AnalyticsConstants.CON_USER,
				environment.getRequiredProperty(AnalyticsConstants.CONCIERGE_ANALYTIES + "." + AnalyticsConstants.CON_USER.toLowerCase() + AnalyticsConstants.SERVICE_NAME));
		serviceNameMap.put(
				AnalyticsConstants.PRC_DISP,
				environment.getRequiredProperty(AnalyticsConstants.CONCIERGE_ANALYTIES + "." + AnalyticsConstants.PRC_DISP.toLowerCase() + AnalyticsConstants.SERVICE_NAME));
		serviceNameMap.put(
				AnalyticsConstants.MT_CALL,
				environment.getRequiredProperty(AnalyticsConstants.CONCIERGE_ANALYTIES + "." + AnalyticsConstants.MT_CALL.toLowerCase() + AnalyticsConstants.SERVICE_NAME));
		serviceNameMap.put(
				AnalyticsConstants.HS_CALL,
				environment.getRequiredProperty(AnalyticsConstants.CONCIERGE_ANALYTIES + "." + AnalyticsConstants.HS_CALL.toLowerCase() + AnalyticsConstants.SERVICE_NAME));
		serviceNameMap.put(
				AnalyticsConstants.AR_PUSH,
				environment.getRequiredProperty(AnalyticsConstants.CONCIERGE_ANALYTIES + "." + AnalyticsConstants.AR_PUSH.toLowerCase() + AnalyticsConstants.SERVICE_NAME));

		// Application.preperties設定値
		// key:サービスID、value:グラフタイトル
		serviceGraphTitleMap.put(
				AnalyticsConstants.AC_CHECKIN,
				environment.getRequiredProperty(AnalyticsConstants.CONCIERGE_ANALYTIES + "." + AnalyticsConstants.AC_CHECKIN.toLowerCase() + AnalyticsConstants.GRAPH_TITLE));
		serviceGraphTitleMap.put(
				AnalyticsConstants.CON_USER,
				environment.getRequiredProperty(AnalyticsConstants.CONCIERGE_ANALYTIES + "." + AnalyticsConstants.CON_USER.toLowerCase() + AnalyticsConstants.GRAPH_TITLE));
		serviceGraphTitleMap.put(
				AnalyticsConstants.PRC_DISP,
				environment.getRequiredProperty(AnalyticsConstants.CONCIERGE_ANALYTIES + "." + AnalyticsConstants.PRC_DISP.toLowerCase() + AnalyticsConstants.GRAPH_TITLE));
		serviceGraphTitleMap.put(
				AnalyticsConstants.MT_CALL,
				environment.getRequiredProperty(AnalyticsConstants.CONCIERGE_ANALYTIES + "." + AnalyticsConstants.MT_CALL.toLowerCase() + AnalyticsConstants.GRAPH_TITLE));
		serviceGraphTitleMap.put(
				AnalyticsConstants.HS_CALL,
				environment.getRequiredProperty(AnalyticsConstants.CONCIERGE_ANALYTIES + "." + AnalyticsConstants.HS_CALL.toLowerCase() + AnalyticsConstants.GRAPH_TITLE));
		serviceGraphTitleMap.put(
				AnalyticsConstants.AR_PUSH,
				environment.getRequiredProperty(AnalyticsConstants.CONCIERGE_ANALYTIES + "." + AnalyticsConstants.AR_PUSH.toLowerCase() + AnalyticsConstants.GRAPH_TITLE));

		// key:サービスID、value:サービス種別
		serviceKindMap.put(
				environment.getRequiredProperty(AnalyticsConstants.CONCIERGE_ANALYTIES + "." + AnalyticsConstants.AC_CHECKIN.toLowerCase() + AnalyticsConstants.SERVICE_ID),
				AnalyticsConstants.AC_CHECKIN);
		serviceKindMap.put(
				environment.getRequiredProperty(AnalyticsConstants.CONCIERGE_ANALYTIES + "." + AnalyticsConstants.CON_USER.toLowerCase() + AnalyticsConstants.SERVICE_ID),
				AnalyticsConstants.CON_USER);
		serviceKindMap.put(
				environment.getRequiredProperty(AnalyticsConstants.CONCIERGE_ANALYTIES + "." + AnalyticsConstants.PRC_DISP.toLowerCase() + AnalyticsConstants.SERVICE_ID),
				AnalyticsConstants.PRC_DISP);
		serviceKindMap.put(
				environment.getRequiredProperty(AnalyticsConstants.CONCIERGE_ANALYTIES + "." + AnalyticsConstants.MT_CALL.toLowerCase() + AnalyticsConstants.SERVICE_ID),
				AnalyticsConstants.MT_CALL);
		serviceKindMap.put(
				environment.getRequiredProperty(AnalyticsConstants.CONCIERGE_ANALYTIES + "." + AnalyticsConstants.HS_CALL.toLowerCase() + AnalyticsConstants.SERVICE_ID),
				AnalyticsConstants.HS_CALL);
		serviceKindMap.put(
				environment.getRequiredProperty(AnalyticsConstants.CONCIERGE_ANALYTIES + "." + AnalyticsConstants.AR_PUSH.toLowerCase() + AnalyticsConstants.SERVICE_ID),
				AnalyticsConstants.AR_PUSH);

		// key:サービス種別、value:サービスID
		serviceIdMap.put(AnalyticsConstants.AC_CHECKIN,
				environment.getRequiredProperty(AnalyticsConstants.CONCIERGE_ANALYTIES + "." + AnalyticsConstants.AC_CHECKIN.toLowerCase() + AnalyticsConstants.SERVICE_ID));
		serviceIdMap.put(AnalyticsConstants.CON_USER,
				environment.getRequiredProperty(AnalyticsConstants.CONCIERGE_ANALYTIES + "." + AnalyticsConstants.CON_USER.toLowerCase() + AnalyticsConstants.SERVICE_ID));
		serviceIdMap.put(AnalyticsConstants.PRC_DISP,
				environment.getRequiredProperty(AnalyticsConstants.CONCIERGE_ANALYTIES + "." + AnalyticsConstants.PRC_DISP.toLowerCase() + AnalyticsConstants.SERVICE_ID));
		serviceIdMap.put(AnalyticsConstants.MT_CALL,
				environment.getRequiredProperty(AnalyticsConstants.CONCIERGE_ANALYTIES + "." + AnalyticsConstants.MT_CALL.toLowerCase() + AnalyticsConstants.SERVICE_ID));
		serviceIdMap.put(AnalyticsConstants.HS_CALL,
				environment.getRequiredProperty(AnalyticsConstants.CONCIERGE_ANALYTIES + "." + AnalyticsConstants.HS_CALL.toLowerCase() + AnalyticsConstants.SERVICE_ID));
		serviceIdMap.put(AnalyticsConstants.AR_PUSH,
				environment.getRequiredProperty(AnalyticsConstants.CONCIERGE_ANALYTIES + "." + AnalyticsConstants.AR_PUSH.toLowerCase() + AnalyticsConstants.SERVICE_ID));
	}

	/**
	 * 利用状況確認ツールグループマスタのサービスIDからApplication.preperties設定のサービス名称の取得
	 * 
	 * @param mDataAnalyticsGrpGeneralConfig
	 * @return
	 */
	public Map<String, String> getServiceList(MDataAnalyticsGrpGeneralConfig mDataAnalyticsGrpGeneralConfig)
			throws IllegalStateException {
		// 利用状況確認ツールグループ汎用マスタのServiceID
		Map<String, String> serviceIdList = new LinkedHashMap<>();
		if (StringUtils.isEmpty(mDataAnalyticsGrpGeneralConfig.getMasterValue(ALLOWED_SERVICE_ID_KEY))) {
			logger.log("WCMG0101", "利用状況確認ツールグループ汎用マスタが設定されていません。[" + ALLOWED_SERVICE_ID_KEY + "]");
			throw new InvalidMasterConfigException(
					"利用状況確認ツールグループ汎用マスタが設定されていません。[" + ALLOWED_SERVICE_ID_KEY + "]", "", "利用状況確認ツールグループ汎用マスタ");
		}

		String serviceIdArray[] = mDataAnalyticsGrpGeneralConfig.getMasterValue(ALLOWED_SERVICE_ID_KEY).split(",");
		for (String serviceId : serviceIdArray) {
			serviceIdList.put(serviceKindMap.getOrDefault(serviceId, ""), serviceNameMap.getOrDefault(serviceKindMap.getOrDefault(serviceId, ""), ""));
		}
		return serviceIdList;
	}

	/**
	 * 集計単位取得
	 * 
	 * @param mDataAnalyticsGrpGeneralConfig
	 * @param mDataAnalyticsSvcGeneral
	 * @return
	 */
	public List<SumUnitDto> getUnitList(MDataAnalyticsGrpGeneralConfig mDataAnalyticsGrpGeneralConfig) {
		List<SumUnitDto> sumUnitList = new ArrayList<>();
		// サービスID
		String serviceIdArray[] = mDataAnalyticsGrpGeneralConfig.getMasterValue(ALLOWED_SERVICE_ID_KEY).split(",");

		for (String serviceId : serviceIdArray) {
			MDataAnalyticsSvcGeneralConfig mDataAnalyticsSvcGeneral = mDataAnalyticsSvcGeneralBhv
					.getMDataAnalyticsSvcGeneralConfig(serviceKindMap.getOrDefault(serviceId, ""));
			// ，区切りで複数指定あり
			String[] sumUnitArray = mDataAnalyticsSvcGeneral.getMasterValue(SEARCH_ITEM_SUM_UNIT).split(",");
			for (String sumUnit : sumUnitArray) {
				SumUnitDto sumUnitDto = new SumUnitDto(serviceKindMap.getOrDefault(serviceId, ""), sumUnit);
				sumUnitList.add(sumUnitDto);
				Boolean result = false;
				for (String value: UNIT_VALUE) {
					if (sumUnit.equals(value)) {
						result = true;
						break;
					}
				}
				if (!result) {
					logger.log("WCMG0101", "利用状況確認ツールサービス汎用マスタが設定されていません。[" + SEARCH_ITEM_SUM_UNIT + "]");
					throw new InvalidMasterConfigException(
							"利用状況確認ツールサービス汎用マスタ不正。[" + SEARCH_ITEM_SUM_UNIT + "]");
				}
			}
		}
		if (sumUnitList.isEmpty()) {
			logger.log("WCMG0101", "利用状況確認ツールサービス汎用マスタが設定されていません。[" + SEARCH_ITEM_SUM_UNIT + "]");
			throw new InvalidMasterConfigException(
					"利用状況確認ツールサービス汎用マスタが設定されていません。[" + SEARCH_ITEM_SUM_UNIT + "]");
		}
		return sumUnitList;
	}

	/**
	 * CSV出力パターンの選択肢取得
	 * 
	 * @param mDataAnalyticsGrpGeneralConfig
	 * @return
	 */
	public List<CsvPatternDto> getCsvPatternList(MDataAnalyticsGrpGeneralConfig mDataAnalyticsGrpGeneralConfig) {
		// CSV出力パターンマスタを全件取得
		List<MDataAnalyticsCsvPattern> mDataAnalyticsCsvPatternList = mDataAnalyticsCsvPatternBhv
				.searchDataAnalyticsCsvPattern();
		// サービスID
		String serviceIdArray[] = mDataAnalyticsGrpGeneralConfig.getMasterValue(ALLOWED_SERVICE_ID_KEY).split(",");

		List<CsvPatternDto> csvPatternList = new ArrayList<CsvPatternDto>();
		for (String serviceId : serviceIdArray) {
			MDataAnalyticsSvcGeneralConfig mDataAnalyticsSvcGeneral = mDataAnalyticsSvcGeneralBhv
					.getMDataAnalyticsSvcGeneralConfig(serviceKindMap.getOrDefault(serviceId, ""));
			// CSV出力パターン。「，」区切りで複数指定あり
			String[] csvOutputPatternArray = mDataAnalyticsSvcGeneral.getMasterValue(CSV_OUTPUT_PATTERN).split(",");
			if (csvOutputPatternArray.length == 0 || csvOutputPatternArray[0].isEmpty()) {
				logger.log("WCMG0101", "CSV出力パターンマスタまたは利用状況確認ツールサービス汎用マスタが設定されていません。");
				throw new InvalidMasterConfigException(
						"CSV出力パターンマスタまたは利用状況確認ツールサービス汎用マスタが設定されていません。");
			}
			for (String csvOutputPattern : csvOutputPatternArray) {
				if (!csvOutputPattern.isEmpty()) {
					if (!org.apache.commons.lang3.StringUtils.isNumeric(csvOutputPattern)) {
						logger.log("WCMG0101", "利用状況確認ツールサービス汎用マスタが設定値が数値以外。サービス汎用マスタ[csv_output_pattern]=" + csvOutputPattern);
						throw new InvalidMasterConfigException(
								"CSV出力パターンマスタまたは利用状況確認ツールサービス汎用マスタが設定されていません。");
					}
					MDataAnalyticsCsvPattern mDataAnalyticsCsvPattern = getMDataAnalyticsCsvPattern(mDataAnalyticsCsvPatternList, Long.parseLong(csvOutputPattern));
					if (StringUtils.isEmpty(mDataAnalyticsCsvPattern)) {
						logger.log("WCMG0101", "利用状況確認ツールサービス汎用マスタの設定値がCSV出力パターンマスタに登録されていません。サービス汎用マスタ[csv_output_pattern]=" + csvOutputPattern);
						throw new InvalidMasterConfigException(
								"CSV出力パターンマスタまたは利用状況確認ツールサービス汎用マスタが設定されていません。");
					} else {
						String targetName = environment.getRequiredProperty(AnalyticsConstants.CONCIERGE_ANALYTIES + "." + serviceKindMap.getOrDefault(serviceId, "").toLowerCase() + AnalyticsConstants.GRAPH_TITLE);
						String csvPatternDispName = mDataAnalyticsCsvPattern.getDisplayName().replace(TARGET, targetName);
						String searchPeriodType = mDataAnalyticsCsvPattern.getSearchPeriodType();
						CsvPatternDto csvPatternDto = new CsvPatternDto(serviceKindMap.getOrDefault(serviceId, ""), csvOutputPattern, csvPatternDispName, searchPeriodType);

						csvPatternList.add(csvPatternDto);
					}
				}
			}
		}
		if (csvPatternList.isEmpty()) {
			logger.log("WCMG0101", "CSV出力パターンマスタまたは利用状況確認ツールサービス汎用マスタが設定されていません。");
			throw new InvalidMasterConfigException(
					"CSV出力パターンマスタまたは利用状況確認ツールサービス汎用マスタが設定されていません。");
		}
		return csvPatternList;
	}

	/**
	 * CSV出力パターンDTOから、SEQが一致するデータを取得する
	 * 
	 * @param mDataAnalyticsCsvPatternList
	 * @param seq
	 * @return
	 */
	private MDataAnalyticsCsvPattern getMDataAnalyticsCsvPattern(
			List<MDataAnalyticsCsvPattern> mDataAnalyticsCsvPatternList, Long seq) {
		for (MDataAnalyticsCsvPattern mDataAnalyticsCsvPattern : mDataAnalyticsCsvPatternList) {
			if (mDataAnalyticsCsvPattern.getSeq().equals(seq)) {
				return mDataAnalyticsCsvPattern;
			}
		}
		return null;
	}

	/**
	 * 利用状況確認ツールユーザ汎用マスタより、リストボックスの初期値取得
	 * 
	 * @param groupId
	 * @param mDataAnalyticsGrpGeneralConfig
	 * @param userSessionDto
	 * @return
	 */
	public List<GeneraltDto> getDefaultData(String groupId,
			MDataAnalyticsGrpGeneralConfig mDataAnalyticsGrpGeneralConfig, UserSessionDto userSessionDto, List<SumUnitDto> sumUnitList, List<CsvPatternDto> csvPatternList) {
		List<GeneraltDto> slectDefaultList = new ArrayList<>();
		// サービスID
		String serviceIdArray[] = mDataAnalyticsGrpGeneralConfig.getMasterValue(ALLOWED_SERVICE_ID_KEY).split(",");
		// KEY ※[UNIT_KEY]は配列の１番目
		List<String> masterKeys = Arrays.asList(UNIT_KEY, PERIOD_START_KEY, PERIOD_END_KEY, DEPT_CODE_KEY,
				CSV_OUTPUT_KEY);

		// 集計単位ごとに初期値を設定するため集計単位を保持しておく
		Map<String, String> unitMap = new HashMap<>();

		// サービス汎用マスタ（集計単位）
		// ユーザー汎用マスタ、master_key=unit にサービスマスタに登録されていない値が設定されてないかチェックするため、
		// key：サービス種別_集計単位、value:集計単位名、でMAPしておき、ユーザー汎用マスタ取得時のチェックに使用します。
		Map<String, String> sumUnitMap = sumUnitList.stream()
		.collect(Collectors.toMap(p -> p.getServiceKind() + "_" + p.getSumUnit(), p -> p.getSumUnitName()));

		// サービス汎用マスタ（CSVパターン）
		// ユーザー汎用マスタ、master_key=csv_output_pattern にサービスマスタに登録されていない値が設定されてないかチェックするため、
		// key：サービス種別_CSVパターンマスタのSeq、value:CSV名、でMAPしておき、ユーザー汎用マスタ取得時のチェックに使用します。
		Map<String, String> csvPatternMap = csvPatternList.stream()
		.collect(Collectors.toMap(p -> p.getServiceKind() + "_" + p.getSeq(), p -> p.getDisplayName()));
		
		// サービス汎用マスタ（診療科）
		// ユーザー汎用マスタ、master_key=dept_code にAPI34で取得した診療科に登録されていない値が設定されてないかチェックするため、
		// key：診療科コード、value:診療科名、でMAPしておき、ユーザー汎用マスタ取得時のチェックに使用します。
		Map<String, String> deptMap = userSessionDto.getDepartmentList().stream()
				.collect(Collectors.toMap(p -> p.getDeptCode(), p -> p.getDeptName()));

		// サービス種別ごとの各リストボックスの初期値を取得する
		for (String serviceKind : AnalyticsConstants.SERVICE_KIND) {
			// 利用状況確認ツールグループ汎用マスタに登録されているか
			if (Arrays.asList(serviceIdArray).contains(serviceIdMap.getOrDefault(serviceKind, ""))) {
				// 設定値ごとに取得する
				for (String masterKey : masterKeys) {
					List<MDataAnalyticsUsrGeneral> mDataAnalyticsUsrGeneralList = mDataAnalyticsUsrGeneralBhv
							.getMDataAnalyticsUsrGeneralConfig(groupId, userSessionDto, serviceKind, masterKey, sumUnitMap, csvPatternMap, deptMap);
					if (mDataAnalyticsUsrGeneralList.size() > 0) {
						String masterValue = "";
						if (masterKey.equals(PERIOD_START_KEY) || masterKey.equals(PERIOD_END_KEY)) {
							// 集計期間初期値
							// 集計期間のとき、設定値は「-3」など数値が設定されている。画面で初期値設定しやすいように、設定値から計算した年月を初期値として引き渡す。
							DateTime nowDate = AppUtils.getNowDateTime();
							switch (unitMap.get(serviceKind)) {
							case AnalyticsConstants.UNIT_HOUR:	// 集計単位：時間
							case AnalyticsConstants.UNIT_DAY:	// 集計単位：日
								// 設定値が0以上または未設定時は常に前日
								int days = -1;
								if (!StringUtils.isEmpty(mDataAnalyticsUsrGeneralList.get(0).getMasterValue()) && mDataAnalyticsUsrGeneralList.get(0).getMasterValue().matches("[+-]?\\d*(\\.\\d+)?")) {
									days = Integer.parseInt(mDataAnalyticsUsrGeneralList.get(0).getMasterValue());
								}
								if (days >= 0) {
									days = -1;
								}
								// データ保持期限前が設定されたときは前日にする
								DateTime pastDate = DateTime.now().minusMonths(analyticsTtl);	// データ保持期限の日（一番古いデータ日）
								DateTime setDate = DateTime.now().plusDays(days);// 初期値の日数分過去日(設定値はマイナスなのでplusDaysする
								if (setDate.isBefore(pastDate)) {
									days = -1;
								}
								nowDate = nowDate.plusDays(days);// 設定値がマイナスなのでPlusでOK
								masterValue = DateTimeFormat.forPattern("yyyy/MM/dd").print(nowDate);
								break;

							case AnalyticsConstants.UNIT_MONTH:
								// 集計単位：月
								int month = -1;
								if (!StringUtils.isEmpty(mDataAnalyticsUsrGeneralList.get(0).getMasterValue()) && mDataAnalyticsUsrGeneralList.get(0).getMasterValue().matches("[+-]?\\d*(\\.\\d+)?")) {
									month = Integer.parseInt(mDataAnalyticsUsrGeneralList.get(0).getMasterValue());
									if (month < analyticsTtl* -1) {
										// 選択可能月数より前の設定は、前月にする
										month = -1;
									}
								}
								nowDate = nowDate.plusMonths(month);// 設定値がマイナスなのでPlusでOK
								// 期間開始のとき１日、期間終了のとき月末の日付にする
								DateTime dateTime = new DateTime(nowDate);
								if (masterKey.equals(PERIOD_START_KEY)) {
									dateTime = dateTime.dayOfMonth().withMinimumValue();
								} else {
									dateTime = dateTime.dayOfMonth().withMaximumValue();
								}
								masterValue = DateTimeFormat.forPattern("yyyyMMdd").print(dateTime);
								break;
							}

						} else {
							// 集計期間以外の初期値
							masterValue = mDataAnalyticsUsrGeneralList.get(0).getMasterValue();
							unitMap.put(serviceKind, masterValue);	// 集計単位保持
						}
						GeneraltDto selectListDefaultDto = new GeneraltDto(serviceKind, masterKey, masterValue);
						slectDefaultList.add(selectListDefaultDto);
					}
				}
			}
		}
		if (slectDefaultList.isEmpty()) {
			logger.log("WCMG0101", "利用状況確認ツールユーザ汎用マスタが設定されていません。[" + ALLOWED_SERVICE_ID_KEY + "]");
			throw new InvalidMasterConfigException("利用状況確認ツールユーザ汎用マスタが設定されていません。[" + ALLOWED_SERVICE_ID_KEY + "]");
		}
		return slectDefaultList;
	}

	/**
	 * 利用状況確認ツールサービス汎用マスタ取得
	 * 
	 * @param mDataAnalyticsGrpGeneralConfig
	 * @return
	 */
	public Map<String, String> getMDataAnalyticsGrpGeneral(
			MDataAnalyticsGrpGeneralConfig mDataAnalyticsGrpGeneralConfig, String masterKey)
			throws IllegalStateException {
		// 利用状況確認ツールグループ汎用マスタのServiceID
		Map<String, String> messageHeadList = new LinkedHashMap<>();
		String serviceIdArray[] = mDataAnalyticsGrpGeneralConfig.getMasterValue(ALLOWED_SERVICE_ID_KEY).split(",");

		for (String serviceId : serviceIdArray) {
			MDataAnalyticsSvcGeneralConfig mDataAnalyticsSvcGeneral = mDataAnalyticsSvcGeneralBhv
					.getMDataAnalyticsSvcGeneralConfig(serviceKindMap.getOrDefault(serviceId, ""));
			String messageHead = mDataAnalyticsSvcGeneral.getMasterValue(masterKey);
			
			// 診療科表示非表示設定のみ以下のチェックを行う
			if (masterKey.equals(SEARCH_ITEM_DEPT)) {
				// 空は非表示とする
				if (messageHead.isEmpty()) {
					messageHead = "0";
				}
				// 0,1以外は設定エラー
				if (messageHead.equals("0") || messageHead.equals("1")) {
					messageHeadList.put(serviceKindMap.getOrDefault(serviceId, ""), messageHead);
				} else {
					logger.log("WCMG0101", "利用状況確認ツールサービス汎用マスタが設定されていません。[" + masterKey + "]");
					throw new InvalidMasterConfigException("利用状況確認ツールサービス汎用マスタが設定されていません。[" + masterKey + "]", "利用状況確認ツールサービス汎用マスタ", "NgValue");
				}
			} else {
				messageHeadList.put(serviceKindMap.getOrDefault(serviceId, ""), messageHead);
			}
		}
		if (messageHeadList.isEmpty()) {
			logger.log("WCMG0101", "利用状況確認ツールサービス汎用マスタが設定されていません。[" + masterKey + "]");
			throw new InvalidMasterConfigException("利用状況確認ツールサービス汎用マスタが設定されていません。[" + masterKey + "]", "利用状況確認ツールサービス汎用マスタ", "NoData");
		}
		return messageHeadList;
	}

	/**
	 * 診療科取得
	 * 
	 * @param userSessionDto
	 * @param request
	 * @return
	 */
	public List<DepartmentDto> getDepartmentListItem(UserSessionDto userSessionDto, HttpServletRequest request) {
		try {
			// 受診科を取得する
			ApiRequestDxo reqDxo = new ApiRequestDxo();
			reqDxo.setServletRequest(request);

			List<DepartmentDto> departmentList = apiCall.getDepartmentList(reqDxo, userSessionDto);
			if (!departmentList.isEmpty()) {
				if (!AppConstants.CHART_TYPE_HX.equals(userSessionDto.getHospitalOptApi().getChartType())) {
					// 診療科でソート(HX は SQL で ORDER BY が指定してあるのでソートしなくて良い)
					departmentList = departmentList.stream()
						.sorted(Comparator.comparing(DepartmentDto::getDeptCode))
						.collect(Collectors.toList());
				}
				departmentList.add(0, new DepartmentDto(AnalyticsConstants.DEPT_ALL, "全科")); // 先頭に全科を追加
			}
			return departmentList;

		} catch (Exception e) {
			throw new InvalidMasterConfigException("システム連携PF", "診療科一覧", " ");
		}
	}

	/**
	 * グラフ表示用データ取得
	 * @param searchItemDto
	 * @param userSessionDto
	 * @return
	 */
	public List<GraphDataDto> getGraphData(SearchItemDto searchItemDto, UserSessionDto userSessionDto) {
		// サービス種別ごとのFactoryを設定
		IMakeGraphData factory = iMakeGraphDataFactory.create(searchItemDto.getSelectServiceKind());

		/** 検索条件 */
		// 検索対象テーブルの検索値となるグループID取得
		String searchTargetGroupId = factory.getSearchTargetGroupId(searchItemDto.getSelectServiceKind(), userSessionDto);
		// 検索対象期間
		Pair<Date, Date> pair = getPeriod(searchItemDto);
		Date fromDate = pair.getLeft();
		Date toDate = pair.getRight();
		// 診療科は選択されない(選択肢をださない）場合があるので、Nullを回避しておく
		if (StringUtils.isEmpty(searchItemDto.getSelectDepertment())) {
			searchItemDto.setSelectDepertment("");
		}

		/** グラフ表示用データ取得 */
		List<Map<String, Long>> graphDataMapList = factory.getGraphData(searchTargetGroupId, fromDate, toDate, searchItemDto.getSelectUnit(), searchItemDto.getSelectDepertment(), userSessionDto.getMDataAnalyticsGrpGeneralConfig().getFetchAmount());
		// グラフ表示用に整形する
		List<GraphDataDto> graphDataList = getGraphDataListArrange(searchItemDto, graphDataMapList, fromDate, toDate);

		return graphDataList;
	}
	
	/**
	 * 最大値取得からグラフの上限値を設定する
	 * @param map
	 * @return
	 */
	public Long getMaxValue(Map<String, Long> map) {
		Long maxValue = 0L;
		Long scaleMaxValue = 0L;
		Long plusPercent = 10L;	// グラフ最大目盛りの加算比率
		
		for (Map.Entry<String, Long> entry : map.entrySet()) {
			if (entry.getValue() > maxValue) {
				maxValue = entry.getValue();
			}
		}

		if (maxValue >= 10) {
			// グラフの上限値
			int tempValue = Math.round(maxValue / plusPercent);
			scaleMaxValue = (long) tempValue + maxValue;
		} else {
			scaleMaxValue =10L;
		}
		return scaleMaxValue;
	}

	/**
	 * グラフ目盛り
	 * グラフ全体で最大値の10分の１の桁数の最小値を１目盛りにする
	 * ただし、最大値が20%までは、5分の1、21%～70%は2分の1、71%～100%は1分の1
	 * 例)最大値：7500 → 1000
	 *    最大値：44000 → 10000の2分の1で、2000
	 *    最大値：150 → 100の5分の1で、20
	 * @param maxValue
	 * @return
	 */
	public int getStepSize(Long maxValue) {
		if (maxValue <= 10) {
			return 1;
		}
		double valLen = String.valueOf(Math.toIntExact(maxValue) / 10).length();
		double stepSize = Math.pow(10, valLen);
		if (maxValue <= stepSize * 2) {
			stepSize = stepSize /5;
		} else if (maxValue <= stepSize * 7) {
			stepSize = stepSize /2;
		}
		return (int)stepSize;
	}

	/**
	 * 集計表表示用　見出し日付の整形
	 * @param unit
	 * @param dateString
	 * @return
	 */
	public String getFormatGroupDateForSpred(SearchItemDto searchItemDto, String dateString) {
		String formatDateStr = "";
		SimpleDateFormat ymdFormat = new SimpleDateFormat("yyyy/MM/dd");
		switch (searchItemDto.getSelectUnit()) {
		case "hour":
			Date date = AppUtils.parseDate(searchItemDto.getSelectPeriodDate(), "yyyy/MM/dd").toDate();
			formatDateStr = ymdFormat.format(date) + " " + dateString + ":00";
			break;
		case "day":
			DateTime dateValue = AppUtils.toDateTime(Integer.parseInt(dateString));
			formatDateStr = ymdFormat.format(dateValue.toDate());
			break;
		case "month":
			if (dateString.length() == 6) {
				formatDateStr = dateString.substring(0,4) + "/" + dateString.substring(4,6);
			}
			break;
		}
		return formatDateStr;
	}

	/**
	 * CSV出力用　日付の整形
	 * @param searchItemDto
	 * @param dateString
	 * @return
	 */
	public String getFormatGroupDateForCsv(SearchItemDto searchItemDto, String dateString) {
		String formatDateStr = "";
		switch (searchItemDto.getSelectUnit()) {
		case "hour":
			formatDateStr = searchItemDto.getSelectPeriodDate() + " " + dateString + ":00";
			break;
		case "day":
			SimpleDateFormat ymdFormat = new SimpleDateFormat("yyyy/MM/dd");
			DateTime dateValue = AppUtils.toDateTime(Integer.parseInt(dateString));
			formatDateStr = ymdFormat.format(dateValue.toDate());
			break;
		case "month":
			if (dateString.length() == 6) {
				formatDateStr = dateString.substring(0,4) + "/" + dateString.substring(4,6);
			}
			break;
		}
		return formatDateStr;
	}

	/**
	 * グラフ表示用　見出し日付の整形
	 * @param unit
	 * @param dateString
	 * @return
	 */
	public String getFormatGroupDateForGraph(SearchItemDto searchItemDto,  String dateString, boolean yearChange) {
		String formatDateStr = "";
		switch (searchItemDto.getSelectUnit()) {
		case "hour":
			formatDateStr = dateString;
			break;
		case "day":
			SimpleDateFormat ymdFormatMd = new SimpleDateFormat("MM/dd");
			SimpleDateFormat ymdFormatYmd = new SimpleDateFormat("yyyy/MM/dd");
			DateTime dateValue = AppUtils.toDateTime(Integer.parseInt(dateString));
			if (yearChange) {
				formatDateStr = ymdFormatYmd.format(dateValue.toDate());
			} else {
				formatDateStr = ymdFormatMd.format(dateValue.toDate());
			}
			break;
		case "month":
			if (dateString.length() == 6) {
				formatDateStr = dateString.substring(0,4) + "/" + dateString.substring(4,6);
			}
			break;
		}
		return formatDateStr;
	}

	/**
	 * 検索結果データを表示用に整形する
	 * @param graphData
	 * @param searchItemDto
	 * @return
	 */
	public DisplayDataDto getMakeData(GraphDataDto graphData, SearchItemDto searchItemDto, Model model) {
	
		String label[]= new String[graphData.getData().entrySet().size()];	// グラフ下部 見出し
		Long point[]= new Long[graphData.getData().entrySet().size()];		// グラフデータ
		List<SpreadsheetDataDto> spreadsheetDataList = new ArrayList<>();	// 集計表データ用DTO

		int i = 0;
		boolean yearChange = false;
		String beforeData = "";
		for(Map.Entry<String, Long> entry : graphData.getData().entrySet()) {
			// グラフデータ
			yearChange = false;
			if (entry.getKey().length() >=4) {
				if (!beforeData.equals(entry.getKey().substring(0, 4))) {
					yearChange = true;
				}
				beforeData = entry.getKey().substring(0, 4);
			}
			// グラフ表示用に見出しになる日付を整形
			label[i] = getFormatGroupDateForGraph(searchItemDto, entry.getKey(), yearChange);
			point[i] = entry.getValue();
			i++;
			// 集計表データ
			SpreadsheetDataDto spreadsheetDataDto = new SpreadsheetDataDto();
			// 集計表示用に見出しになる日付を整形
			spreadsheetDataDto.setTitle(getFormatGroupDateForSpred(searchItemDto, entry.getKey()));
			spreadsheetDataDto.setData(String.format("%,d", entry.getValue()));
			spreadsheetDataList.add(spreadsheetDataDto);
		}

		DisplayDataDto displayDataDto = new DisplayDataDto();
		// グラフデータセット
		displayDataDto.setLabel(label);
		displayDataDto.setPoint(point);
		displayDataDto.setSpreadsheetDataList(spreadsheetDataList);

		model.addAttribute("graphTitle", graphData.getTitle());				// タイトル
		model.addAttribute("graphGraphTitle", graphData.getGraphTitle());	// グラフタイトル

		// 集計表データセット
		String spreadsheetTitle = getUnitTitle(searchItemDto.getSelectUnit());
		model.addAttribute("spreadsheetHeaderTitle", spreadsheetTitle);			// 集計表項目のタイトル
		model.addAttribute("spreadsheetValueTitle", graphData.getGraphTitle());	// 集計表値のタイトル

		return displayDataDto;
	}

	/**
	 * CSVデータ取得
	 * @param searchItemDto
	 * @param userSessionDto
	 * @return
	 */
	public void getCsvData(SearchItemDto searchItemDto, UserSessionDto userSessionDto, MDataAnalyticsCsvPattern mDataAnalyticsCsvPattern, String departmentListJson, ServletOutputStream outputStream) throws Exception {
		// サービス種別ごとのFactoryを設定
		IMakeCsvData factory = iMakeCsvDataFactory.create(searchItemDto.getSelectServiceKind());

		/** 検索条件 */
		// 検索対象期間
		Pair<Date, Date> pair = getPeriod(searchItemDto);
		Date fromDate = pair.getLeft();
		Date toDate = pair.getRight();

		// 診療科は選択されない(選択肢をださない）場合があるので、Nullを回避しておく
		if (StringUtils.isEmpty(searchItemDto.getSelectDepertment())) {
			searchItemDto.setSelectDepertment("");
		}

		/** CSVデータ取得 */
		factory.getCsvData(userSessionDto, fromDate, toDate, searchItemDto, mDataAnalyticsCsvPattern, departmentListJson, outputStream);
	}
	
	/**
	 * 集計単位名取得
	 * @param unit
	 * @return
	 */
	public String getUnitTitle(String unit) {
		
		String spreadsheetTitle = "";
		switch (unit) {
		case "hour":
			spreadsheetTitle = "日時";
			break;
		case "day":
			spreadsheetTitle = "年月日";
			break;
		case "month":
			spreadsheetTitle = "年月";
			break;
		}
		return spreadsheetTitle;
	}

	/**
	 * 年月ごと、日ごと、時間ごとの集計データを整形する
	 * グラフのメモリが歯抜けにならないように、期間内でデータがない日付（月、または時刻）に、0件のデータを詰めておく
	 * 
	 * @param searchItemDto
	 * @param graphDataMapList
	 * @param fromDate
	 * @param toDate
	 * @return
	 */
	public List<GraphDataDto> getGraphDataListArrange(SearchItemDto searchItemDto, List<Map<String, Long>> graphDataMapList, Date fromDate, Date toDate) {
		
		List<GraphDataDto> graphDataList = new ArrayList<>();
		
		for(Map<String, Long> graphDataMap : graphDataMapList) {
			GraphDataDto graphData = new GraphDataDto();
			LinkedHashMap<String, Long> scaleGraphDataMap = new LinkedHashMap<>();
			switch (searchItemDto.getSelectUnit()) {
			case AnalyticsConstants.UNIT_HOUR:
				// 時間ごとのとき、24時間分作成
				for (int i=0; i<24; i++) {
					String key = String.format("%02d",i);
					Long value = graphDataMap.containsKey(key) ? graphDataMap.get(key) : 0L;
					scaleGraphDataMap.put(key, value);
				}
				break;
			case AnalyticsConstants.UNIT_DAY:
			case AnalyticsConstants.UNIT_MONTH:
				// 月ごと、日にちごとのとき
				String formatPattern = searchItemDto.getSelectUnit().equals(AnalyticsConstants.UNIT_DAY) ? "yyyyMMdd" : "yyyyMM";
				SimpleDateFormat yearMonthFormat = new SimpleDateFormat(formatPattern);
				Calendar calendarWhileDate = Calendar.getInstance();
				calendarWhileDate.setTime(fromDate);
				int plusScale = searchItemDto.getSelectUnit().equals(AnalyticsConstants.UNIT_DAY) ? Calendar.DAY_OF_MONTH : Calendar.MONTH;
				while (calendarWhileDate.getTime().compareTo(toDate) <= 0) {
					String key = yearMonthFormat.format(calendarWhileDate.getTime());
					Long value = graphDataMap.containsKey(key) ? graphDataMap.get(key) : 0L;
					scaleGraphDataMap.put(key, value);
					calendarWhileDate.add(plusScale, 1);
				}
				break;
			}

			graphData.setTitle(serviceNameMap.getOrDefault(searchItemDto.getSelectServiceKind(), ""));	// タイトル
			graphData.setGraphTitle(serviceGraphTitleMap.getOrDefault(searchItemDto.getSelectServiceKind(), ""));	// グラフタイトル
			graphData.setMaxValue(getMaxValue(scaleGraphDataMap));			// 最大値（グラフの最大目盛り）
			graphData.setStepSize(getStepSize(graphData.getMaxValue()));	// グラフ目盛り
			graphData.setData(scaleGraphDataMap);
			graphDataList.add(graphData);
		}
		return graphDataList;
	}

	/**
	 * CSVパターンマスタの名称変換
	 * @param fileName
	 * @param searchItemDto
	 * @return
	 */
	public String replaceCsvPatternName(String fileName, SearchItemDto searchItemDto) {
		// サービス種別名称
		String kindName = environment.getRequiredProperty(AnalyticsConstants.CONCIERGE_ANALYTIES + "." + searchItemDto.getSelectServiceKind().toLowerCase() + AnalyticsConstants.SERVICE_NAME);
		String targetName = environment.getRequiredProperty(AnalyticsConstants.CONCIERGE_ANALYTIES + "." + searchItemDto.getSelectServiceKind().toLowerCase() + AnalyticsConstants.GRAPH_TITLE);
		String systemDate = AppUtils.getStrNowDateTime();

		// 置換
		fileName = fileName.replace(TARGET, targetName);	// 集計単位
		fileName = fileName.replace(KIND, kindName);		// サービス種別
		fileName = fileName.replace(SYSDATE, systemDate);	// システム日付

		return fileName;
	}

	/**
	 * 検索期間の開始、終了を日付型にする
	 * @param searchItemDto
	 * @return
	 */
	private Pair<Date, Date> getPeriod(SearchItemDto searchItemDto) {
		Date fromDate = new Date();
		Date toDate = new Date();
		
		if (searchItemDto.getSelectUnit().equals(AnalyticsConstants.UNIT_HOUR)) {
			// 時間ごとのときは、「日」が選択されるので、From,Toを同じ日にする。
			fromDate =AppUtils.parseDate(searchItemDto.getSelectPeriodDate(), "yyyy/MM/dd").toDate();
			toDate =AppUtils.parseDate(searchItemDto.getSelectPeriodDate(), "yyyy/MM/dd").toDate();
		} else if (searchItemDto.getSelectUnit().equals(AnalyticsConstants.UNIT_DAY)) {
			fromDate =AppUtils.parseDate(searchItemDto.getSelectPeriodFromDate(), "yyyy/MM/dd").toDate();
			toDate =AppUtils.parseDate(searchItemDto.getSelectPeriodToDate(), "yyyy/MM/dd").toDate();
		} else {
			fromDate =AppUtils.toDateTime(Integer.parseInt(searchItemDto.getSelectPeriodStart())).toDate();
			toDate =AppUtils.toDateTime(Integer.parseInt(searchItemDto.getSelectPeriodEnd())).toDate();
		}
		return Pair.of(fromDate,toDate);
	}

	/**
	 * サービスIDのチェックに使用します。
	 * @param serviceId
	 * @return
	 */
	public String getServiceKind(String serviceId) {
		return serviceKindMap.getOrDefault(serviceId, "");
	}
	
	/**
	 * 五桁以上の数字文字列の場合は下四桁を切り捨てて〇〇万形式に、
	 * 四桁以下の場合はそのまま返します。
	 * @param str
	 * @return
	 */
	public String formatNumber(int number) {
		val str = String.valueOf(number);
		int len = str.length();
		if(len <= 4) return str;
		return str.substring(0, str.length() - 4) + "万";
	}
}
