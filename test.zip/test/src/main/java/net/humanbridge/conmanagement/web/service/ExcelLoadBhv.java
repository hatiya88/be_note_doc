package net.humanbridge.conmanagement.web.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import jp.co.fjqs.f2.springboot.logger.basic.F2Logger;
import net.humanbridge.conmanagement.constant.AppConstants;
import net.humanbridge.conmanagement.excel.cbean.SheetCB;
import net.humanbridge.conmanagement.excel.entity.CellDto;
import net.humanbridge.conmanagement.excel.entity.RowDto;
import net.humanbridge.conmanagement.util.ExcelUtils;
import net.humanbridge.conmanagement.util.ThreadLocalUtils;
import net.humanbridge.conmanagement.web.dbflute.exbhv.MCategoryBhv;
import net.humanbridge.conmanagement.web.dbflute.exbhv.MTemplateBhv;
import net.humanbridge.conmanagement.web.dbflute.exentity.MCategory;
import net.humanbridge.conmanagement.web.dbflute.exentity.MTemplate;
import net.humanbridge.conmanagement.web.dto.UserSessionDto;
import net.humanbridge.conmanagement.web.dto.UserSessionDto.ServiceDto;
import net.humanbridge.conmanagement.web.exception.DownloadException;
import net.humanbridge.conmanagement.web.exception.RepoolException;
import net.humanbridge.conmanagement.web.exception.UploadException;
import net.humanbridge.conmanagement.web.model.RepoolModel;
import net.humanbridge.maintenance.api.rest.constant.CodeConstants;
import net.humanbridge.maintenance.api.rest.dto.response.MasterDownloadResponseDto;
import net.humanbridge.maintenance.api.rest.dto.response.MasterUploadDetailDto;
import net.humanbridge.maintenance.api.rest.dto.response.MasterUploadResponseDto;

/**
 * エクセルをロード（ダウンロード・アップロード）するbehavior
 * <pre>
 * 本クラスのメソッド名および抽出条件クラス（SheetCB）は
 * DBFluteのメソッド名に合わせています。
 * </pre>
 */
@Service
public class ExcelLoadBhv {
	
	@Autowired
	private DownloadService downloadService;

	@Autowired
	private UploadService uploadService;
	
	@Autowired
	private MTemplateBhv mTemplateBhv;
	
	@Autowired
	private MCategoryBhv mCategoryBhv;
	
	@Autowired
	private RepoolService repoolService;
	
	/** イベントロガー */
	private static final F2Logger logger = F2Logger.getLogger();
	
	/*
	 * 削除処理では、PrimaryKeyの他、マスメンツールのdownload.jsonに、master_hospital_columnで定義されているカラムも必要となります
	 * 削除対象のテーブルに、master_hospital_columnが設定されている場合は、以下に追記してください(すべて小文字)。
	 * key:テーブル名
	 * value:カラム名
	 * 例）[m_open_reservation_frame]テーブルの[group_id]カラムが対象のとき
	 *　　key   : m_open_reservation_frame
	 *　　value : group_id
	 */
	private static final Map<String, String> masterHospitalMap = Collections.unmodifiableMap(MapUtils.putAll(new HashMap<>(), new String[][] {
		{"m_open_reservation_frame", "group_id"},	// スマート診察券 - 公開予約枠マスタ - グループID
		{"client_alert", "group_id"},	// コンシェルジュ - クライアントアラートマスタ - グループID
	}));

	/**
	 * {@code conditionMap}で抽出行を指定してテーブルを抽出します。
	 * 
	 * @param serviceDto
	 *            サービスDTO
	 * @param userSessionDto
	 *            ユーザーセッションDTO
	 * @param conditionMap
	 *            条件Map
	 * <pre>
	 * key:シート名、value:条件
	 * valueのSheetCBクラスはDBFluteのAbstractConditionBeanを継承したクラスに相当
	 * </pre>
	 * @return 抽出結果  key:シート名、value:条件に合致したRowDtoリスト
	 * @throws DownloadException
	 *            ダウンロード例外
	 * @throws IOException
	 *            IO例外
	 */
	public Map<String, List<RowDto>> selectList(ServiceDto serviceDto, UserSessionDto userSessionDto,
			Map<String, SheetCB> conditionMap) throws Exception {
		
		return selectList(serviceDto, userSessionDto, conditionMap, false);
	}
	
	/**
	 * {@code conditionMap}で抽出行を指定してテーブルを抽出します。
	 * 
	 * @param serviceDto
	 *            サービスDTO
	 * @param userSessionDto
	 *            ユーザーセッションDTO
	 * @param conditionMap
	 *            条件Map
	 * @param doGetHeader
	 *            ヘッダ行取得有無
	 * <pre>
	 * key:シート名、value:条件
	 * valueのSheetCBクラスはDBFluteのAbstractConditionBeanを継承したクラスに相当
	 * </pre>
	 * @return 抽出結果  key:シート名、value:条件に合致したRowDtoリスト
	 * @throws DownloadException
	 *            ダウンロード例外
	 * @throws IOException
	 *            IO例外
	 */
	public Map<String, List<RowDto>> selectList(ServiceDto serviceDto, UserSessionDto userSessionDto,
			Map<String, SheetCB> conditionMap, boolean doGetHeader) throws Exception {
		List<String> tableNames = new ArrayList<String>(conditionMap.keySet());
		
		// ExcelダウンロードAPI呼出
		MasterDownloadResponseDto responseDto = downloadService.download(serviceDto, userSessionDto, tableNames);
		
		// エクセルファイル取出
		try (Workbook workbook = ExcelUtils.getExcelFromDownloadResponse(responseDto);) {
			Map<String, List<RowDto>> downloadDataMap = ExcelUtils.selectList(workbook, conditionMap, doGetHeader);
			logger.log("ICMG0026", ThreadLocalUtils.getServiceDto().getGroupId(), ExcelUtils.expandDataMap(downloadDataMap));
			return downloadDataMap;
		}
	}

	/**
	 * {@code tableNames}で指定されたテーブルを抽出します。
	 * 
	 * @param serviceDto
	 *            サービスDTO
	 * @param userSessionDto
	 *            ユーザーセッションDTO
	 * @param tableNames
	 *            テーブル名
	 * @return 抽出結果  key:シート名、value:条件に合致したRowDtoリスト
	 * @throws DownloadException
	 *            ダウンロード例外
	 * @throws IOException
	 *            IO例外
	 */
	public Map<String, List<RowDto>> selectList(ServiceDto serviceDto, UserSessionDto userSessionDto,
			List<String> tableNames) throws Exception {
		
		// ExcelダウンロードAPI呼出
		MasterDownloadResponseDto responseDto = downloadService.download(serviceDto, userSessionDto, tableNames);
		
		// エクセルファイル取出
		try (Workbook workbook = ExcelUtils.getExcelFromDownloadResponse(responseDto);) {
			return ExcelUtils.selectList(workbook, null, true);
		}
	}

	/**
	 * {@code entityListMap}のデータを更新または削除します。
	 * 
	 * @param serviceDto
	 *            サービスDTO
	 * @param userSessionDto
	 *            ユーザーセッションDTO
	 * @param entityListMap
	 *            ユーザーセッションDTO
	 * @return マスタアップロードレスポンス
	 * @throws DownloadException
	 *            ダウンロード例外
	 * @throws UploadException
	 *            アップロード例外
	 * @throws IOException
	 *            IO例外
	 * @throws RepoolException
	 *            再プール例外
	 */
	public MasterUploadResponseDto updateOrDelete(ServiceDto serviceDto, UserSessionDto userSessionDto,
			Map<String, List<RowDto>> entityListMap) throws Exception {
		return updateOrDelete(serviceDto, userSessionDto, entityListMap, true);
	}
	
	/**
	 * {@code entityListMap}のデータを更新または削除し、設定があれば再プールします。
	 * 
	 * @param serviceDto
	 *            サービスDTO
	 * @param userSessionDto
	 *            ユーザーセッションDTO
	 * @param entityListMap
	 *            ユーザーセッションDTO
	 * @param doRepool
	 *            再プールフラグ
	 * @return マスタアップロードレスポンス
	 * @throws DownloadException
	 *            ダウンロード例外
	 * @throws UploadException
	 *            アップロード例外
	 * @throws IOException
	 *            IO例外
	 * @throws RepoolException
	 *            再プール例外
	 */
	public MasterUploadResponseDto updateOrDelete(ServiceDto serviceDto, UserSessionDto userSessionDto,
			Map<String, List<RowDto>> entityListMap, boolean doRepool) throws Exception {
		
		MasterUploadResponseDto responseDto = null;

		// 更新と削除は１つのエクセルでアップロードできないため２つに分ける
		Map<String, List<RowDto>> updateListMap = new HashMap<>();
		Map<String, List<RowDto>> deleteListMap = new HashMap<>();
		
		for (Map.Entry<String, List<RowDto>> entity : entityListMap.entrySet()) {
			String targetColumn = masterHospitalMap.get(entity.getKey().toLowerCase());	// マスメンツールのdownload.json、master_hospital_column
			for (RowDto rowDto : entity.getValue()) {
				// 行ごとの削除フラグ判定
				if (rowDto.isDelete()) {
					if (!deleteListMap.containsKey(entity.getKey()))
						deleteListMap.put(entity.getKey(), new ArrayList<RowDto>());
					// 削除のときは必要なCellのみにする
					RowDto rowDtoPrimary = new RowDto();
					for (CellDto cell : rowDto.values()) {
						// PrimaryKeyのカラム
						if (cell.isPrimary()) {
							rowDtoPrimary.put(cell.getColumnName(), cell);
						}
						// 削除処理ではPrimaryKeyの他、マスメンツールのdownload.jsonに、master_hospital_columnで定義されているカラムも必要となります
						if (!StringUtils.isEmpty(targetColumn) && targetColumn.equals(cell.getColumnName().toLowerCase())) {
							rowDtoPrimary.put(cell.getColumnName(), cell);
						}
					}
					deleteListMap.get(entity.getKey()).add(rowDtoPrimary);
				} else {
					if (!updateListMap.containsKey(entity.getKey()))
						updateListMap.put(entity.getKey(), new ArrayList<RowDto>());
					updateListMap.get(entity.getKey()).add(rowDto);
				}
			}
		}
		
		List<String> tableNames = new ArrayList<String>(entityListMap.keySet());
		// エクセルのシートに定義するカラム名は対象テーブルをエクセルダウンロードして取得する
		Map<String, List<RowDto>> downloadSheetMap = selectList(serviceDto, userSessionDto, tableNames);	
		
		// 更新
		if (!CollectionUtils.isEmpty(updateListMap)) {
			responseDto = insertOrUpdate(serviceDto, userSessionDto, updateListMap, downloadSheetMap);
			if (responseDto.hasError()) {
				throw new UploadException("CMG999_E0001", new String[] { userSessionDto.getLoginUserId() }, "更新に失敗しました。user_id:%s");
			}
		}
		
		// 削除
		if (!CollectionUtils.isEmpty(deleteListMap)) {
			logger.log("ICMG0029", ThreadLocalUtils.getServiceDto().getGroupId(), ExcelUtils.expandDataMap(deleteListMap));
			//削除のときは、必要カラムのみ引き渡すため、全カラムを持つdownloadSheetMapは使用しない
			responseDto = createExcelAndUpload(serviceDto, userSessionDto, CodeConstants.UPLOAD_MODE_DELETE, deleteListMap, deleteListMap);
			if (responseDto.hasError()) {
				throw new UploadException("CMG999_E0001", new String[] { userSessionDto.getLoginUserId() }, "削除に失敗しました。user_id:%s");
			}
		}

		// キャッシュクリア
		if (doRepool)
			responseDto = repoolByTemplateConfig(serviceDto, userSessionDto, responseDto);
		
		return responseDto;
	}

	/**
	 * ダウンロードデータとマージして更新アップロードします。
	 * 
	 * @param serviceDto
	 *            サービスDTO
	 * @param userSessionDto
	 *            ユーザーセッションDTO
	 * @param entityListMap
	 *            データリストMap
	 * @return マスタアップロードレスポンス
	 * @throws Exception
	 *            各種例外
	 */
	public MasterUploadResponseDto insertOrUpdateWithDownLoad(ServiceDto serviceDto, UserSessionDto userSessionDto,
			Map<String, List<RowDto>> entityListMap)
			throws Exception {

		logger.log("ICMG0027", ThreadLocalUtils.getServiceDto().getGroupId(), ExcelUtils.expandDataMap(entityListMap));
		
		List<String> tableNames = new ArrayList<String>(entityListMap.keySet());
		
		// エクセルのシートに定義するカラム名は対象テーブルをエクセルダウンロードして取得する
		Map<String, List<RowDto>> downloadSheetMap = selectList(serviceDto, userSessionDto, tableNames);
		
		// 主キーが一致するデータはアップロードされたカラムだけ更新するようダウンロードデータとマージ
		entityListMap = createSheetMap(serviceDto, userSessionDto, entityListMap, downloadSheetMap);

		logger.log("ICMG0028", ThreadLocalUtils.getServiceDto().getGroupId(), ExcelUtils.expandDataMap(entityListMap));
		
		// エクセル変換およびアップロード
		return createExcelAndUpload(serviceDto, userSessionDto, CodeConstants.UPLOAD_MODE_UPDATE, entityListMap, downloadSheetMap);
	}
	
	/**
	 * ダウンロードデータとマージして更新アップロードします。
	 * 
	 * @param serviceDto
	 *            サービスDTO
	 * @param userSessionDto
	 *            ユーザーセッションDTO
	 * @param entityListMap
	 *            データリストMap
	 * @param downloadSheetMap
	 *            ダウンロードデータMap
	 * @return マスタアップロードレスポンス
	 * @throws DownloadException
	 *            ダウンロード例外
	 * @throws IOException
	 *            IO例外
	 * @throws UploadException 
	 *            アップロード例外
	 */
	public MasterUploadResponseDto insertOrUpdate(ServiceDto serviceDto, UserSessionDto userSessionDto,
			Map<String, List<RowDto>> entityListMap, Map<String, List<RowDto>> downloadSheetMap)
			throws DownloadException, IOException, UploadException {

		logger.log("ICMG0027", ThreadLocalUtils.getServiceDto().getGroupId(), entityListMap);
		
		// 主キーが一致するデータはアップロードされたカラムだけ更新するようダウンロードデータとマージ
		entityListMap = createSheetMap(serviceDto, userSessionDto, entityListMap, downloadSheetMap);

		logger.log("ICMG0028", ThreadLocalUtils.getServiceDto().getGroupId(), entityListMap);
		
		// エクセル変換およびアップロード
		return createExcelAndUpload(serviceDto, userSessionDto, CodeConstants.UPLOAD_MODE_UPDATE, entityListMap, downloadSheetMap);
	}
	
	/**
	 * 主キーを取得します。
	 * 
	 * @param dataSheetMap
	 * @return
	 */
	public Map<String, List<String>> getPrimarykeyMap(Map<String, List<RowDto>> dataSheetMap) {
		Map<String, List<String>> primarykeySheetMap = new HashMap<>();
		for (Map.Entry<String, List<RowDto>> entry : dataSheetMap.entrySet()) {
			List<String> primarykeyList = new ArrayList<>();
			if (CollectionUtils.isEmpty(entry.getValue())) {
				primarykeySheetMap.put(entry.getKey(), primarykeyList);
				continue;
			}
			RowDto headerRow = entry.getValue().get(0);
			primarykeyList = headerRow.entrySet().stream()
					.filter(c -> c.getValue().isPrimary())
					.map(c -> c.getValue().getColumnName())
					.collect(Collectors.toList());
			primarykeySheetMap.put(entry.getKey(), primarykeyList);
		}
		return primarykeySheetMap;
	}
		 
	/**
	 * データシートのMapを作成します。
	 * 
	 * @param serviceDto
	 * @param userSessionDto
	 * @param uploadSheetMap
	 * @param downloadSheetMap
	 * @return
	 * @throws DownloadException
	 * @throws IOException
	 */
	public Map<String, List<RowDto>> createSheetMap(ServiceDto serviceDto, UserSessionDto userSessionDto,
			Map<String, List<RowDto>> uploadSheetMap,
			Map<String, List<RowDto>> downloadSheetMap) throws DownloadException, IOException {
		
		Map<String, List<RowDto>> sheetMap = new HashMap<>();
		
		// 既存マスタの主キー取得
		Map<String, List<String>> primarykeyMap = getPrimarykeyMap(downloadSheetMap);
		// 既存マスタ有無チェック（無い場合は入力値をそのままアップロード）
		boolean isExistData = false;
		for (Map.Entry<String, List<String>> entry : primarykeyMap.entrySet()) {
			if (!CollectionUtils.isEmpty(entry.getValue())) {
				isExistData = true;
				break;
			}
		}
		if (!isExistData) {
			return uploadSheetMap;
		}
		
		// 主キーが一致するものはマージ。アップロードデータにカラムがあればアップロードの値を優先、カラムが無ければダウンロードデータを引き継ぐ
		for (Map.Entry<String, List<RowDto>> uploadSheet : uploadSheetMap.entrySet()) {
			List<RowDto> downloadRowList = downloadSheetMap.get(uploadSheet.getKey());
			List<RowDto> rowList = new ArrayList<>();
			List<String> primaryList = primarykeyMap.get(uploadSheet.getKey());
			
			// アップロードされたデータ行ごとにマージ
			for (Map<String, CellDto> uploadRow : uploadSheet.getValue()) {
				// カラム情報生成、アップロードデータから値のみコピー
				Map<String, RowDto> columnInfoMap = getColumnInfoMap(downloadSheetMap);
				RowDto row = columnInfoMap.get(uploadSheet.getKey());
				
				for (Map.Entry<String, CellDto> entry : row.entrySet()) {
					// アップロードされたカラムのみ値コピー（変数rowの中身は主キーも含め値がすべて空）
					if (uploadRow.containsKey(entry.getKey())) {
						row.get(entry.getKey()).setValue(uploadRow.get(entry.getKey()).getValue());
					}
				}

				// 主キーに値を持つ行か判定
				boolean hasPrimarykeyRow = false;
				for (Map.Entry<String, CellDto> cell : uploadRow.entrySet()) {
					if (cell.getValue().isPrimary() && StringUtils.isNotEmpty(cell.getValue().getValue())) {
						hasPrimarykeyRow = true;
						break;
					}
				}

				/**
				 * 主キーに値を持つ行の場合は一致するダウンロードデータとマージする。
				 * 1) 一致するデータが無い場合はアップロードデータをそのまま使用。
				 * 2) 複合キーで部分的にキーが空のデータはそのままアップロードされるがjar側で捨てられる。
				 */
				if (hasPrimarykeyRow) {
					for (Map<String, CellDto> downloadRow : downloadRowList) {
						boolean isMatchPrimarykey = false;
						// 主キーが複合キーである場合を想定し、主キーカラムの値の全ての一致の判定
						for (String primarykeyName : primaryList) {
							isMatchPrimarykey = StringUtils.isNotEmpty(uploadRow.get(primarykeyName).getValue()) 
									&& StringUtils.isNotEmpty(downloadRow.get(primarykeyName).getValue()) 
									&& StringUtils.equals(uploadRow.get(primarykeyName).getValue(), downloadRow.get(primarykeyName).getValue());
							if (!isMatchPrimarykey) break;
						}
						// 主キーが一致する場合はダウンロードデータをベースにする。
						if (isMatchPrimarykey) {
							row = new RowDto();
							for (Map.Entry<String, CellDto> downloadData : downloadRow.entrySet()) {
								CellDto dto = downloadData.getValue().clone();
								row.put(downloadData.getKey(), dto);
							}
							break;
						}
					}
					// アップロードされたカラムの値のみ上書きする
					for (Map.Entry<String, CellDto> uploadData : uploadRow.entrySet()) {
						row.put(uploadData.getKey(), uploadData.getValue().clone());
					}					
				}
				
				rowList.add(row);
			}
			
			sheetMap.put(uploadSheet.getKey(), rowList);
		}
		
		return sheetMap;
	}
	
	/**
	 * シートごとのカラム情報のみ格納されたMapを取得します。
	 * 
	 * @param dataSheetMap
	 * @return
	 */
	public Map<String, RowDto> getColumnInfoMap(Map<String, List<RowDto>> dataSheetMap) {
		Map<String, RowDto> columnInfoMap = new HashMap<>();
		for (Map.Entry<String, List<RowDto>> entry : dataSheetMap.entrySet()) {
			RowDto row1 = entry.getValue().get(0);
			RowDto rowMap = new RowDto();
			// 1行目の値をクリアしてカラム情報のみ格納されたMap作成
			for (Map.Entry<String, CellDto> column : row1.entrySet()) {
				CellDto dto = column.getValue().clone();
				dto.setValue(null);
				rowMap.put(dto.getColumnName(), dto);
			}
			columnInfoMap.put(entry.getKey(), rowMap);
		}
		return columnInfoMap;
	}	
		 
	/**
	 * エクセルを作成してアップロードします。
	 * 
	 * @param serviceDto
	 * @param userSessionDto
	 * @param mode
	 * @param entityListMap
	 * @param downloadSheetMap
	 * @return
	 * @throws UploadException
	 * @throws IOException
	 */
	public MasterUploadResponseDto createExcelAndUpload(ServiceDto serviceDto,
			UserSessionDto userSessionDto,
			String mode,
			Map<String, List<RowDto>> entityListMap, 
			Map<String, List<RowDto>> downloadSheetMap) throws UploadException, IOException {
		
		try (Workbook excel = ExcelUtils.convertTableMapToExcel(entityListMap, downloadSheetMap);
				ByteArrayOutputStream bos = new ByteArrayOutputStream();) {
			excel.write(bos);
			byte[] bytes = bos.toByteArray();
			return uploadService.upload(serviceDto, userSessionDto, mode, bytes);
		}
	}
	
	/**
	 * テンプレートマスタ設定による再プール
	 * 
	 * @param serviceDto
	 * @param userSessionDto
	 * @param prevReponseDto
	 * @throws RepoolException
	 */
	public MasterUploadResponseDto repoolByTemplateConfig(ServiceDto serviceDto,
			UserSessionDto userSessionDto, MasterUploadResponseDto prevReponseDto) {
		// キャッシュクリア
		MTemplate mTemplate = mTemplateBhv.selectByPKValue(userSessionDto.getTemplateSeqCached());
		if (mTemplate == null || !StringUtils.equals(mTemplate.getRepoolFlag(), AppConstants.REPOOL_ON)) {
			return prevReponseDto;
		}
		
		MasterUploadResponseDto responseDto = new MasterUploadResponseDto();
		try {
			MCategory mCategory = mCategoryBhv.selectByServiceId(serviceDto.getServiceId());			
			RepoolModel repoolModel = new RepoolModel();
			repoolModel.setSelectRepoolApi(mCategory.getRepoolApiPath());
			repoolModel.setSelectRepoolLabel(mCategory.getCategoryLabel() + "キャッシュクリア");
			repoolModel.setSelectRepoolMethod(mCategory.getRepoolApiMethod());
			repoolService.repool(serviceDto, userSessionDto, repoolModel);
			responseDto.setResult(CodeConstants.RESULT_OK);
		} catch (RepoolException e) {
			responseDto.setResult(AppConstants.RESULT_REPOOL_ERROR);
			MasterUploadDetailDto detailDto = new MasterUploadDetailDto();
			detailDto.setError(true);
			detailDto.setMessage(e.getMessage());
			responseDto.setDetails(Arrays.asList(detailDto));
		}
		
		return responseDto;
	}

}
