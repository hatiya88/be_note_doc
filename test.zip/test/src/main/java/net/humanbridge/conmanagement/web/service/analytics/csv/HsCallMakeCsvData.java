package net.humanbridge.conmanagement.web.service.analytics.csv;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.fjqs.f2.springboot.logger.basic.F2Logger;
import lombok.val;
import net.humanbridge.conmanagement.constant.AnalyticsConstants;
import net.humanbridge.conmanagement.util.MiscUtils;
import net.humanbridge.conmanagement.web.dbflute.exbhv.TDataAnalyticsSumCntHsCallBhv;
import net.humanbridge.conmanagement.web.dbflute.exentity.MDataAnalyticsCsvPattern;
import net.humanbridge.conmanagement.web.dbflute.exentity.TDataAnalyticsSumCntHsCall;
import net.humanbridge.conmanagement.web.exception.CsvException;
import net.humanbridge.conmanagement.web.service.analytics.graph.HsCallMakeGraphData;

/**
 * 診察状況お知らせ（Hospision)のCSVデータ作成
 * @author xonogawa.koichi
 *
 */
@Service("Csv_" + AnalyticsConstants.HS_CALL)
public class HsCallMakeCsvData extends AbstractMakeCsvData<TDataAnalyticsSumCntHsCall> {

	/** イベントロガー */
	private static final F2Logger logger = F2Logger.getLogger();

	@Autowired
	private TDataAnalyticsSumCntHsCallBhv sumCntHsCallBhv;
	
	@Autowired
	private HsCallMakeGraphData hsCallMakeGraphData;

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected String getServiceKind() {
		return AnalyticsConstants.HS_CALL;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Map<String, Long> searchPattern1(String groupId, Date fromDate, Date toDate, String deptCode, String sortColumns, String unit, int fetchAmount) {
		return this.sumCntHsCallBhv.getTDataAnalyticsSumCntHsCallForCsvPattern1(groupId, fromDate, toDate, deptCode, sortColumns, unit, fetchAmount);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void searchPattern2(String groupId, Date fromDate, Date toDate, String deptCode, MDataAnalyticsCsvPattern mDataAnalyticsCsvPattern, String deptListJson, ServletOutputStream outputStream, int fetchAmount) throws IOException {
		this.sumCntHsCallBhv.getTDataAnalyticsSumCntHsCallForCsvPattern2(groupId, fromDate, toDate, deptCode, mDataAnalyticsCsvPattern, deptListJson, outputStream, fetchAmount);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Map<String, Long> groupingData(List<TDataAnalyticsSumCntHsCall> data, String unit, Map<String, Long> groupByHsCallMap) {
		return this.hsCallMakeGraphData.groupingTDataAnalyticsSumCntHsCallData(data, unit, groupByHsCallMap);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void makeCsv(String groupId, List<TDataAnalyticsSumCntHsCall> data, String targetColumns, String deptListJson, ServletOutputStream outputStream) {
		val format = this.getDateFormat();
		val deptMap = this.getDeptMap(deptListJson);

		try {
			// 明細行
			val targetColumn = targetColumns.split(",");
			for (val sumCntHsCall: data) {
				val lineData = new ArrayList<String>();
				// 出力項目をCSVパターンマスタに設定された順にセットする
				for (String column: targetColumn) {
					switch (column.trim()) {
						case "seq":
							lineData.add(sumCntHsCall.getSeq().toString());
							break;
						case "group_id":
							lineData.add(MiscUtils.defaultIfNull(sumCntHsCall.getGroupId()));
							break;
						case "execute_time":
							String executeTime = "";
							if (sumCntHsCall.getExecuteTime() != null) {
								executeTime = format.format(sumCntHsCall.getExecuteTime());
							}
							lineData.add(executeTime);
							break;
						case "dept_code":
							lineData.add(deptMap.getOrDefault(MiscUtils.defaultIfNull(sumCntHsCall.getDeptCode()), ""));
							break;
						case "patient_id":
							lineData.add(MiscUtils.defaultIfNull(sumCntHsCall.getPatientId()));
							break;
						case "up_date":
							String upDate = "";
							if (sumCntHsCall.getUpDate() != null) {
								upDate = format.format(sumCntHsCall.getUpDate());
							}
							lineData.add(upDate);
							break;
					}
				}
				String byteData = '"' + String.join('"' + "," + '"', lineData) + '"' + AnalyticsConstants.LINE_SEPARATOR;
				outputStream.write(byteData.getBytes("MS932"));
			}

		} catch (IOException e) {
			logger.log("ECMG0103", e, e.getMessage());
			throw new CsvException(e.getMessage());
		}
	}
}
