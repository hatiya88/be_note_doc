package net.humanbridge.conmanagement.web.service.analytics.csv;

import static net.humanbridge.conmanagement.web.dbflute.exbhv.MDataAnalyticsCsvPatternBhv.SEARCH_PERIOD_TYPE_PERIOD_OFF;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.ServletOutputStream;

import org.apache.commons.lang3.StringUtils;
import org.seasar.dbflute.dbmeta.AbstractEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.fjqs.f2.springboot.logger.basic.F2Logger;
import lombok.val;
import net.humanbridge.conmanagement.constant.AnalyticsConstants;
import net.humanbridge.conmanagement.web.dbflute.exentity.MDataAnalyticsCsvPattern;
import net.humanbridge.conmanagement.web.dto.UserSessionDto;
import net.humanbridge.conmanagement.web.dto.analytics.DepartmentDto;
import net.humanbridge.conmanagement.web.dto.analytics.SearchItemDto;
import net.humanbridge.conmanagement.web.exception.CsvException;
import net.humanbridge.conmanagement.web.service.analytics.AnalyticsService;
/**
 * CSVデータ作成の抽象クラス
 * @author xonogawa.koichi
 *
 */
public abstract class AbstractMakeCsvData<T extends AbstractEntity> implements IMakeCsvData {

	private static final ObjectMapper mapper = new ObjectMapper();

	/** イベントロガー */
	private static final F2Logger logger = F2Logger.getLogger();

	@Autowired
	private Environment environment;

	@Autowired
	AnalyticsService analyticsService;
	
	/**
	 * {@inheritDoc}
	 */
	public void getCsvData(UserSessionDto userSessionDto, Date fromDate, Date toDate, SearchItemDto searchItemDto, MDataAnalyticsCsvPattern mDataAnalyticsCsvPattern, String deptListJson, ServletOutputStream outputStream) {

		try {
			val groupId = this.getSearchTargetGroupId(userSessionDto);

			if (SEARCH_PERIOD_TYPE_PERIOD_OFF.equals(mDataAnalyticsCsvPattern.getSearchPeriodType())) {
				// 日時を検索条件に含めない
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
				try {
					fromDate = sdf.parse("1900/01/01");
					toDate = sdf.parse("9999/12/31");
				} catch (ParseException e) {
					// 固定値を変換しているのでエラーにはならない
					logger.log("ECMGC0001", "日付変換エラー", e.getMessage());
					throw new CsvException("日付変換エラー");
				}
			}

			// パターン①
			// 集計値をCSV出力する
			if (StringUtils.isEmpty(mDataAnalyticsCsvPattern.getTargetTable())) {
				val data = this.searchPattern1(groupId, fromDate, toDate, searchItemDto.getSelectDepertment(), mDataAnalyticsCsvPattern.getSort(), searchItemDto.getSelectUnit(), userSessionDto.getMDataAnalyticsGrpGeneralConfig().getFetchAmount());
				if (data.isEmpty()) {
					throw new CsvException("CSV出力対象が0件です。", data.size());
				}
				this.makeCsvDefaultPattern(data, fromDate, toDate, searchItemDto, outputStream);
				return;
			}

			// パターン①以外
			// 取得したデータをCSV出力する
			this.searchPattern2(groupId, fromDate, toDate, searchItemDto.getSelectDepertment(), mDataAnalyticsCsvPattern, deptListJson, outputStream, userSessionDto.getMDataAnalyticsGrpGeneralConfig().getFetchAmount());
			outputStream.close();
			return;

		} catch (CsvException e) {
			throw new CsvException(e.getMessage(), e.getCount());
			
		} catch (Exception e) {
			logger.log("ECMG0103", e, e.getMessage());
			throw new CsvException("CSV出力に失敗しました。");
		}
	}

	/**
	 * サービス取得を取得します。
	 * 
	 * @return サービス種別
	 */
	protected abstract String getServiceKind();
	
	/**
	 * CSVに出力するデータを検索します。
	 * パターン１（集計値を出力する）ときに使用します
	 * 
	 * @param groupId
	 * @param fromDate
	 * @param toDate
	 * @param deptCode
	 * @param sortColumns
	 * @return 検索結果
	 */
	protected abstract Map<String, Long> searchPattern1(String groupId, Date fromDate, Date toDate, String deptCode, String sortColumns, String unit, int fetchAmount);

	/**
	 * CSVに出力するデータを検索します。
	 * パターン２（取得値を出力する）ときに使用します
	 * 
	 * @param groupId
	 * @param fromDate
	 * @param toDate
	 * @param deptCode
	 * @param mDataAnalyticsCsvPattern
	 * @return 検索結果
	 */
	protected abstract void searchPattern2(String groupId, Date fromDate, Date toDate, String deptCode, MDataAnalyticsCsvPattern mDataAnalyticsCsvPattern, String deptListJson, ServletOutputStream outputStream, int fetchAmount) throws IOException;

	/**
	 * データを集計単位でグルーピングします。
	 * @param data データ
	 * @param unit 単位
	 * @return グルーピング結果
	 */
	protected abstract Map<String, Long> groupingData(List<T> data, String unit, Map<String, Long> groupByMap);
	
	/**
	 * パターン①以外のCSVデータを作成します。
	 * 
	 * @param groupId
	 * @param data
	 * @param targetColumns
	 * @param columnsHeadNames
	 * @param deptListJson
	 */
	protected abstract void makeCsv(String groupId, List<T> data, String targetColumns, String deptListJson, ServletOutputStream outputStream);
	
	/**
	 * CSV出力用日付フォーマットを取得します。
	 * 
	 * @return 日付フォーマット
	 */
	protected  SimpleDateFormat getDateFormat() {
		return new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	}
	
	/**
	 * グルーピングフォーマットを取得します。
	 * 
	 * @param unit
	 * @return グルーピングフォーマット
	 */
	protected String getGroupingFormat(String unit) {
		switch (unit) {
		case AnalyticsConstants.UNIT_HOUR:
			// 日時で集計
			return "HH";
		case AnalyticsConstants.UNIT_DAY:
			// 日にちで集計
			return "yyyyMMdd";
		case AnalyticsConstants.UNIT_MONTH:
			// 年月で集計
			return "yyyyMM";
		default:
			return "";
		}
	}
	
	/**
	 * 診療科コードと名称のマップを取得します。
	 * 
	 * @param deptListJson 診療科一覧のJSON文字列
	 * @return 診療科コードと名称のマップ
	 */
	protected Map<String, String> getDeptMap(String deptListJson) {
		try {
			return Arrays.asList(mapper.readValue(deptListJson, DepartmentDto[].class)).stream()
				.collect(Collectors.toMap(p -> p.getDeptCode(), p -> p.getDeptName()));
		} catch (JsonParseException e) {
			logger.log("WCMG0102", deptListJson, e, e.getMessage());
			throw new CsvException(e.getMessage());

		} catch (JsonMappingException e) {
			logger.log("WCMG0102", deptListJson, e, e.getMessage());
			throw new CsvException(e.getMessage());

		} catch (IOException e) {
			logger.log("ECMG0103", e, e.getMessage());
			throw new CsvException(e.getMessage());
		}
	}
	
	/**
	 * application.properties のキーの接頭語を取得します。
	 * 
	 * @return 接頭語
	 */
	private String getAppPropKeyPrefix() {
		return AnalyticsConstants.CONCIERGE_ANALYTIES + "." + this.getServiceKind().toLowerCase();
	}
	
	/**
	 * グラフタイトルを取得します。
	 * 
	 * @return グラフタイトル
	 */
	private String getGraphTitle() { 
		return this.environment.getRequiredProperty(this.getAppPropKeyPrefix() + AnalyticsConstants.GRAPH_TITLE);
	}
	
	/**
	 * サービス種別から、検索対象テーブルの検索値となるグループIDを取得します。
	 * 
	 * @param userSessionDto
	 * @return グループID
	 */
	private String getSearchTargetGroupId(UserSessionDto userSessionDto) {
		val appPropKeyPrefix = this.getAppPropKeyPrefix();
		// サービス種別ごとのグループID種別
		val serviceType = this.environment.getRequiredProperty(appPropKeyPrefix + AnalyticsConstants.SERVICE_ID_TYPE);
		
		switch (serviceType) {
			case "1": // 契約グループID
				return userSessionDto.getGroupId();
			case "2": // 連携グループID
				return userSessionDto.getProviderGroupIdMap().get(userSessionDto.getGroupId());
			case "3": // 子サービスグループID
				val serviceId = environment.getRequiredProperty(appPropKeyPrefix + AnalyticsConstants.SERVICE_ID);
				return userSessionDto.getChildGroupIdMap().get(serviceId);
			default:
				return "";
		}
	}

	/**
	 * パターン①のCSVデータを作成します。
	 * 
	 * @param data
	 * @param fromDate
	 * @param toDate
	 * @param searchItemDto
	 */
	private void makeCsvDefaultPattern(Map<String, Long> data, Date fromDate, Date toDate, SearchItemDto searchItemDto, ServletOutputStream outputStream) {
		val groupByList = new ArrayList<Map<String, Long>>();
		groupByList.add(data);
		val graphDataList = analyticsService.getGraphDataListArrange(searchItemDto, groupByList, fromDate, toDate);

		try {
			// CSVデータ作成
			// ヘッダー行
			val columnsHeadName = new String[] {analyticsService.getUnitTitle(searchItemDto.getSelectUnit()), this.getGraphTitle()};
			String byteData ='"' + String.join('"' + "," + '"', columnsHeadName) + '"' + AnalyticsConstants.LINE_SEPARATOR;
			outputStream.write(byteData.getBytes("MS932"));

			// 明細行
			for(val entry : graphDataList.get(0).getData().entrySet()) {
				val lineData = new ArrayList<String>();
				lineData.add('"' + analyticsService.getFormatGroupDateForCsv(searchItemDto, entry.getKey().toString()) + '"');
				lineData.add('"' + entry.getValue().toString() + '"');
				byteData = String.join(",", lineData) + AnalyticsConstants.LINE_SEPARATOR;
				outputStream.write(byteData.getBytes("MS932"));
			}
			outputStream.close();

		} catch (IOException e) {
			logger.log("ECMG0103", e, e.getMessage());
			throw new CsvException(e.getMessage());
		}
	}
}
