package net.humanbridge.conmanagement.web.service;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.humanbridge.conmanagement.external.call.MasterDownloadApiCall;
import net.humanbridge.conmanagement.external.exception.MaintenanceApiCallException;
import net.humanbridge.conmanagement.web.dto.UserSessionDto;
import net.humanbridge.conmanagement.web.dto.UserSessionDto.ServiceDto;
import net.humanbridge.conmanagement.web.exception.DownloadException;
import net.humanbridge.conmanagement.web.exception.ServiceException;
import net.humanbridge.maintenance.api.rest.dto.response.MasterDownloadResponseDto;

/**
 * ダウンロードサービス
 */
@Service
public class DownloadService {

	@Autowired
	private MasterDownloadApiCall masterDownloadApiCall;

	/**
	 * マスタを保持しているREST側に問い合わせて、マスタをダウンロードします。
	 * 
	 * @param serviceDto
	 * @param userSessionDto
	 * @param masterNames
	 * @return ダウンロード情報(execl含む)
	 * @throws ServiceException
	 * @throws DownloadException 
	 */
	public MasterDownloadResponseDto download(ServiceDto serviceDto, UserSessionDto userSessionDto, List<String> masterNames) throws DownloadException {
		MasterDownloadResponseDto downloadResponseDto;
		try {
			downloadResponseDto = masterDownloadApiCall.call(serviceDto, userSessionDto, masterNames);
		} catch (MaintenanceApiCallException e) {
			throw new DownloadException(
				"MST005_E0003",
				new String[] { serviceDto.getContractGroupId(), serviceDto.getServiceId(), StringUtils.join(masterNames, ",") },
				"マスタのダウンロードに失敗しました。groupId:%s service:%s masters:%s", e);
		}
		return downloadResponseDto;
	}
	 
}
