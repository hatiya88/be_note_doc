package net.humanbridge.conmanagement.totp.model;

import lombok.Data;

@Data
/**
 * 二要素認証モデル
 */
public class AuthenticationModel {

	/** 認証コード */
	private String optCode;
}
