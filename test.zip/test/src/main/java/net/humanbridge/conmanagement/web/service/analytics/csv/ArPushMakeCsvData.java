package net.humanbridge.conmanagement.web.service.analytics.csv;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.ServletOutputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.fjqs.f2.springboot.logger.basic.F2Logger;
import lombok.val;
import net.humanbridge.conmanagement.constant.AnalyticsConstants;
import net.humanbridge.conmanagement.util.MiscUtils;
import net.humanbridge.conmanagement.web.dbflute.exbhv.TDataAnalyticsRuleBhv;
import net.humanbridge.conmanagement.web.dbflute.exbhv.TDataAnalyticsSumCntArPushBhv;
import net.humanbridge.conmanagement.web.dbflute.exentity.MDataAnalyticsCsvPattern;
import net.humanbridge.conmanagement.web.dbflute.exentity.TDataAnalyticsSumCntArPush;
import net.humanbridge.conmanagement.web.exception.CsvException;
import net.humanbridge.conmanagement.web.service.analytics.graph.ArPushMakeGraphData;

/**
 * アラートリマインドのCSVデータ作成クラス
 * @author xonogawa.koichi
 *
 */
@Service("Csv_" + AnalyticsConstants.AR_PUSH)
public class ArPushMakeCsvData extends AbstractMakeCsvData<TDataAnalyticsSumCntArPush> {
	
	/** イベントロガー */
	private static final F2Logger logger = F2Logger.getLogger();
	
	@Autowired
	private TDataAnalyticsSumCntArPushBhv sumCntArPushBhv;
	
	@Autowired
	private TDataAnalyticsRuleBhv ruleBhv;
	
	@Autowired
	private ArPushMakeGraphData arPushMakeGraphData;
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	protected String getServiceKind() {
		return AnalyticsConstants.AR_PUSH;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Map<String, Long> searchPattern1(String groupId, Date fromDate, Date toDate, String deptCode, String sortColumns, String unit, int fetchAmount) {
		return this.sumCntArPushBhv.getTDataAnalyticsSumCntArPushForCsvPattern1(groupId, fromDate, toDate, sortColumns, unit, fetchAmount);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void searchPattern2(String groupId, Date fromDate, Date toDate, String deptCode, MDataAnalyticsCsvPattern mDataAnalyticsCsvPattern, String deptListJson, ServletOutputStream outputStream, int fetchAmount) throws IOException {
		this.sumCntArPushBhv.getTDataAnalyticsSumCntArPushForCsvPattern2(groupId, fromDate, toDate, mDataAnalyticsCsvPattern, deptListJson, outputStream, fetchAmount);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Map<String, Long> groupingData(List<TDataAnalyticsSumCntArPush> data, String unit, Map<String, Long> groupByArPushMap) {
		return this.arPushMakeGraphData.groupingTDataAnalyticsSumCntArPush(data, unit, groupByArPushMap);
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void makeCsv(String groupId, List<TDataAnalyticsSumCntArPush> data, String targetColumns, String deptListJson, ServletOutputStream outputStream) {
		val format = this.getDateFormat();
		val ruleMap = this.ruleBhv.getTDataAnalyticsRuleForCsv(groupId).stream()
			.collect(Collectors.toMap(p -> p.getRuleId(), p -> p.getRuleName()));

		try {
			//明細行
			val targetColumn = targetColumns.split(",");
			for(val sumCntArPush: data) {
				val lineData = new ArrayList<String>();
				//出力項目をパターンマスタに設定された順にセットする。
				for(val column: targetColumn) {
					switch(column.trim()) {
						case "seq":
							lineData.add(sumCntArPush.getSeq().toString());
							break;
						case "group_id":
							lineData.add(MiscUtils.defaultIfNull(sumCntArPush.getGroupId()));
							break;
						case "execute_time":
							String executeTime = "";
							if (sumCntArPush.getExecuteTime() != null) {
								executeTime = format.format(sumCntArPush.getExecuteTime());
							}
							lineData.add(executeTime);
							break;
						case "patient_id":
							lineData.add(MiscUtils.defaultIfNull(sumCntArPush.getPatientId()));
							break;
						case "rule_id":
							val ruleId = MiscUtils.defaultIfNull(sumCntArPush.getRuleId());
							lineData.add(ruleId);
							lineData.add(ruleMap.getOrDefault(ruleId, ""));
							break;
						case "up_date":
							String upDate = "";
							if (sumCntArPush.getUpDate() != null) {
								upDate = format.format(sumCntArPush.getUpDate());
							}
							lineData.add(upDate);
							break;
						}
				}
				String byteData = '"' + String.join('"' + "," + '"', lineData) + '"' + AnalyticsConstants.LINE_SEPARATOR;
				outputStream.write(byteData.getBytes("MS932"));
			}

		} catch (IOException e) {
			logger.log("ECMG0103", e, e.getMessage());
			throw new CsvException(e.getMessage());
		}
	}
}
