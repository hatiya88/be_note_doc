package net.humanbridge.conmanagement.web.service.analytics.graph;

/**
 * グラフ作成FactoryクラスのInterFace
 * @author xonogawa.koichi
 *
 */
public interface IMakeGraphDataFactory {

	/**
	 * @see IMakeGraphData の具象クラスを生成して返します。
	 * 
	 * @param serviceKind サービス種別
	 * @return @see IGraphData の具象クラス
	 */
	IMakeGraphData create(String serviceKind);
}
