package net.humanbridge.conmanagement.web.service.analytics.graph;

import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.humanbridge.conmanagement.constant.AnalyticsConstants;
import net.humanbridge.conmanagement.web.dbflute.exbhv.TDataAnalyticsSumCntHsCallBhv;
import net.humanbridge.conmanagement.web.dbflute.exentity.TDataAnalyticsSumCntHsCall;

/**
 * 診察状況お知らせ（Hospision)のグラフデータ作成
 * @author xonogawa.koichi
 *
 */
@Service("Graph_" + AnalyticsConstants.HS_CALL)
public class HsCallMakeGraphData extends AbstractMakeGraphData {

	@Autowired
	TDataAnalyticsSumCntHsCallBhv tDataAnalyticsSumCntHsCallBhv;

	/**
	 * 診察状況お知らせ（Hospision)のグラフデータ作成
	 * @param searchTargetGroupId
	 * @param fromDate
	 * @param toDate
	 * @param unit
	 * @param deptCode
	 * @return
	 */
	public List<Map<String, Long>> getGraphData(String searchTargetGroupId, Date fromDate, Date toDate, String unit, String deptCode, int fetchAmount) {
		// データ取得し、集計単位に合わせてグルーピングする
		Map<String, Long> groupByHsCallMap =tDataAnalyticsSumCntHsCallBhv.getTDataAnalyticsSumCntHsCall(searchTargetGroupId, fromDate, toDate, deptCode, unit, fetchAmount);
		List<Map<String, Long>> groupByList = new ArrayList<Map<String, Long>>();
		groupByList.add(groupByHsCallMap);
		return groupByList;
	}

	/**
	 * 集計単位でGroupingする
	 * @param tDataAnalyticsSumCntHsCall
	 * @param unit
	 * @return
	 */
	public Map<String, Long> groupingTDataAnalyticsSumCntHsCallData(List<TDataAnalyticsSumCntHsCall> tDataAnalyticsSumCntHsCallList, String unit, Map<String, Long> groupByHsCallMap) {
		Map<String, Long> newGroupByHsCallMap = new LinkedHashMap<String, Long>();
		Map<String, Long> margeGroupByHsCallMap = new LinkedHashMap<String, Long>();

		if (!tDataAnalyticsSumCntHsCallList.isEmpty()) {
			SimpleDateFormat yearMonthFormat = new SimpleDateFormat(getGroupingFormat(unit));
			newGroupByHsCallMap = tDataAnalyticsSumCntHsCallList.stream()
					.collect(Collectors.groupingBy(p -> yearMonthFormat.format(p.getExecuteTime()), Collectors.counting()));
		}
		// 今回取得データからMapへ
		for (String key : newGroupByHsCallMap.keySet()) {
			margeGroupByHsCallMap.put(key, newGroupByHsCallMap.getOrDefault(key, 0L));
		}
		// 前回取得分を加算する
		for (String key : groupByHsCallMap.keySet()) {
			margeGroupByHsCallMap.put(key, groupByHsCallMap.getOrDefault(key, 0L) + newGroupByHsCallMap.getOrDefault(key, 0L));
		}
		return margeGroupByHsCallMap;
	}
}
