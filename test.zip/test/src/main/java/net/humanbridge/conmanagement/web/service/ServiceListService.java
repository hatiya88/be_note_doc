package net.humanbridge.conmanagement.web.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import jp.co.fjqs.f2.springboot.logger.basic.F2Logger;
import net.humanbridge.conmanagement.constant.AppConstants;
import net.humanbridge.conmanagement.portal.call.ChildServiceGroupIdListApiCall;
import net.humanbridge.conmanagement.portal.dxo.request.ChildServiceGroupIdListApiRequestDxo;
import net.humanbridge.conmanagement.portal.dxo.response.ChildServiceGroupIdListApiResponseDxo;
import net.humanbridge.conmanagement.portal.mapper.ChildServiceGroupId;
import net.humanbridge.conmanagement.util.AppUtils;
import net.humanbridge.conmanagement.util.ThreadLocalUtils;
import net.humanbridge.conmanagement.web.dbflute.exbhv.MCategoryBhv;
import net.humanbridge.conmanagement.web.dbflute.exentity.MCategory;
import net.humanbridge.conmanagement.web.dto.ServiceRowDto;
import net.humanbridge.conmanagement.web.dto.UserSessionDto.HospitalConfig;
import net.humanbridge.conmanagement.web.exception.ServiceException;

/**
 * サービス一覧取得サービス
 */
@Service
public class ServiceListService {

	private static final F2Logger logger = F2Logger.getLogger();

	@Autowired
	private ChildServiceGroupIdListApiCall childServiceGroupIdListApiCall;

	@Autowired
	private MCategoryBhv mCategoryBhv;

	@Autowired
	private Environment environment;

	/** コンシェルジュサービスID */
	@Value("${concierge.service-id}")
	private String conciergeServiceId;

	/** 共通グループのグループID */
	@Value("${common-group-id}")
	private String commonGroupId;

	/** 予約語名：gateway-url */
	private static final String RESERVED_GATEWAY_URL = "gateway-url";

	/** 予約語＋コンテキストパスパターン：^(\$\{[^\}]+\})/([^/]+)/? */
	private static final Pattern PATTERN_GATEWAY_URL = Pattern.compile("^(\\$\\{[^\\}]+\\})/([^/]+)/?");

	/**
	 * ポータルのサービスマスタからグループ一覧を取得します。
	 *
	 * @param contractGroupId
	 *            契約グループID（コンシェルジュのグループID）
	 * @return 取得結果一覧
	 * @throws ServiceException サービス一覧取得エラー
	 */
	public List<ServiceRowDto> search(String contractGroupId) throws ServiceException {
		List<ServiceRowDto> resultList = new ArrayList<>();

		// コンシェルジュの子サービスID・グループIDマップ（key:サービスID，value:グループID）
		Map<String, String> serviceIdGroupIdMap = new HashMap<>();

		// true：共通グループ選択，false：病院選択
		boolean commonGroupMode = true;

		/* 共通グループ以外の病院を選択時 */
		if (ObjectUtils.notEqual(contractGroupId, commonGroupId)) {
			commonGroupMode = false;

			/** サービス一覧取得パラメータ **/
			ChildServiceGroupIdListApiRequestDxo requestDxo = new ChildServiceGroupIdListApiRequestDxo();
			requestDxo.setContractGroupId(contractGroupId);		// 契約グループID

			/** コンシェルジュ配下サービス・グループ一覧取得API呼び出し **/
			ChildServiceGroupIdListApiResponseDxo responseDxo = childServiceGroupIdListApiCall.call(requestDxo);

			/** レスポンスチェック **/
			int status = responseDxo.getPortalhttpResponse().responseCode;
			if (status != HttpStatus.OK.value()
			 || responseDxo.getChildServiceGroupIdMapper() == null
			 || responseDxo.getChildServiceGroupIdMapper().getChildServiceGroupIds() == null) {
				logger.log("ICMG0019", contractGroupId, status);
				throw new ServiceException("CMG003_E1001", new String[] { contractGroupId }, "サービス・グループ一覧情報の取得に失敗しました。契約グループID:%s");
			}

			// サービスID・グループID一覧
			List<ChildServiceGroupId> ChildServiceGroupIdList = responseDxo.getChildServiceGroupIdMapper().getChildServiceGroupIds();
			logger.log("ICMG0018", ChildServiceGroupIdList.size());						// サービス一覧情報取得結果（全件数）

			/** サービスID、マスタメンテナンス対象サービスの病院グループIDのマップを作成 **/
			// 対象サービスの病院グループIDをサービスIDに紐づける
			for (ChildServiceGroupId ChildServiceGroupId : ChildServiceGroupIdList) {
				F2Logger.getLogger(this.getClass()).debug("サービス・グループ情報詳細：" + AppUtils.dumpObject(ChildServiceGroupId));
				serviceIdGroupIdMap.put(ChildServiceGroupId.getServiceId(), ChildServiceGroupId.getGroupId());
			}
		}

		/** カテゴリーマスタ取得 (共通グループを選択時は、全て取得) **/
		List<String> serviceIdList = new ArrayList<>(serviceIdGroupIdMap.keySet());		// 共通グループを選択時は、空リスト（全検索）
		List<MCategory> mCategoryList = mCategoryBhv.findByServiceId(serviceIdList);
		logger.log("ICMG0021", mCategoryList.size()); 									// カテゴリーマスタ一覧情報取得結果（全件数）

		/** 汎用マスタ取得 */
		HospitalConfig hospitalConfig = ThreadLocalUtils.getHospitalConfig();
		
		/** 取得結果リストの作成 **/
		for (MCategory mCategory : mCategoryList) {
			if (!hospitalConfig.isAuthorizedSerivce(mCategory.getServiceId())) { // 使用可能なサービスとしてマスタ設定されているか判定
				continue;
			}
			try {
				F2Logger.getLogger(this.getClass()).debug("カテゴリーマスタ情報詳細：" + mCategory);
				ServiceRowDto serviceDto = new ServiceRowDto();
				serviceDto.setCategorySeq(mCategory.getCategorySeq());															// シーケンス
				serviceDto.setGroupId(getHospitalGroupId(commonGroupMode, mCategory, serviceIdGroupIdMap, contractGroupId));	// 病院グループID
				serviceDto.setServiceId(mCategory.getServiceId());																// 子サービスID
				serviceDto.setServiceLabel(mCategory.getCategoryLabel());														// 子サービス名
				serviceDto.setServiceUrl(replaceServiceUrl(mCategory.getServiceUrl()));											// サービスURL（予約語置換）
				serviceDto.setDescription(mCategory.getDescription());
				resultList.add(serviceDto);
			} catch (IllegalStateException ignore) {
				logger.log("WCMG9002", ThreadLocalUtils.contractGroupIdDefaultEmpty(), String.format(
						"不正なマスタ定義のため無視します。エラー原因：%s | カテゴリーマスタ情報詳細：%s", ignore.getMessage(), mCategory.toString()));
			}
		}

		return resultList;
	}

	/**
	 * 各サービスが使用している病院のグループIDを取得します。
	 *
	 * @param commonGroupMode
	 *            共通グループ選択時、true
	 * @param mCategory
	 *            カテゴリー情報
	 * @param serviceIdGroupIdMap
	 *            コンシェルジュの子サービスID・グループIDマップ（key:サービスID，value:グループID）
	 * @param contractGroupId
	 *            契約グループID（コンシェルジュのグループID）
	 * @return 病院グループID
	 */
	String getHospitalGroupId(boolean commonGroupMode, MCategory mCategory, Map<String, String> serviceIdGroupIdMap, String contractGroupId) {
		// 共通グループ選択時は、null
		if (commonGroupMode) {
			return null;
		}

		// コンシェルジュのグループIDを使用する場合は、契約グループID（コンシェルジュ、メッセンジャーなど）
		if (ObjectUtils.equals(mCategory.getUseGroupIdType(), AppConstants.USE_GROUP_ID_TYPE_CONCIERGE)) {
			return contractGroupId;
		}

		// 上記以外は、子サービスのグループID
		return serviceIdGroupIdMap.get(mCategory.getServiceId());
	}

	/**
	 * サービスURLの予約語を置換します。
	 *
	 * @param serviceUrl
	 *            サービスURL
	 * @return 置換処理済みサービスURL
	 * @throws IllegalStateException 予約語置換エラー
	 */
	String replaceServiceUrl(String serviceUrl) throws IllegalStateException {
		String resultUrl = serviceUrl;

		Matcher matcher = PATTERN_GATEWAY_URL.matcher(serviceUrl);
		if (matcher.find()) {
			String reservedName = matcher.group(1);							// 予約語（${gateway-url}, ${gateway-url.concierge} など）
			String contextName = matcher.group(2);							// コンテキストパス

			/* プロパティからサービスURLを取得 */
			String keyName = StringUtils.substring(reservedName, 2, -1);	// プロパティ名（gateway-url, gateway-url.concierge など）
			if (StringUtils.equals(keyName, RESERVED_GATEWAY_URL)) {
				// コンテキストパスなし変数（${gateway-url}）なら、コンテキストパスを付与（${gateway-url.context-path}）
				keyName = String.format("%s.%s", keyName, contextName);
			} else if (!StringUtils.startsWith(keyName, RESERVED_GATEWAY_URL + ".")) {
				// 不明な予約語な場合はエラー（サービスURL以外の取得は禁止）
				throw new IllegalStateException(String.format("無効な置換変数です。%s", reservedName));
			}
			String gatewayUrl = environment.getRequiredProperty(keyName);

			/* 予約語を置換 */
			resultUrl = StringUtils.replaceOnce(serviceUrl, reservedName, gatewayUrl);
		}

		return resultUrl;
	}

}
