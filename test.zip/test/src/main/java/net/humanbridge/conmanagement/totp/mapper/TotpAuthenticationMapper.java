package net.humanbridge.conmanagement.totp.mapper;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 *  TOTPサーバーからの認証結果
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class TotpAuthenticationMapper implements Serializable {

	/** Serial version UID. (Default) */
	private static final long serialVersionUID = 1L;

	/** ユーザーID */
	@JsonProperty("user_id")
	private String userId;

	/** 確認した時間 */
	@JsonProperty("check_time")
	private String checkTime;

	/** エラーコード */
	@JsonProperty("ErrorCode")
	private String errorCode;

	/** エラーメッセージ */
	@JsonProperty("ErrorMessage")
	private String errorMessage;
}
