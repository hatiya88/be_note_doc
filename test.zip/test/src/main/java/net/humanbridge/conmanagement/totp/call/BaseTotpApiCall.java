package net.humanbridge.conmanagement.totp.call;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.net.ssl.SSLContext;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.Header;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Value;
import jp.co.fjqs.f2.springboot.logger.basic.F2Logger;
import net.humanbridge.conmanagement.external.exception.TOTPApiCallException;
import jp.co.fjqs.f2.springboot.http.HttpResponse;

/**
 * OTP WebAPI呼び出しクラス
 */
public abstract class BaseTotpApiCall {

	// イベントロガー
	protected static final F2Logger logger = F2Logger.getLogger();

	// TOTPサーバ接続先ホスト
	@Value("${totp.http.host}")
	protected String httpHost;
	// TOTPサーバ接続先ポート
	@Value("${totp.http.port}")
	protected int httpPort;
	//TOTPサーバ 応答タイムアウト設定(msec)
	@Value("${totp.http.socket.timeout:20000}")
	protected int timeout;
	//TOTPサーバSSL接続
	@Value("${totp.protocol.ssl:false}")
	protected boolean protocolSsl;

	/**
	 * TOTP WebAPI(GET)の呼び出し
	 *
	 * @param path  URLパス
	 * @param reqParam  要求パラメータ。?key=value&…の部分をMap化した値
	 * @return レスポンス
	 */
	public HttpResponse callGet(String path, Map<String, String> reqParam) {
		HttpResponse response = new HttpResponse();
		try {
			String protocol = "http";
			if (protocolSsl) {
				protocol = "https";
			}
			String requestUrl = String.format("%s://%s:%d/%s", protocol, httpHost, httpPort, path);
			if (reqParam != null && reqParam.size() > 0) {
				requestUrl = requestUrl + "?" + getQueryString(reqParam);
			}
			RequestConfig config = RequestConfig.custom().setConnectTimeout(timeout).setSocketTimeout(timeout).build();
			SSLContext sslContext = SSLContexts.custom().loadTrustMaterial(new TrustSelfSignedStrategy()).build();
			CloseableHttpClient client = HttpClients.custom().setSSLContext(sslContext)// SSL証明書の検証を無効化
					.setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE).setDefaultRequestConfig(config).build();

			HttpGet request = new HttpGet(requestUrl);
			request.addHeader("Content-type", "application/json;charset=utf-8");
			logger.log("ICMG0104", protocol, httpHost, httpPort, "get", path, "", timeout);

			// ■API要求
			org.apache.http.HttpResponse httpResponse = client.execute(request);
			// 応答作成
			response.responseCode = httpResponse.getStatusLine().getStatusCode();
			response.responseBody = EntityUtils.toString(httpResponse.getEntity());
			response.responseHeaderMap = new LinkedHashMap<String, String>();
			for (Header reshead : httpResponse.getAllHeaders()) {
				response.responseHeaderMap.put(reshead.getName(), reshead.getValue());
			}
			// 健全性確認用ログ出力
			logger.log("ICMG0105", StringUtils.substring(response.responseBody, 0, 1000));
		} catch (Exception e) {
			logger.log("ECMG0105", e, path);
			throw new TOTPApiCallException("CMG999_E0001");
		}
		return response;
	}

	/**
	 * TOTP WebAPI(POST)の呼び出し
	 *
	 * @param path  URLパス
	 * @param sendParam  送信パラメータ。JSONを文字列化したもの。
	 * @return レスポンス
	 */
	public HttpResponse callPost(String path, String sendParam) {
		HttpResponse response = new HttpResponse();
		try {
			String protocol = "http";
			if (protocolSsl) {
				protocol = "https";
			}
			String requestUrl = String.format("%s://%s:%d/%s", protocol, httpHost, httpPort, path);
			RequestConfig config = RequestConfig.custom().setConnectTimeout(timeout).setSocketTimeout(timeout).build();
			SSLContext sslContext = SSLContexts.custom().loadTrustMaterial(new TrustSelfSignedStrategy()).build();
			CloseableHttpClient client = HttpClients.custom().setSSLContext(sslContext)// SSL証明書の検証を無効化
					.setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE).setDefaultRequestConfig(config).build();

			HttpPost request = new HttpPost(requestUrl);
			request.addHeader("Content-type", "application/json;charset=utf-8");
			if (sendParam != null && sendParam.length() > 0) {
				StringEntity params = new StringEntity(sendParam, "UTF-8");
				request.setEntity(params);
			}
			logger.log("ICMG0104", protocol, httpHost, httpPort, "post", path, jsStrMasking(sendParam), timeout);

			// ■API要求
			org.apache.http.HttpResponse httpResponse = client.execute(request);
			// 応答作成
			response.responseCode = httpResponse.getStatusLine().getStatusCode();
			response.responseBody = EntityUtils.toString(httpResponse.getEntity());
			response.responseHeaderMap = new LinkedHashMap<String, String>();
			for (Header reshead : httpResponse.getAllHeaders()) {
				response.responseHeaderMap.put(reshead.getName(), reshead.getValue());
			}
			// 健全性確認用ログ出力
			logger.log("ICMG0105", StringUtils.substring(response.responseBody, 0, 1000));
		} catch (Exception e) {
			logger.log("ECMG0105", e, path);
			throw new TOTPApiCallException("CMG999_E0001");
		}
		return response;
	}

	/** 
	 * OTPホーム画面のリクエストURLの作成
	 */
	protected String createTransferURL(Map<String, String> reqParam, String startupPath) {
		String protocol = "http";
		if (protocolSsl) {
			protocol = "https";
		}
		String requestUrl = String.format("%s://%s:%d/%s", protocol, httpHost, httpPort, startupPath);
		if (reqParam != null && reqParam.size() > 0) {
			requestUrl = requestUrl + "?" + getQueryString(reqParam);
		}
		return requestUrl;
	}

	/** 
	 * 要求パラメータの整形（?key=value&…）の部分
	 */
	private String getQueryString(Map<String, String> paramMap) {
		if (paramMap == null) {
			return "";
		}
		List<NameValuePair> namvalpair = new ArrayList<NameValuePair>();
		Iterator<String> it = paramMap.keySet().iterator();
		while (it.hasNext()) {
			String key = it.next();
			String val = paramMap.get(key);
			namvalpair.add(new BasicNameValuePair(key, val));
		}
		String queryString = URLEncodedUtils.format(namvalpair, "UTF-8");
		return queryString;
	}

	/**
	 * JSON形式の文字列の特定のkeyのvalueをマスクします。
	 *
	 * @param JsonString JSON形式の文字列
	 * @return replacedJsonString マスク済み文字列
	 */
	private String jsStrMasking(String jsonString) {
		try {
			// ダブルクォーテーションで囲まれているvalueをマスクします。
			return jsonString.replaceAll("(?<=\"totp\")(\\s?:\\s?\").*?(?=\")", "$1○○○");
		} catch (Exception e) {
			return "○○○";
		}
	}
}
