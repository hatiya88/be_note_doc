package net.humanbridge.conmanagement.totp.mapper;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 *  秘密鍵無効化の結果
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class TotpRevokePrivateKeyMapper implements Serializable {

	/** Serial version UID. (Default) */
	private static final long serialVersionUID = 1L;

	/** ユーザーID */
	@JsonProperty("user_id")
	private String userId;

	/** 削除処理を行った時間 */
	@JsonProperty("revoke_time")
	private String revokeTime;

	/** エラーコード */
	@JsonProperty("ErrorCode")
	private String errorCode;

	/** エラーメッセージ */
	@JsonProperty("ErrorMessage")
	private String errorMessage;
}
