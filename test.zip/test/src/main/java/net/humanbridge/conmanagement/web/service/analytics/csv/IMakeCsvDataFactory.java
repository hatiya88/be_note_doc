package net.humanbridge.conmanagement.web.service.analytics.csv;

public interface IMakeCsvDataFactory {

	/**
	 * @see IMakeCsvData の具象クラスを生成して返します。
	 * 
	 * @param serviceKind サービス種別
	 * @return @see IMakeCsvData の具象クラス
	 */
	IMakeCsvData create(String serviceKind);
}
