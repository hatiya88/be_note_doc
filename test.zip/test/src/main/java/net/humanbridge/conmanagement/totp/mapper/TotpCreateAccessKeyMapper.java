package net.humanbridge.conmanagement.totp.mapper;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 *  アクセスキーの生成結果
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class TotpCreateAccessKeyMapper implements Serializable {

	/** Serial version UID. (Default) */
	private static final long serialVersionUID = 1L;

	/** アクセスキー */
	@JsonProperty("access_key")
	private String accessKey;

	/** アクセスキーの有効期限 */
	@JsonProperty("expires_in")
	private String expiresIn;

	/** エラーコード */
	@JsonProperty("ErrorCode")
	private String errorCode;

	/** エラーメッセージ */
	@JsonProperty("ErrorMessage")
	private String errorMessage;
}
