package net.humanbridge.conmanagement.web.service.analytics;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fujitsu.portal.api.exception.HttpRequestException;

import jp.co.fjqs.f2.springboot.logger.basic.F2Logger;
import net.humanbridge.conmanagement.concierge.response.HospitalOptApiResponseDxo;
import net.humanbridge.conmanagement.external.call.HospitalOptionMasterApiCall;
import net.humanbridge.conmanagement.web.dbflute.exbhv.MDataAnalyticsGrpGeneralBhv;
import net.humanbridge.conmanagement.web.dto.UserSessionDto;
import net.humanbridge.conmanagement.web.dto.UserSessionDto.MDataAnalyticsGrpGeneralConfig;
import net.humanbridge.conmanagement.web.dto.analytics.DepartmentDto;
import net.humanbridge.conmanagement.web.exception.AuthenticationException;
import net.humanbridge.conmanagement.web.exception.ServiceException;
import net.humanbridge.conmanagement.web.service.AuthenticationService;

/**
 * 利用状況確認ツールでのみ必要とするデータを取得します
 * @author xonogawa.koichi
 *
 */
@Service
public class AnalyticsOnlyService {

	/** イベントロガー */
	private static final F2Logger logger = F2Logger.getLogger();

	/** システム連携PF接続用ユーザのログインID */
	@Value("${systemconnector.login.id}")
	private String systemconnectorLoginId;

	/** システム連携PF接続用ユーザのパスワード */
	@Value("${systemconnector.login.password}")
	private String systemconnectorLoginPassword;

	@Autowired
	private HospitalOptionMasterApiCall hospitalOptionMasterApiCall;

	@Autowired
	private AuthenticationService authenticationService;

	@Autowired
	private AnalyticsService analyticsService;

	@Autowired
	private MDataAnalyticsGrpGeneralBhv mDataAnalyticsGrpGeneralBhv;

	public UserSessionDto getAnalyticsData(UserSessionDto userSessionDto, String contractGroupId, HttpServletRequest request)
			throws AuthenticationException, HttpRequestException, ServiceException {

		// システム連携PF接続用ユーザーでチームID、連携グループIDを取得し、キャッシュする
		if (userSessionDto.getTeamIdMap() == null) {
			// スタッフ権限以外のユーザでログインしている場合は、ログインユーザで取得済。スタッフ権限の場合はシステム連携PF接続用ユーザーで取得する。
			ImmutablePair<Map<String, String>, Map<String, String>> teamIdGroupIdMap = authenticationService.getTeamIdGroupIdMap(systemconnectorLoginId, systemconnectorLoginPassword);
			userSessionDto.setTeamIdMap(teamIdGroupIdMap.getLeft());				// チームID
			userSessionDto.setProviderGroupIdMap(teamIdGroupIdMap.getRight()); 		// 連携グループID
			F2Logger.getLogger(this.getClass()).debug(String.format("WebApi53 システム連携PF接続用ユーザーで取得 LoginId:%s", systemconnectorLoginId));
		}

		// ログインユーザの連携グループIDがシステム連携PF接続用ユーザーに紐づけられているか
		if (userSessionDto.getProviderGroupIdMap().getOrDefault(userSessionDto.getGroupId(), "").isEmpty()) {
			logger.log("ECMG0100", "システム連携PF接続用ユーザー" + systemconnectorLoginId + ")に" + userSessionDto.getGroupCached(userSessionDto.getGroupId()).getGroupName() + "(" + userSessionDto.getGroupId() + ")が紐づけられていません。");
			throw new AuthenticationException("CMG999_E0001", new String[] { userSessionDto.getLoginUserId() }, 
					"システム連携PF接続用ユーザーに" + userSessionDto.getGroupCached(userSessionDto.getGroupId()).getGroupName() + "(" + userSessionDto.getGroupId() + ")が紐づけられていません。");
		}
		// 病院オプションマスタの取得
		HospitalOptApiResponseDxo hospitalOptApiResponse = hospitalOptionMasterApiCall.call(contractGroupId);
		userSessionDto.setHospitalOptApi(hospitalOptApiResponse);

		// WebApi34:コンシェルジュ配下サービスID・グループIDを取得
		Map<String, String> childGroupIdMap = authenticationService.getChildServiceGroupIdList(contractGroupId);
		userSessionDto.setChildGroupIdMap(childGroupIdMap);

		// 診療科取得
		List<DepartmentDto> departmentList = analyticsService.getDepartmentListItem(userSessionDto, request);
		userSessionDto.setDepartmentList(departmentList);

		// 利用状況確認ツールグループ汎用マスタ
		MDataAnalyticsGrpGeneralConfig mDataAnalyticsGrpGeneralConfig = mDataAnalyticsGrpGeneralBhv.getMDataAnalyticsGrpGeneralConfig(contractGroupId);
		userSessionDto.setMDataAnalyticsGrpGeneralConfig(mDataAnalyticsGrpGeneralConfig);

		return userSessionDto;
	}
}
