package net.humanbridge.conmanagement.web.service.totp;

import static net.humanbridge.conmanagement.constant.MfaConstants.*;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.var;
import net.humanbridge.conmanagement.constant.AppConstants;
import net.humanbridge.conmanagement.external.exception.TOTPApiCallException;
import net.humanbridge.conmanagement.totp.call.TotpAuthenticationAPICall;
import net.humanbridge.conmanagement.totp.call.TotpCreateAccessKeyAPICall;
import net.humanbridge.conmanagement.totp.call.TotpRevokePrivateKeyAPICall;
import net.humanbridge.conmanagement.totp.call.TotpUserStatusAPICall;
import net.humanbridge.conmanagement.totp.call.TotpViewCall;
import net.humanbridge.conmanagement.web.dto.UserSessionDto;

/**
 * TOTPサービスクラス
 */
@Service
public class TotpService {

	@Autowired
	private TotpCreateAccessKeyAPICall totpCreateAccessKeyAPICall;

	@Autowired
	private TotpAuthenticationAPICall totpAuthenticationAPICall;

	@Autowired
	private TotpRevokePrivateKeyAPICall totpRevokePrivateKeyAPICall;

	@Autowired
	private TotpUserStatusAPICall totpUserStatusAPICall;

	@Autowired
	private TotpViewCall totpViewCall;

	/**
	 * アクセスキーの生成を行う
	 * 
	 * @param userSessionDto
	 * @param session (CSRF対策トークンを取得)
	 * @return  アクセスキーの生成結果
	 * @throws Exception 
	 * 
	 * @throws Exception 
	 */
	public String createKey(UserSessionDto userSessionDto, HttpSession session) throws Exception {
		String state = (String) session.getAttribute(AppConstants.SESSION_KEY_CSRF_TOKEN);
		var response = totpCreateAccessKeyAPICall.call(userSessionDto.getLoginUserId(), state);
		int statusCode = response.getLeft() != null ? response.getLeft() : HttpServletResponse.SC_INTERNAL_SERVER_ERROR;
		if (statusCode == HttpServletResponse.SC_OK && response.getRight().getAccessKey() != null) {
			return response.getRight().getAccessKey();
		}
		throw new TOTPApiCallException("CMG014-E0001");
	}

	/**
	 * 認証コードを基にTOPTサーバでユーザーの認証を行う
	 * 
	 * @param userSessionDto
	 * @param optCode  認証コード
	 * 
	 * @throws Exception
	 */
	public void authentication(UserSessionDto userSessionDto, String optCode) throws Exception {
		if (optCode.isEmpty()) throw new TOTPApiCallException("CMG014-E0002");
		if (!isHalfNumeric(optCode)) throw new TOTPApiCallException("CMG014-E0004");
		var response = totpAuthenticationAPICall.call(userSessionDto.getLoginUserId(), Integer.parseInt(optCode));
		int statusCode = response.getLeft() != null ? response.getLeft() : HttpServletResponse.SC_INTERNAL_SERVER_ERROR;
		if (statusCode == HttpServletResponse.SC_OK) return;

		//TOTPサーバのエラー時のレスポンスメッセージと画面表示するエラーメッセージのマッピング
		if (statusCode == HttpServletResponse.SC_BAD_REQUEST && response.getRight().getErrorCode() == "WA02007") {
			throw new TOTPApiCallException("CMG014-E0002");
		}
		if (statusCode == HttpServletResponse.SC_BAD_REQUEST && response.getRight().getErrorCode() == "WA02008"
				|| statusCode == HttpServletResponse.SC_UNAUTHORIZED) {
			throw new TOTPApiCallException("CMG014-E0003");
		}
		if (statusCode == HttpServletResponse.SC_BAD_REQUEST) {
			throw new TOTPApiCallException("CMG014-E0001");
		}
		if (statusCode == HttpServletResponse.SC_NOT_FOUND
				|| statusCode == HttpServletResponse.SC_FORBIDDEN) {
			throw new TOTPApiCallException("CMG999_E0001");
		}
		throw new TOTPApiCallException("CMG014-E0001");
	}

	//半角数字6文字
	private boolean isHalfNumeric(String str) {
		return Pattern.matches("\\d{6}", str);
	}

	/**
	 * 登録されている秘密鍵を無効化する
	 * 
	 * @param userSessionDto
	 * @throws JsonProcessingException 
	 * 
	 * @throws Exception
	 */
	public void revokeKey(UserSessionDto userSessionDto) throws Exception {
		var response = totpRevokePrivateKeyAPICall.call(userSessionDto.getLoginUserId());
		int statusCode = response.getLeft() != null ? response.getLeft() : HttpServletResponse.SC_INTERNAL_SERVER_ERROR;
		if (statusCode == HttpServletResponse.SC_OK && response.getRight().getUserId() != null) return;
		throw new TOTPApiCallException("CMG014-E0001");
	}

	/**
	 * 二要素認証の秘密鍵の登録状況の確認
	 * 
	 * @param userSessionDto
	 * @return true：認証する / false：認証しない
	 * 
	 * @throws Exception
	 */
	public boolean isActive(UserSessionDto userSessionDto) {
		var response = totpUserStatusAPICall.call(userSessionDto.getLoginUserId());
		int statusCode = response.getLeft() != null ? response.getLeft() : HttpServletResponse.SC_INTERNAL_SERVER_ERROR;
		if (statusCode == HttpServletResponse.SC_OK && response.getRight().getStatus().equals(MFA_KEY_ACTIVE)) {
			//秘密鍵が有効の場合
			return true;
		}
		if (statusCode == HttpServletResponse.SC_NOT_FOUND 
				&& response.getRight().getStatus().equals(MFA_KEY_NOTREGISTERED)) {
			//秘密鍵が未生成の場合
			return false;
		}
		//秘密鍵が利用不可（「inactive」が返却される）の場合を含む異常応答時
		throw new TOTPApiCallException("CMG014-E0001");
	}

	/**
	 * 二要素認証ホーム画面のURLを作成する
	 * 
	 * @param userSessionDto
	 * @param accessKey  OTP-WA01で作成したアクセスキー
	 * @return true：認証する / false：認証しない
	 * 
	 * @throws Exception 
	 */
	public String transfer(UserSessionDto userSessionDto, String accessKey) throws Exception {
		return totpViewCall.transfer(userSessionDto, accessKey);
	}
}