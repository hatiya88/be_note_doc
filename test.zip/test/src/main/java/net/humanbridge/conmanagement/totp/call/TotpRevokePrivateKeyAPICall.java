package net.humanbridge.conmanagement.totp.call;

import java.io.IOException;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fujitsu.portal.api.exception.HttpRequestException;
import jp.co.fjqs.f2.springboot.http.HttpResponse;
import lombok.var;
import net.humanbridge.conmanagement.external.exception.TOTPApiCallException;
import net.humanbridge.conmanagement.totp.dto.TotpRequestDto;
import net.humanbridge.conmanagement.totp.mapper.TotpRevokePrivateKeyMapper;

/**
 * 秘密鍵を無効化（OTP-WA03）呼び出しクラス
 */
@Component
public class TotpRevokePrivateKeyAPICall extends BaseTotpApiCall {

	/** アクセスキー取得（OTP-WA03）パス */
	@Value("${totp.revoke.private-key:/totp/webapi/v1/revoke/private-key}")
	private String path;

	/** クライアントID */
	@Value("${totp.client.id}")
	private String clientId;

	/** クライアントシークレット */
	@Value("${totp.client.secret}")
	private String clientSecret;

	// スレッドセーフ
	private ObjectMapper mapper = new ObjectMapper();

	/**
	 * 登録されているユーザーの秘密鍵を無効化する（OTP-WA03）
	 * 
	 * @param userId  ユーザID
	 * @return レスポンス
	 * 
	 * @throws HttpRequestException
	 */
	public Pair<Integer, TotpRevokePrivateKeyMapper> call(String userId) throws JsonProcessingException {
		// 要求パラメータ
		var reqParam = new TotpRequestDto();
		reqParam.setUserId(userId);
		reqParam.setClientId(clientId);
		reqParam.setClientSecret(clientSecret);
		var json = new ObjectMapper().writeValueAsString(reqParam);

		HttpResponse response = callPost(path, json.toString());

		TotpRevokePrivateKeyMapper totpRevokePrivateKeyMapper;
		try {
			totpRevokePrivateKeyMapper = mapper.readValue(response.responseBody, TotpRevokePrivateKeyMapper.class);
		} catch (IOException e) {
			logger.log("ECMG0001", e, "TOTPサーバ", e.getMessage());
			throw new TOTPApiCallException("CMG999_E0001");
		}
		return Pair.of(response.responseCode, totpRevokePrivateKeyMapper);
	}
}
