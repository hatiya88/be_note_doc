package net.humanbridge.conmanagement.web.service;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.seasar.dbflute.bhv.ConditionBeanSetupper;
import org.seasar.dbflute.bhv.ReferrerLoaderHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import net.humanbridge.conmanagement.constant.AppConstants;
import net.humanbridge.conmanagement.excel.cbean.Condition;
import net.humanbridge.conmanagement.excel.cbean.OrderBy.DataType;
import net.humanbridge.conmanagement.excel.cbean.SheetCB;
import net.humanbridge.conmanagement.excel.entity.CellDto;
import net.humanbridge.conmanagement.excel.entity.RowDto;
import net.humanbridge.conmanagement.pool.InputTypePool;
import net.humanbridge.conmanagement.util.ThreadLocalUtils;
import net.humanbridge.conmanagement.web.dbflute.bsbhv.loader.LoaderOfMTemplate;
import net.humanbridge.conmanagement.web.dbflute.bsbhv.loader.LoaderOfMTemplateItem;
import net.humanbridge.conmanagement.web.dbflute.cbean.MItemValidationCB;
import net.humanbridge.conmanagement.web.dbflute.cbean.MSelectionCB;
import net.humanbridge.conmanagement.web.dbflute.cbean.MTemplateItemCB;
import net.humanbridge.conmanagement.web.dbflute.exbhv.MTemplateBhv;
import net.humanbridge.conmanagement.web.dbflute.exbhv.MTemplateItemBhv;
import net.humanbridge.conmanagement.web.dbflute.exbhv.MValidationRuleBhv;
import net.humanbridge.conmanagement.web.dbflute.exentity.MItemValidation;
import net.humanbridge.conmanagement.web.dbflute.exentity.MTemplate;
import net.humanbridge.conmanagement.web.dbflute.exentity.MTemplateItem;
import net.humanbridge.conmanagement.web.dbflute.exentity.MTemplateItem.InputType;
import net.humanbridge.conmanagement.web.dbflute.exentity.MValidationRule;
import net.humanbridge.conmanagement.web.dto.TemplateInputDto;
import net.humanbridge.conmanagement.web.dto.TemplateRowDto;

/**
 * テンプレートサービス
 */
@Service
public class TemplateService {

	@Autowired
	private MTemplateBhv mTemplateBhv;
	
	@Autowired
	private MTemplateItemBhv mTemplateItemBhv;
	
	@Autowired
	private MValidationRuleBhv mValidationRuleBhv;
	
	@Autowired
	private InputTypePool inputTypePool;
	
	/**
	 * テンプレートマスタ取得（関連テーブル含む）
	 * 
	 * @param templateSeq
	 * @return
	 */
	public MTemplate getTemplate(Long templateSeq) {
		MTemplate mTemplate = mTemplateBhv.selectByPKValue(templateSeq);
		// 項目マスタ取得
		mTemplateBhv.load(mTemplate, new ReferrerLoaderHandler<LoaderOfMTemplate>() {
			@Override
			public void handle(LoaderOfMTemplate loader) {
				loader.loadMTemplateItemList(new ConditionBeanSetupper<MTemplateItemCB>() {
					@Override
					public void setup(MTemplateItemCB refCB) {
						refCB.query().addOrderBy_DisplayOrder_Asc();
					}
				});
			}
		});
		// 選択肢マスタ取得
		for (MTemplateItem item : mTemplate.getMTemplateItemList()) {
			if (!StringUtils.equals(item.getInputType(), StringUtils.lowerCase(InputType.RADIO.toString()))
					&& !StringUtils.equals(item.getInputType(), StringUtils.lowerCase(InputType.LISTBOX.toString()))) {
				continue;
			}
			mTemplateItemBhv.load(item, new ReferrerLoaderHandler<LoaderOfMTemplateItem>() {
				@Override
				public void handle(LoaderOfMTemplateItem loader) {
					loader.loadMSelectionList(new ConditionBeanSetupper<MSelectionCB>() {
						@Override
						public void setup(MSelectionCB refCB) {
							refCB.query().addOrderBy_DisplayOrder_Asc();
						}
					});
				}
			});
		}
		// 入力チェック取得
		for (MTemplateItem item : mTemplate.getMTemplateItemList()) {
			mTemplateItemBhv.loadMItemValidationList(item, new ConditionBeanSetupper<MItemValidationCB>() {
				@Override
				public void setup(MItemValidationCB refCB) {
					refCB.query().addOrderBy_ValidationOrder_Asc();
				}
			});
			for (MItemValidation itemValidation : item.getMItemValidationList()) {
				MValidationRule mValidationRule = mValidationRuleBhv.selectByPKValue(itemValidation.getValidationKey());
				itemValidation.setMValidationRule(mValidationRule); 
			}
		}
		
		return mTemplate;
	}
	
	/**
	 * テンプレート
	 * 
	 * @param mTemplate
	 *            テンプレートマスタ
	 * @return conditionMap
	 *            key:テーブル名、value:抽出条件
	 */
	public Map<String, SheetCB> getTargetCondition(MTemplate mTemplate) {
		Map<String, SheetCB> conditionMap = new HashMap<>();
		for (MTemplateItem item : mTemplate.getMTemplateItemList()) {
			SheetCB cb = conditionMap.get(item.getTableName());
			if (cb == null) {
				cb = new SheetCB(item.getTableName());
			}
			if (StringUtils.isNotEmpty(item.getKeyName())) {
				Integer cIndex = cb.query().getIndexColumnCondition(item.getColumnName());
				if (cIndex == null) {
					cb.query().setInScope(item.getColumnName(), Arrays.asList(item.getKeyName()));
				} else {
					Condition condition = cb.query().getConditionList().get(cIndex);
					List<String> conditionValueList = condition.getConditionValueList();
					List<String> list = new ArrayList<String>(conditionValueList);
					list.add(item.getKeyName());
					condition.setConditionValueList(list);
					cb.query().getConditionList().set(cIndex, condition);
				}
			}
			conditionMap.put(item.getTableName(), cb);			
		}
		
		if (mTemplate.getRowCount() != 1) {
			// ソート指定項目の抽出
			List<MTemplateItem> sortItemList = mTemplate.getMTemplateItemList().stream()
					.filter(i -> i.getSortNumber() != null)
					.sorted((i1, i2) -> i1.getSortNumber().compareTo(i2.getSortNumber()))
					.collect(Collectors.toList());
			if (sortItemList.size() > 0) {
				SheetCB cb = conditionMap.get(sortItemList.get(0).getTableName());
				for (MTemplateItem sortItem : sortItemList) {
					setOrderBy(cb, sortItem);
				}				
			}
		}

		return conditionMap;
	}

	/**
	 * SheetCBにOrderBy句に相当するソート指定をセットします
	 * 
	 * @param cb
	 * @param sortItem
	 */
	public void setOrderBy(SheetCB cb, MTemplateItem sortItem) {
		InputType inputType = inputTypePool.get(sortItem.getInputType());
		if (StringUtils.equals(sortItem.getDescSortFlag(), "1")) {
			if (inputType == InputType.NUMBER) {
				cb.query().addOrderBy_Desc_WithDataType(sortItem.getColumnName(), DataType.NUMBER);
			} else {
				cb.query().addOrderBy_Desc(sortItem.getColumnName());
			}
		} else {
			if (inputType == InputType.NUMBER) {
				cb.query().addOrderBy_Asc_WithDataType(sortItem.getColumnName(), DataType.NUMBER);
			} else {
				cb.query().addOrderBy_Asc(sortItem.getColumnName());
			}
		}
	}	
	
	/**
	 * テンプレート項目シーケンス値リストからテンプレート項目のMap、およびグループIDカラム名Mapを返します。
	 * 
	 * @param itemSeqList
	 *            テンプレート項目シーケンス値リスト
	 * @return left:テンプレート項目Map, right:グループIDカラム名Map
	 */
	public ImmutablePair<Map<Long, MTemplateItem>, Map<String, String>> selectItemByItemSeqInScope() {
		Map<Long, MTemplateItem> templateItemMap = new HashMap<>();
		Map<String, String> groupIdMap = new HashMap<>();
		MTemplateItemCB cb = new MTemplateItemCB();
		cb.query().setTemplateSeq_Equal(ThreadLocalUtils.getTemplateSeq());
		cb.query().addOrderBy_DisplayOrder_Asc();
		List<MTemplateItem> itemList = mTemplateItemBhv.selectList(cb);
		for (MTemplateItem item : itemList) {
			templateItemMap.put(item.getTemplateItemSeq(), item);
			if (StringUtils.equals(item.getGroupIdFlag(), AppConstants.GROUP_ID_FLAG_ON)) {
				groupIdMap.put(item.getTableName(), item.getColumnName());
			}
		}
		return ImmutablePair.of(templateItemMap, groupIdMap);
	}

	/**
	 * テンプレート画面の入力データを取得します。
	 * 
	 * @param inputDtoAryJson
	 *            入力データDTO配列JSON形式文字列
	 * @return dataListMap
	 *            key:テーブル名（シート名）、value:行DTOのリスト
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 * @throws ParseException 
	 */
	public Map<String, List<RowDto>> getInuptDataMap(String inputDtoAryJson) throws JsonParseException, JsonMappingException, IOException, ParseException {
		// 入力データ取得
		ObjectMapper mapper = new ObjectMapper();
		List<TemplateInputDto> inputDtoList = mapper.readValue(inputDtoAryJson, new TypeReference<List<TemplateInputDto>>(){});		
		
		// テンプレート項目マスタ取得
		List<Long> itemSeqList = new ArrayList<>();
		for (TemplateInputDto inputDto : inputDtoList) {
			Long itemSeq = Long.valueOf(inputDto.getName().split("-")[1]);
			itemSeqList.add(itemSeq);
		}		
		ImmutablePair<Map<Long, MTemplateItem>, Map<String, String>> templateInfoPair = selectItemByItemSeqInScope();
		Map<Long, MTemplateItem> templateItemMap = templateInfoPair.getLeft();
		Map<String, String> groupIdMap = templateInfoPair.getRight();
		
		// アップデートデータ作成
		Map<String, List<RowDto>> dataListMap = new HashMap<>();
		for (TemplateInputDto inputDto : inputDtoList) {
			Long itemSeq = Long.valueOf(inputDto.getName().split("-")[1]);
			MTemplateItem mItem = templateItemMap.get(itemSeq);
			
			List<RowDto> rowDtoList = dataListMap.get(mItem.getTableName());
			if (rowDtoList == null)
				rowDtoList = new ArrayList<>();
			
			Map<String, String> primaryKeyMap = inputDto.getPrimaryKeyValueMap();
			RowDto rowDto = null;
			// 汎用マスタ
			if (StringUtils.isNotEmpty(mItem.getKeyName())) {
				// 1設定=>エクセル1行
				rowDto = new RowDto();
				for (Map.Entry<String, String> entry : primaryKeyMap.entrySet()) {
					CellDto primaryColumn = new CellDto(entry.getKey(), true);
					primaryColumn.setValue(entry.getValue());
					rowDto.put(primaryColumn.getColumnName(), primaryColumn);
				}
				CellDto valueColumn = new CellDto(mItem.getValueColumnName(), false);
				String value = convertValue(mItem, inputDto.getValue());
				
				// 削除区分=1で値が空はレコード削除
				if (StringUtils.equals(mItem.getDeleteType(), AppConstants.DELETE_TYPE_ON)
						&& StringUtils.isEmpty(value)) {
					rowDto.setDelete(true);
				}
				valueColumn.setValue(value);
				rowDto.put(valueColumn.getColumnName(), valueColumn);
				
				// 主キー空 の場合、グループIDとキー名は補完する(※予約汎用マスタのようにグループIDとkeyカラムは主キーではないがNotNull想定の前提）
				for (Map.Entry<String, CellDto> rowEntry : rowDto.entrySet()) {
					CellDto cell = rowEntry.getValue();
					if (cell.isPrimary() && StringUtils.isNotEmpty(cell.getValue()))
						break;
					// グループIDおよびキー名を主キーとするテーブルは上記判定で除外される
					if (groupIdMap.containsKey(mItem.getTableName())) {
						CellDto groupIdCell = new CellDto(groupIdMap.get(mItem.getTableName()), false, ThreadLocalUtils.getServiceDto().getGroupId());
						rowDto.put(groupIdMap.get(mItem.getTableName()), groupIdCell);
					}
					CellDto keyCell = new CellDto(mItem.getColumnName(), false, mItem.getKeyName());
					rowDto.put(mItem.getColumnName(), keyCell);
					break;
				}
				
				rowDtoList.add(rowDto);
			} else {
				// 汎用マスタのグループIDカラム項目は補完用項目のため、汎用マスタ以外マスタのデータ生成をするロジックをスキップさせる
				boolean isGroupIdGeneralMaster = isGroupIdColumnAtGeneralMaster(mItem);
				if (isGroupIdGeneralMaster)
					continue;
				
				// 汎用マスタ以外
				int rowIdx = 0;
				for (RowDto row : rowDtoList) {
					boolean isMatchPrimary = false;
					for (Map.Entry<String, String> entry : primaryKeyMap.entrySet()) {
						CellDto primaryColumn = row.get(entry.getKey());
						isMatchPrimary = primaryColumn != null && StringUtils.equals(entry.getValue(), primaryColumn.getValue());
						if (!isMatchPrimary) break;
					}
					if (isMatchPrimary) {
						rowDto = row;
						break;
					}
					rowIdx++;
				}
				if (rowDto == null) {
					rowDto = new RowDto();
					for (Map.Entry<String, String> entry : primaryKeyMap.entrySet()) {
						CellDto cellDto = new CellDto(entry.getKey(), true);
						cellDto.setValue(entry.getValue());
						rowDto.put(cellDto.getColumnName(), cellDto);
					}
				}
				boolean isPrimary = primaryKeyMap.containsKey(mItem.getColumnName());
				CellDto valueColumn = new CellDto(mItem.getColumnName(), isPrimary);
				String value = convertValue(mItem, inputDto.getValue());
				valueColumn.setValue(value);
				rowDto.put(valueColumn.getColumnName(), valueColumn);
				if (CollectionUtils.isEmpty(rowDtoList)) {
					rowDtoList.add(rowDto);
				} else {
					rowDtoList.set(rowIdx, rowDto);
				}
			}
			
			dataListMap.put(mItem.getTableName(), rowDtoList);
		}
		
		return dataListMap;
	}
	
	/**
	 * テンプレート画面(横レイアウト一覧形式)の入力データを取得します。
	 * 
	 * @param inputDtoAryJson
	 *            入力データDTO配列JSON形式文字列
	 * @return dataListMap
	 *            key:テーブル名（シート名）、value:行DTOのリスト
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 * @throws ParseException 
	 */
	public Map<String, List<RowDto>> getInuptDataMapHorizontal(String inputDtoAryJson) throws JsonParseException, JsonMappingException, IOException, ParseException {
		// 入力データ取得
		ObjectMapper mapper = new ObjectMapper();
		List<TemplateRowDto> templateRowList = mapper.readValue(inputDtoAryJson, new TypeReference<List<TemplateRowDto>>(){});
		List<TemplateInputDto> inputDtoList = templateRowList.get(0).getInputList();

		// テンプレート項目マスタ取得
		List<Long> itemSeqList = new ArrayList<>();
		for (TemplateInputDto inputDto : inputDtoList) {
			Long itemSeq = Long.valueOf(inputDto.getName().split("-")[1]);
			itemSeqList.add(itemSeq);
		}		
		ImmutablePair<Map<Long, MTemplateItem>, Map<String, String>> templateInfoPair = selectItemByItemSeqInScope();
		Map<Long, MTemplateItem> templateItemMap = templateInfoPair.getLeft(); 
		
		// アップデートデータ作成
		Map<String, List<RowDto>> dataListMap = new HashMap<>();
		String tableName = "";
		List<RowDto> rowDtoList = new ArrayList<>();
		
		for (TemplateRowDto tRow : templateRowList) {
			boolean isDelete = StringUtils.equals(tRow.getDeleteSelect(), "1");
			
			// 削除ON且つ追加行はスキップ
			if (isDelete && StringUtils.isEmpty(tRow.getPrimaryKeyValue())) 
				continue;
			
			RowDto rowDto = new RowDto();
			rowDto.setDelete(isDelete);
			
			inputDtoList = tRow.getInputList();
			
			TemplateInputDto dto = inputDtoList.get(0);
			for (Map.Entry<String, String> entry : dto.getPrimaryKeyValueMap().entrySet()) {
				CellDto valueColumn = new CellDto(entry.getKey(), true, entry.getValue());
				rowDto.put(valueColumn.getColumnName(), valueColumn);
			}
			
			for (TemplateInputDto inputDto : inputDtoList) {
				Long itemSeq = Long.valueOf(inputDto.getName().split("-")[1]);
				MTemplateItem mItem = templateItemMap.get(itemSeq);
				tableName = mItem.getTableName();
				
				boolean isPrimary = false;
				for (Map.Entry<String, String> entry : dto.getPrimaryKeyValueMap().entrySet()) {
					if (StringUtils.equals(mItem.getColumnName(), entry.getKey())) {
						isPrimary = true;
						break;
					}
				}				
				CellDto valueColumn = new CellDto(mItem.getColumnName(), isPrimary);				
				String value = convertValue(mItem, inputDto.getValue());
				valueColumn.setValue(value);
				rowDto.put(valueColumn.getColumnName(), valueColumn);
			}
			rowDtoList.add(rowDto);
		}
		
		dataListMap.put(tableName, rowDtoList);
		
		return dataListMap;
	}
	
	/**
	 * 変換必要な値の変換
	 * 
	 * @param mItem
	 * @param strDate
	 * @return
	 * @throws ParseException
	 */
	public String convertValue(MTemplateItem mItem, String strVal) throws ParseException {
		InputType inputType = inputTypePool.get(mItem.getInputType());
		
		// 日時以外の変換が必要になれば以下を修正してください
		if (StringUtils.isEmpty(strVal) || (inputType != InputType.DATETIME && inputType != InputType.DATETIMEZONE)) {
			// 項目により空文字必要な場合は空白文字可否フラグON
			if (StringUtils.isEmpty(strVal) && !StringUtils.equals(mItem.getEmptyCharEnable(), AppConstants.EMPTY_STRING_ENABLE_ON)) strVal = null;
			return strVal;
		}
		
		SimpleDateFormat dtf = new SimpleDateFormat(AppConstants.EXCEL_DATETIME_FORMAT);
		SimpleDateFormat dtzf = new SimpleDateFormat(AppConstants.EXCEL_DATETIMEZ_FORMAT);
		SimpleDateFormat dtpf = new SimpleDateFormat(AppConstants.DATETIMEPICKER_FORMAT);
		
		Date date = null;
		date = dtpf.parse(strVal);
		switch (inputType) {
		case DATETIME:
			strVal = dtf.format(date);
			break;
		case DATETIMEZONE:
			strVal = dtzf.format(date);
			break;
		default:
		} 
		
		// 項目により空文字必要な場合は空白文字可否フラグON
		if (StringUtils.isEmpty(strVal) && !StringUtils.equals(mItem.getEmptyCharEnable(), AppConstants.EMPTY_STRING_ENABLE_ON)) strVal = null;
		return strVal;
	}
	
	/**
	 * マスタ入力ルールをJavascrptオブジェクトに変換可能な形式のMapで取得
	 * @param mTemplate
	 * @return
	 */
	public Map<String, Map<String, String>> masterValidRules(MTemplate mTemplate) {
		Map<String, Map<String, String>> validRules = new HashMap<>();
		for (MTemplateItem item : mTemplate.getMTemplateItemList()) {
			if (CollectionUtils.isEmpty(item.getMItemValidationList())) continue;
			for (MItemValidation itemValidation : item.getMItemValidationList()) {
				if (itemValidation.getMValidationRule() == null 
						|| (StringUtils.isEmpty(itemValidation.getMValidationRule().getScript()) && StringUtils.isEmpty(itemValidation.getMValidationRule().getErrorMessage()))) {
					continue;
				}
				Map<String, String> rule = new HashMap<>();
				rule.put("func", itemValidation.getMValidationRule().getScript());
				rule.put("alertText", itemValidation.getMValidationRule().getErrorMessage());
				validRules.put(itemValidation.getValidationKey(), rule);
			}
		}
		return validRules;
	}

	/**
	 * ヘッダー行とデータ行リストのMapに分ける
	 * @param allRowListMap
	 * @return
	 */
	public ImmutablePair<Map<String, RowDto>, Map<String, List<RowDto>>> separateHeaderAndDataMap(Map<String, List<RowDto>> allRowListMap) {
        Map<String, RowDto> headerMap = new HashMap<>();
        Map<String, List<RowDto>> dataListMap = new HashMap<>();
        for (Map.Entry<String, List<RowDto>> entry : allRowListMap.entrySet()) {
        	List<RowDto> allRow = entry.getValue();
        	List<RowDto> dataList = allRow.size() > 1 ? allRow.subList(1, allRow.size()) : new ArrayList<>();
        	headerMap.put(entry.getKey(), allRow.get(0));
        	dataListMap.put(entry.getKey(), dataList);
        }
        return ImmutablePair.of(headerMap, dataListMap);
	}

	/**
	 * 主キーカラムのリストのMapを取得
	 * 
	 * @param headerMap
	 * @return
	 */
	public Map<String, List<String>> primaryKeyMap(Map<String, RowDto> headerMap) {
		Map<String, List<String>> primaryKeyMap = new HashMap<>();
		for (Map.Entry<String, RowDto> sheetHeader : headerMap.entrySet()) {
			RowDto headerRow = sheetHeader.getValue();
			for (Map.Entry<String, CellDto> cellEntry : headerRow.entrySet()) {
				if (!cellEntry.getValue().isPrimary()) continue;
				List<String> primaryKeyList = primaryKeyMap.get(sheetHeader.getKey());
				if (CollectionUtils.isEmpty(primaryKeyList)) primaryKeyList = new ArrayList<>();
				if (primaryKeyList.contains(cellEntry.getKey())) continue;
				primaryKeyList.add(cellEntry.getKey());
				primaryKeyMap.put(sheetHeader.getKey(), primaryKeyList);
			}
		}
		return primaryKeyMap;
	}
	
	/**
	 * グループIDカラム名のMapを取得
	 * 
	 * @param mTemplate
	 * @return
	 */
	public Map<String, String> groupIdMap(MTemplate mTemplate) {
		Map<String, String> groupIdMap = new HashMap<>();
		for (MTemplateItem item : mTemplate.getMTemplateItemList()) {
			if (!StringUtils.equals(item.getGroupIdFlag(), AppConstants.GROUP_ID_FLAG_ON)) continue;
			groupIdMap.put(item.getTableName(), item.getColumnName());
		}
		return groupIdMap;
	}
	
	/**
	 * 項目が汎用マスタにおけるグループIDであるか判定
	 * 
	 * @param mItem
	 * @return
	 */
	public boolean isGroupIdColumnAtGeneralMaster(MTemplateItem mItem) {
		if (!StringUtils.equals(mItem.getGroupIdFlag(), AppConstants.GROUP_ID_FLAG_ON)) 
			return false;
		List<MTemplateItem> mItemList = mTemplateItemBhv.findByTemplateSeqSearch(mItem.getTemplateSeq());
		for (MTemplateItem item : mItemList) {
			// 同一テンプレート内に同一テーブル名且つキー名を持つ項目が存在すれば汎用マスタ形式のテーブルのカラムと判断
			if (StringUtils.equals(mItem.getTableName(), item.getTableName())
					&& StringUtils.isNotEmpty(item.getKeyName())) {
				return true;
			}
		}
		return false;
	}

}
