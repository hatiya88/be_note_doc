package net.humanbridge.conmanagement.web.dto;

import static net.humanbridge.conmanagement.constant.AppConstants.MUSER_ALLOWED_FLAG;
import static net.humanbridge.conmanagement.web.dbflute.exbhv.MConManageGeneralBhv.ALLOWED_OPTION_SERVICE_ID_KEY;
import static net.humanbridge.conmanagement.web.dbflute.exbhv.MConManageGeneralBhv.STANDARD_SERVICE_ID_KEY;
import static net.humanbridge.conmanagement.web.dbflute.exbhv.MDataAnalyticsGrpGeneralBhv.ALLOWED_SERVICE_ID_KEY;
import static net.humanbridge.conmanagement.web.dbflute.exbhv.MDataAnalyticsGrpGeneralBhv.PAGE_SIZE;
import static net.humanbridge.conmanagement.web.dbflute.exbhv.MUserAuthBhv.ALLOWED_DATA_ANALYTICS_KEY;
import static net.humanbridge.conmanagement.web.dbflute.exbhv.MUserAuthBhv.ALLOWED_SERVICE_MANAGEMENT_KEY;
import static net.humanbridge.conmanagement.web.dbflute.exbhv.MUserAuthBhv.ALLOWED_TOOL_SERVICE_ID_KEY;
import static net.humanbridge.conmanagement.web.dbflute.exbhv.MUserAuthBhv.ALLOWED_USER_MANAGEMENT_KEY;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.fujitsu.portal.api.mapper.User;

import jp.co.fjqs.f2.springboot.logger.basic.F2Logger;
import net.humanbridge.conmanagement.concierge.response.HospitalOptApiResponseDxo;
import net.humanbridge.conmanagement.constant.AnalyticsConstants;
import net.humanbridge.conmanagement.web.dto.analytics.DepartmentDto;

/**
 * 共通のセッションとして、値を格納する
 */
public class UserSessionDto implements Serializable {

	/** Serial version UID. (Default) */
	private static final long serialVersionUID = 1L;

	/** APIキー */
	private String apiKey;

	/** アクセストークン */
	private String accessToken;

	/** ログインユーザー情報 */
	private User loginUser;

	/** ログイングループID */
	private String groupId;

	/** イベントロガー */
	private static final F2Logger logger = F2Logger.getLogger();

	/**
	 * 子サービスグループID
	 * key: サービスID
	 * value: 子サービスグループID
	 */
	private Map<String, String> childGroupIdMap;
	
	/**
	 * ログインユーザ チームID
	 * key: 契約グループID
	 * value: チームID
	 */
	private Map<String, String> teamIdMap;

	/**
	 * 連携グループID
	 * key: 契約グループID
	 * value: 連携グループID
	 */
	private Map<String, String> providerGroupIdMap;

	/** 病院選択 で 選択した情報をキャッシュ */
	private Map<String, GroupDto> groupCached = new HashMap<String, GroupDto>();

	/** サービス選択 で 選択した情報をキャッシュ */
	private Map<String, ServiceDto> serviceCached = new HashMap<String, ServiceDto>();

	/** 病院オプションマスタをキャッシュ */
	private HospitalOptApiResponseDxo hospitalOptApi = new HospitalOptApiResponseDxo();
	
	private String functionName;
	
	/** 設定選択 で 選択したテンプレートをキャッシュ */
	private Long templateSeqCached = null;

	/** 病院設定（汎用マスタ）情報をキャッシュ */
	private HospitalConfig hospitalConfig = null;

	/** 利用者設定（利用者管理マスタ）情報をキャッシュ */
	private MUserConfig mUserConfig = null;

	/** マスメンAPIユーザ(マスタメンテ組込みjarの共通権限チェック対応) */
	private DummyUser dummyUser = new DummyUser();

	/** 診療科 */
	private List<DepartmentDto> departmentDto = new ArrayList<DepartmentDto>();

	/** 利用状況確認ツールグループ汎用マスタ */
	private MDataAnalyticsGrpGeneralConfig mDataAnalyticsGrpGeneralConfig = null;
	
	/** コンストラクタ */
	public UserSessionDto() {
		// do nothing
	}

	/**
	 * 病院選択画面で、選択したグループに関する情報をキャッシュします。
	 * @param contractGroupId 契約グループID
	 * @param groupName 病院グループ名
	 */
	public void putGroupCached(String contractGroupId, String groupName) {
		GroupDto groupServiceDto = new GroupDto();
		groupServiceDto.setContractGroupId(contractGroupId);
		groupServiceDto.setGroupName(groupName);
		groupCached.put(contractGroupId, groupServiceDto);
	}

	/**
	 * 病院選択画面で、選択したサービスに関する情報をキャッシュします。
	 * @param contractGroupId 契約グループID
	 * @param groupId 病院グループID
	 * @param categorySeq カテゴリーSeq
	 * @param serviceId サービスID
	 * @param serviceName サービス名
	 * @param serviceUrl サービスURL(予約語置換済み)
	 */
	public void putServiceCached(String contractGroupId, String groupId, Long categorySeq, String serviceId, String serviceName, String serviceUrl) {
		ServiceDto serviceDto = new ServiceDto();
		serviceDto.setContractGroupId(contractGroupId);
		serviceDto.setGroupId(groupId);
		serviceDto.setCategorySeq(categorySeq);
		serviceDto.setServiceId(serviceId);
		serviceDto.setServiceName(serviceName);
		serviceDto.setServiceUrl(serviceUrl);
		serviceCached.put(contractGroupId + "¥n" + serviceId, serviceDto);
	}

	/**
	 * キャッシュから、グループに関する情報を取得します。
	 * @param contractGroupId 契約グループID
	 * @return 病院情報
	 */
	public GroupDto getGroupCached(String contractGroupId) {
		return groupCached.get(contractGroupId);
	}

	/**
	 * キャッシュから、サービスに関する情報を取得します。
	 * @param contractGroupId 契約グループID
	 * @param serviceId サービスID
	 * @return サービス情報
	 */
	public ServiceDto getServiceCached(String contractGroupId, String serviceId) {
		return serviceCached.get(contractGroupId + "¥n" + serviceId);
	}

	/** APIキー */
	public String getApiKey() {
		return apiKey;
	}

	/** APIキー */
	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}

	/** アクセストークン */
	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	/** アクセストークン */
	public String getAccessToken() {
		return accessToken;
	}

	/** ログインユーザー情報 */
	public User getLoginUser() {
		return loginUser;
	}

	/** ログインユーザー情報 */
	public void setLoginUser(User loginUser) {
		this.loginUser = loginUser;
	}

	/** グループID */
	public String getGroupId() {
		return groupId;
	}

	/** グループID */
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	/** 子サービスグループID */
	public Map<String, String> getChildGroupIdMap() {
		return childGroupIdMap;
	}

	/** 子サービスグループID */
	public void setChildGroupIdMap(Map<String, String> childGroupIdMap) {
		this.childGroupIdMap = childGroupIdMap;
	}

	/** チームID */
	public Map<String, String> getTeamIdMap() {
		return teamIdMap;
	}

	/** チームID */
	public void setTeamIdMap(Map<String, String> teamIdMap) {
		this.teamIdMap = teamIdMap;
	}

	/** 連携グループID */
	public Map<String, String> getProviderGroupIdMap() {
		return providerGroupIdMap;
	}

	/** 連携グループID */
	public void setProviderGroupIdMap(Map<String, String> providerGroupIdMap) {
		this.providerGroupIdMap = providerGroupIdMap;
	}

	// ------------ //
	// 追加メソッド //
	// ------------ //

	/** ログインユーザーID */
	public String getLoginUserId() {
		if (loginUser == null) {
			return null;
		}
		return loginUser.getUserId();
	}

	/** ログインユーザー名 */
	public String getLoginUserName() {
		if (loginUser == null) {
			return null;
		}
		return loginUser.getFamilyName() + " " + loginUser.getFirstName();
	}

	/**
	 *  契約グループを示す クラス
	 */
	public static class GroupDto implements Serializable {
		private static final long serialVersionUID = 1L;

		/** 契約グループID */
		private String contractGroupId;

		/** 病院のグループ名 */
		private String groupName;

		/** 未設定の場合、true */
		public boolean isEmpty() {
			return contractGroupId == null;
		}

		/** 設定済の場合、true */
		public boolean isNotEmpty() {
			return !isEmpty();
		}

		/** 契約グループID */
		public String getContractGroupId() {
			return contractGroupId;
		}

		/** 契約グループID */
		public void setContractGroupId(String contractGroupId) {
			this.contractGroupId = contractGroupId;
		}

		/** 病院のグループ名 */
		public String getGroupName() {
			return groupName;
		}

		/** 病院のグループ名 */
		public void setGroupName(String groupName) {
			this.groupName = groupName;
		}
	}

	/**
	 *  契約グループIDと、サービス名を示す クラス
	 */
	public static class ServiceDto implements Serializable, Cloneable  {
		private static final long serialVersionUID = 1L;

		/** 契約グループID */
		private String contractGroupId;

		/** カテゴリーSeq */
		private Long categorySeq;

		/** サービスID */
		private String serviceId;

		/** マスタメンテナンス対象サービスの病院グループID */
		private String groupId;

		/** サービス名 */
		private String serviceName;

		/** サービスURL(予約語置換済み) */
		private String serviceUrl;

		/** 未設定の場合、true */
		public boolean isEmpty() {
			return contractGroupId == null || serviceId == null;
		}

		/** 設定済の場合、true */
		public boolean isNotEmpty() {
			return !isEmpty();
		}

		/** 共通グループ選択モードかどうか */
		public boolean isCommonMode() {
			// 共通グループの場合、マスタメンテナンス対象サービスの病院グループIDは null となる
			return StringUtils.isNotBlank(contractGroupId) && StringUtils.isBlank(groupId);
		}

		/** 病院選択モードかどうか */
		public boolean isUserMode() {
			return !isCommonMode();
		}

		/** 契約グループID */
		public String getContractGroupId() {
			return contractGroupId;
		}

		/** 契約グループID */
		public void setContractGroupId(String contractGroupId) {
			this.contractGroupId = contractGroupId;
		}

		/** カテゴリーSeq */
		public Long getCategorySeq() {
			return categorySeq;
		}

		/** カテゴリーSeq */
		public void setCategorySeq(Long categorySeq) {
			this.categorySeq = categorySeq;
		}

		/** サービスID */
		public String getServiceId() {
			return serviceId;
		}

		/** サービスID */
		public void setServiceId(String serviceId) {
			this.serviceId = serviceId;
		}

		/** マスタメンテナンス対象サービスの病院グループID */
		public String getGroupId() {
			return groupId;
		}

		/** マスタメンテナンス対象サービスの病院グループID */
		public void setGroupId(String groupId) {
			this.groupId = groupId;
		}

		/** サービス名 */
		public String getServiceName() {
			return serviceName;
		}

		/** サービス名 */
		public void setServiceName(String serviceName) {
			this.serviceName = serviceName;
		}

		/** サービスURL(予約語置換済み) */
		public String getServiceUrl() {
			return serviceUrl;
		}

		/** サービスURL(予約語置換済み) */
		public void setServiceUrl(String serviceUrl) {
			this.serviceUrl = serviceUrl;
		}

	    @Override
	    public ServiceDto clone() {
	    	ServiceDto clone = null;
	    	try {
	    		clone = (ServiceDto) super.clone();
	    	} catch (CloneNotSupportedException e) {}
	    	return clone;
	    }
	}

	/**
	 * 病院ごとの設定
	 *   汎用マスタでのみ使用
	 *   ※1) インスタンス生成時の値を変更させないためにsetterは追加しない。
	 *   ※2) メンバの値を変更する場合はインスタンスを生成し直す。
	 */
	public static class HospitalConfig implements Serializable {

		private static final long serialVersionUID = 1L;

		/** 病院ごとの設定値 key:設定項目、value:設定値 **/
		private Map<String, String> configMap;

		/** 設定値初期値 key:設定項目、value:設定値 **/
		private Map<String, String> defaultConfigMap;

		/**
		 * コンストラクタ
		 *
		 * @param configMap
		 * @param defaulConfigMap
		 * @return
		 */
		public HospitalConfig(Map<String, String> configMap, Map<String, String> defaultConfigMap) {
			this.configMap = configMap;
			this.defaultConfigMap = defaultConfigMap;
		}

		/**
		 * キーに対する設定値を取得します。
		 *
		 * @param masterKey
		 * @return
		 */
		public String getMasterValue(String masterKey) {
			return this.configMap.containsKey(masterKey) ? this.configMap.get(masterKey) : this.defaultConfigMap.get(masterKey);
		}

		/**
		 * 上記ソースは変更しない。
		 * 変更は下記に追加していく。
		 */

		/**
		 * 標準サービスIDを取得します。
		 *
		 * @return
		 */
		public List<String> standardServiceIdList() {
			 String standardServiceIds = getMasterValue(STANDARD_SERVICE_ID_KEY);
			 List<String> standardList = StringUtils.isNotEmpty(standardServiceIds) ? Arrays.asList(standardServiceIds.split(",")) : new ArrayList<>();
			 return standardList;
		}

		/**
		 * 許可オプションサービスIDを取得します。
		 *
		 * @return
		 */
		public List<String> allowedOptionServiceIdList() {
			 String allowedOptionServiceIds = getMasterValue(ALLOWED_OPTION_SERVICE_ID_KEY);
			 List<String> optionList = StringUtils.isNotEmpty(allowedOptionServiceIds) ? Arrays.asList(allowedOptionServiceIds.split(",")) : new ArrayList<>();
			 return optionList;
		}

		/**
		 * 承認されたサービスであるか判定します。
		 *
		 * @param serviceId
		 * @return
		 */
		public boolean isAuthorizedSerivce(String serviceId) {
			return standardServiceIdList().contains(serviceId) || allowedOptionServiceIdList().contains(serviceId);
		}
	}

	/**
	 * ツール利用者ごとの設定
	 *   利用者管理マスタでのみ使用
	 *   ※1) インスタンス生成時の値を変更させないためにsetterは追加しない。
	 *   ※2) メンバの値を変更する場合はインスタンスを生成し直す。
	 */
	public static class MUserConfig implements Serializable {

		private static final long serialVersionUID = 1L;

		/** 利用者ごとの設定値 key:設定項目、value:設定値 **/
		private Map<String, String> userConfigMap;

		/** 設定値初期値 key:設定項目、value:設定値 **/
		private Map<String, String> userdefaultConfigMap;

		/**
		 * コンストラクタ
		 *
		 * @param userConfigMap
		 * @param userdefaultConfigMap
		 * @return
		 */
		public MUserConfig(Map<String, String> userConfigMap, Map<String, String> userdefaultConfigMap) {
			this.userConfigMap = userConfigMap;
			this.userdefaultConfigMap = userdefaultConfigMap;
		}

		/**
		 * キーに対する設定値を取得します。
		 *
		 * @param userMasterKey
		 * @return
		 */
		public String getMasterValue(String userMasterKey) {
			return this.userConfigMap.containsKey(userMasterKey) ? this.userConfigMap.get(userMasterKey) : this.userdefaultConfigMap.get(userMasterKey);
		}

		/**
		 * 上記ソースは変更しない。
		 * 変更は下記に追加していく。
		 */

		/**
		 * ツールの利用許可サービスIDを取得します。（カンマ区切り）
		 * 
		 * @return
		 */
		public List<String> allowedToolServiceIdList() {
			 String allowedToolServiceIds = getMasterValue(ALLOWED_TOOL_SERVICE_ID_KEY);
			 List<String> emptyServiceIdList = new ArrayList<>();
			 return StringUtils.isEmpty(allowedToolServiceIds) ? emptyServiceIdList : Arrays.asList(allowedToolServiceIds.split(","));
		}

		/**
		 * 利用者管理機能の利用許可フラグを取得します。
		 * 0:不可、1:許可
		 * @return
		 */
		public String allowedUserManagementFlag() {
			 String allowedUserManagementFlag = getMasterValue(ALLOWED_USER_MANAGEMENT_KEY);
			 return allowedUserManagementFlag;
		}

		/**
		 * サービス管理機能の利用許可フラグを取得します。
		 * 0:不可、1:許可
		 * @return
		 */
		public String allowedServiceManagementFlag() {
			 String allowedServiceManagementFlag = getMasterValue(ALLOWED_SERVICE_MANAGEMENT_KEY);
			 return allowedServiceManagementFlag;
		}

		/**
		 * 利用状況確認ツールの利用許可フラグを取得します。
		 * 0:不可、1:許可
		 * @return
		 */
		public String allowedDataAnalyticsFlag() {
			 String allowedDataAnalyticsFlag = getMasterValue(ALLOWED_DATA_ANALYTICS_KEY);
			 return allowedDataAnalyticsFlag;
		}

		/**
		 * 利用許可のあるツールであるか判定します。
		 * >ログイン時にシステム設定ツールの利用許可があるか判別
		 * @param serviceId
		 * @return
		 */
		public boolean isAuthorizedTool(String serviceId) {
			return allowedToolServiceIdList().contains(serviceId);
		}
		
		/**
		 * 管理者機能の利用許可があるユーザか判定します。
		 *　>利用者管理とサービス管理の利用許可フラグがあれば管理者機能ボタンがメインメニュ画面に追加される。
		 * 0:不可:MUSER_NOT_ALLOWED_FLAG、1:許可:MUSER_ALLOWED_FLAG
		 * @return
		 */
		public boolean isAuthorizedMUser() {
			return allowedUserManagementFlag().equals(MUSER_ALLOWED_FLAG) || allowedServiceManagementFlag().equals(MUSER_ALLOWED_FLAG);
		}

	}

	/**
	 * ツール利用者ごとの設定
	 *   利用状況確認ツールグループ用マスタでのみ使用
	 *   ※1) インスタンス生成時の値を変更させないためにsetterは追加しない。
	 *   ※2) メンバの値を変更する場合はインスタンスを生成し直す。
	 */
	public static class MDataAnalyticsGrpGeneralConfig implements Serializable {

		private static final long serialVersionUID = 1L;

		/** グループIDごとの設定値 key:設定項目、value:設定値 **/
		private Map<String, String> dataAnalyticsGrpGeneralConfigMap;

		/**
		 * コンストラクタ
		 *
		 * @param dataAnalyticsGrpGeneralConfigMap
		 * @param groupDefaultConfigMap
		 * @return
		 */
		public MDataAnalyticsGrpGeneralConfig(Map<String, String> dataAnalyticsGrpGeneralConfigMap) {
			this.dataAnalyticsGrpGeneralConfigMap = dataAnalyticsGrpGeneralConfigMap;
		}

		/**
		 * キーに対する設定値を取得します。
		 *
		 * @param groupMasterKey
		 * @return
		 */
		public String getMasterValue(String groupMasterKey) {
			return this.dataAnalyticsGrpGeneralConfigMap.get(groupMasterKey);
		}

		/**
		 * 上記ソースは変更しない。
		 * 変更は下記に追加していく。
		 */

		/**
		 * ツールの利用許可サービスIDを取得します。（カンマ区切り）
		 * 
		 * @return
		 */
		public List<String> allowedAnalyticsToolServiceIdList() {
			 String allowedAnalyticsToolServiceIds = getMasterValue(ALLOWED_SERVICE_ID_KEY);
			 List<String> emptyServiceIdList = new ArrayList<>();
			 return StringUtils.isEmpty(allowedAnalyticsToolServiceIds) ? emptyServiceIdList : Arrays.asList(allowedAnalyticsToolServiceIds.split(","));
		}

		/**
		 * 利用許可のあるツールであるか判定します。
		 * >ログイン時にシステム設定ツールの利用許可があるか判別
		 * @param serviceId
		 * @return
		 */
		public boolean isAuthorizedAnalyticsTool(String serviceId) {
			return allowedAnalyticsToolServiceIdList().contains(serviceId);
		}

		/**
		 * Pagingで１回に取得する件数を取得します
		 * 
		 * @return
		 */
		public int getFetchAmount() {
			if (StringUtils.isNotEmpty(getMasterValue(PAGE_SIZE))) {
				try {
					return Integer.valueOf(getMasterValue(PAGE_SIZE));	
				} catch (Exception e) {
					logger.log("WCMG0101", e, "利用状況確認ツールグループ汎用マスタ-Pagingで１回に取得する件数", e.getMessage());
					return AnalyticsConstants.PAGE_SIZE;
				}
			} else {
				return AnalyticsConstants.PAGE_SIZE;
			}
		}
	}

	/**
	 * ツール利用者ごとの設定
	 *   利用状況確認ツールユーザ汎用マスタでのみ使用
	 *   ※1) インスタンス生成時の値を変更させないためにsetterは追加しない。
	 *   ※2) メンバの値を変更する場合はインスタンスを生成し直す。
	 */
	public static class MDataAnalyticsUsrGeneralConfig implements Serializable {

		private static final long serialVersionUID = 1L;

		/** グループIDごとの設定値 key:設定項目、value:設定値 **/
		private Map<String, String> dataAnalyticsUsrGeneralConfigMap;

		/** 設定値初期値 key:設定項目、value:設定値 **/
		private Map<String, String> dataAnalyticsUsrGeneralDefaultConfigMap;

		/**
		 * コンストラクタ
		 *
		 * @param dataAnalyticsUsrGeneralConfigMap
		 * @param dataAnalyticsUsrGeneralDefaultConfigMap
		 * @return
		 */
		public MDataAnalyticsUsrGeneralConfig(Map<String, String> dataAnalyticsUsrGeneralConfigMap, Map<String, String> dataAnalyticsUsrGeneralDefaultConfigMap) {
			this.dataAnalyticsUsrGeneralConfigMap = dataAnalyticsUsrGeneralConfigMap;
			this.dataAnalyticsUsrGeneralDefaultConfigMap = dataAnalyticsUsrGeneralDefaultConfigMap;
		}

		/**
		 * キーに対する設定値を取得します。
		 *
		 * @param groupMasterKey
		 * @return
		 */
		public String getMasterValue(String groupMasterKey) {
			return this.dataAnalyticsUsrGeneralConfigMap.containsKey(groupMasterKey) ? this.dataAnalyticsUsrGeneralConfigMap.get(groupMasterKey) : this.dataAnalyticsUsrGeneralDefaultConfigMap.get(groupMasterKey);
		}

		/**
		 * 上記ソースは変更しない。
		 * 変更は下記に追加していく。
		 */

		/**
		 * ツールの利用許可サービスIDを取得します。（カンマ区切り）
		 * 
		 * @return
		 */
		public List<String> allowedAnalyticsToolServiceIdList() {
			 String allowedAnalyticsToolServiceIds = getMasterValue(ALLOWED_SERVICE_ID_KEY);
			 List<String> emptyServiceIdList = new ArrayList<>();
			 return StringUtils.isEmpty(allowedAnalyticsToolServiceIds) ? emptyServiceIdList : Arrays.asList(allowedAnalyticsToolServiceIds.split(","));
		}

		/**
		 * 利用許可のあるツールであるか判定します。
		 * >ログイン時にシステム設定ツールの利用許可があるか判別
		 * @param serviceId
		 * @return
		 */
		public boolean isAuthorizedAnalyticsTool(String serviceId) {
			return allowedAnalyticsToolServiceIdList().contains(serviceId);
		}
	}

	/**
	 * ツール利用者ごとの設定
	 *   利用状況確認ツールユーザ汎用マスタでのみ使用
	 *   ※1) インスタンス生成時の値を変更させないためにsetterは追加しない。
	 *   ※2) メンバの値を変更する場合はインスタンスを生成し直す。
	 */
	public static class MDataAnalyticsSvcGeneralConfig implements Serializable {

		private static final long serialVersionUID = 1L;

		/** グループIDごとの設定値 key:設定項目、value:設定値 **/
		private Map<String, String> dataAnalyticsSvcGeneralConfigMap;

		/** 設定値初期値 key:設定項目、value:設定値 **/
		private Map<String, String> dataAnalyticsSvcGeneralDefaultConfigMap;

		/**
		 * コンストラクタ
		 *
		 * @param dataAnalyticsSvcGeneralConfig
		 * @param dataAnalyticsSvcGeneralDefaultConfigMap
		 * @return
		 */
		public MDataAnalyticsSvcGeneralConfig(Map<String, String> dataAnalyticsSvcGeneralConfigMap, Map<String, String> dataAnalyticsSvcGeneralDefaultConfigMap) {
			this.dataAnalyticsSvcGeneralConfigMap = dataAnalyticsSvcGeneralConfigMap;
			this.dataAnalyticsSvcGeneralDefaultConfigMap = dataAnalyticsSvcGeneralDefaultConfigMap;
		}

		/**
		 * キーに対する設定値を取得します。
		 *
		 * @param groupMasterKey
		 * @return
		 */
		public String getMasterValue(String groupMasterKey) {
			return this.dataAnalyticsSvcGeneralConfigMap.containsKey(groupMasterKey) ? this.dataAnalyticsSvcGeneralConfigMap.get(groupMasterKey) : this.dataAnalyticsSvcGeneralDefaultConfigMap.get(groupMasterKey);
		}

		/**
		 * 上記ソースは変更しない。
		 * 変更は下記に追加していく。
		 */

		/**
		 * ツールの利用許可サービスIDを取得します。（カンマ区切り）
		 * 
		 * @return
		 */
		public List<String> allowedAnalyticsToolServiceIdList() {
			 String allowedAnalyticsToolServiceIds = getMasterValue(ALLOWED_SERVICE_ID_KEY);
			 List<String> emptyServiceIdList = new ArrayList<>();
			 return StringUtils.isEmpty(allowedAnalyticsToolServiceIds) ? emptyServiceIdList : Arrays.asList(allowedAnalyticsToolServiceIds.split(","));
		}

		/**
		 * 利用許可のあるツールであるか判定します。
		 * >ログイン時にシステム設定ツールの利用許可があるか判別
		 * @param serviceId
		 * @return
		 */
		public boolean isAuthorizedAnalyticsTool(String serviceId) {
			return allowedAnalyticsToolServiceIdList().contains(serviceId);
		}
	}

	/**
	 * マスメンAPIユーザ（マスタメンテ組込みjarAPI通信用）
	 */
	public static class DummyUser implements Serializable {
		
		private static final long serialVersionUID = 1L;

		private User user;
		
		private String accessToken;
		
		private String apiKey;

		public User getUser() {
			return user;
		}

		public void setUser(User user) {
			this.user = user;
		}

		public String getAccessToken() {
			return accessToken;
		}

		public void setAccessToken(String accessToken) {
			this.accessToken = accessToken;
		}

		public String getApiKey() {
			return apiKey;
		}

		public void setApiKey(String apiKey) {
			this.apiKey = apiKey;
		}
	}
	
	/** 機能名 */
	public String getFunctionName() {
		return functionName;
	}

	/** 機能名 */
	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}

	/** テンプレートシーケンス */
	public void setTemplateSeqCached(Long templateSeq) {
		templateSeqCached = templateSeq;
	}

	/** テンプレートシーケンス */
	public Long getTemplateSeqCached() {
		return templateSeqCached;
	}

	/** 汎用マスタ */
	public HospitalConfig getHospitalConfig() {
		return hospitalConfig;
	}

	/** 汎用マスタ */
	public void setHospitalConfig(HospitalConfig hospitalConfig) {
		this.hospitalConfig = hospitalConfig;
	}

	/** 利用者管理マスタ */
	public MUserConfig getMUserConfig() {
		return mUserConfig;
	}

	/** 利用者管理マスタ */
	public void setMUserConfig(MUserConfig mUserConfig) {
		this.mUserConfig = mUserConfig;
	}

	/** 病院オプションマスタ */
	public HospitalOptApiResponseDxo getHospitalOptApi() {
		return hospitalOptApi;
	}

	/** 病院オプションマスタ */
	public void setHospitalOptApi(HospitalOptApiResponseDxo hospitalOptApi) {
		this.hospitalOptApi = hospitalOptApi;
	}

	/** 診療科 */
	public List<DepartmentDto> getDepartmentList() {
		return departmentDto;
	}

	/** 診療科 */
	public void setDepartmentList(List<DepartmentDto> departmentDto) {
		this.departmentDto = departmentDto;
	}

	/** 利用状況確認ツールグループ汎用マスタ */
	public MDataAnalyticsGrpGeneralConfig getMDataAnalyticsGrpGeneralConfig() {
		return mDataAnalyticsGrpGeneralConfig;
	}

	/** 利用状況確認ツールグループ汎用マスタ */
	public void setMDataAnalyticsGrpGeneralConfig(MDataAnalyticsGrpGeneralConfig mDataAnalyticsGrpGeneralConfig) {
		this.mDataAnalyticsGrpGeneralConfig = mDataAnalyticsGrpGeneralConfig;
	}

	/** マスメンAPIユーザ */
	public DummyUser getDummyUser() {
		return dummyUser;
	}

	/** マスメンAPIユーザ */
	public void setDummyUser(DummyUser dummyUser) {
		this.dummyUser = dummyUser;
	}
	
}
