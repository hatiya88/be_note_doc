package net.humanbridge.conmanagement.web.service.custom;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import net.humanbridge.conmanagement.excel.cbean.OrderBy.DataType;
import net.humanbridge.conmanagement.excel.cbean.SheetCB;
import net.humanbridge.conmanagement.excel.entity.CellDto;
import net.humanbridge.conmanagement.excel.entity.RowDto;
import net.humanbridge.conmanagement.util.ExcelUtils;
import net.humanbridge.conmanagement.util.MiscUtils;
import net.humanbridge.conmanagement.util.ThreadLocalUtils;
import net.humanbridge.conmanagement.web.dbflute.exbhv.MConManageGeneralBhv;
import net.humanbridge.conmanagement.web.dbflute.exbhv.MSelectionBhv;
import net.humanbridge.conmanagement.web.dbflute.exbhv.MTemplateItemBhv;
import net.humanbridge.conmanagement.web.dbflute.exentity.MSelection;
import net.humanbridge.conmanagement.web.dbflute.exentity.MTemplateItem;
import net.humanbridge.conmanagement.web.dto.UserSessionDto;
import net.humanbridge.conmanagement.web.dto.UserSessionDto.HospitalConfig;
import net.humanbridge.conmanagement.web.dto.UserSessionDto.ServiceDto;
import net.humanbridge.conmanagement.web.dto.custom.IconDto;
import net.humanbridge.conmanagement.web.service.ExcelLoadBhv;


/**
 * アイコン設定サービス
 */
@Service
public class IconManageService {

	@Autowired
	private MSelectionBhv mSelectionBhv;

	@Autowired
	private MTemplateItemBhv mTemplateItemBhv;

	@Autowired
	private ExcelLoadBhv excelLoadBhv;

	/** コンシェルジュの共通グループID */
	@Value("${common-group-id}")
	private String commonGroupId;

	/** マスタメンテテーブル */
	private static final String TABLE_LAYOUT_SECTION = "layout_section";	
	private static final String TABLE_SECTION_ITEM = "section_item";
	private static final String TABLE_SERVICE = "service";

	/**
	 * アイコン設定画面表示用データ取得
	 * 
	 * @param userSessionDto
	 * @param serviceDto
	 * @param templateSeq テンプレートマスタ - template_seq
	 * @return List<IconContentDto> 画面表示項目DTO
	 * 
	 * @throws Exception
	 */
    public List<IconDto> getIconDtoList(UserSessionDto userSessionDto, ServiceDto serviceDto) throws Exception {

    	/** section_itemマスタ取得 */
		List<RowDto> sectionItemList = getSectionItemList(userSessionDto, serviceDto);

		/** 共通グループIDで取得 */
		// [service]マスタ -- 全件取得
		List<RowDto> serviceList = getServiceList(userSessionDto, serviceDto);
		// serviceマスタ
		Map<String, RowDto> serviceMap = serviceList.stream()
			.collect(Collectors.toMap(
			(RowDto r) -> r.get("service_id").getValue(),
			(RowDto r) -> r)
		);

		/** アイコン選択肢取得マップ */		
		HashMap<String,String> mSelectionMap = getIconSelectionMap();

		/** 汎用マスタ取得 */
		HospitalConfig hospitalConfig = ThreadLocalUtils.getHospitalConfig();
		String contentsSeviceId = hospitalConfig.getMasterValue(MConManageGeneralBhv.CONTENTS_SERVICE_ID_KEY);

		/** アイコン設定データ作成 */
		List<IconDto> iconDtoList = new ArrayList<>();
		IconDto iconDto;

		for (RowDto sectionItem : sectionItemList) {

			// section_item、serviceマスタの項目
			RowDto service = serviceMap.get(sectionItem.get("item_value").getValue());
			if (service == null) {
				continue;
			}
			iconDto = new IconDto(sectionItem, service);
			
			// 名称で表示する項目
			iconDto.setIconName(mSelectionMap.get(service.get("icon_file").getValue()));	// アイコン名称
			// 編集ボタン表示可否 (サービス名表示判定も同じ）
			if (checkContentsService(contentsSeviceId, sectionItem.get("item_value").getValue())){
				iconDto.setButtonFlg(true);
				iconDto.setServiceName(IconDto.CONTENT_NAME);	// サービス名
			} else {
				iconDto.setButtonFlg(false);
				iconDto.setServiceName(service.get("name").getValue());	// サービス名
			}

			iconDtoList.add(iconDto);
		}
		return iconDtoList;		
	}

	/**
	 * 項目「アイコン」の選択肢取得
	 * 
	 * @return
	 */
	public List<MSelection> getIconSelectionList() {
		/** テンプレート項目マスタ取得 **/
		List<MTemplateItem> mTemplateItemList = mTemplateItemBhv.findByTemplateSeqSearch(ThreadLocalUtils.getTemplateSeq());
		MTemplateItem templateItem = null;
		for (MTemplateItem item : mTemplateItemList) {
			if (StringUtils.equals(item.getColumnName(), "icon_file")) {
				templateItem = item;
				break;
			}
		}

		/** 選択肢マスタ取得 **/
		List<MSelection> mSelectionList = new ArrayList<>(); 
		List<MSelection> mSelectionDataList = mSelectionBhv.findByTemplateSeqSearch(templateItem.getTemplateItemSeq());
		MSelection mSelection = new MSelection();
		mSelection.setLabel("");
		mSelection.setValue("");
		mSelectionList.add(mSelection); // 選択肢に空白を入れる
		for (MSelection Selection : mSelectionDataList) {
			mSelectionList.add(Selection);	
		}		
		return mSelectionList;
	}

	/**
	 * 項目「アイコン」の選択肢マップ
	 * 
	 * @return
	 */
	public HashMap<String, String>  getIconSelectionMap() {
		/** アイコン選択取得 **/
		List<MSelection> mSelectionList = getIconSelectionList();

		HashMap<String, String> mSelectionMap = new HashMap<>();
		for (MSelection mSelection : mSelectionList) {
			mSelectionMap.put(mSelection.getValue(), mSelection.getLabel());
		}
		return mSelectionMap;
	}
	
	/**
	 * section_itemマスタ取得
	 * 
	 * @param userSessionDto
	 * @param serviceDto
	 * @return
	 * @throws Exception
	 */
	public List<RowDto> getSectionItemList (UserSessionDto userSessionDto, ServiceDto serviceDto) throws Exception {
    	// [layout_section]マスタ -- [section_style=icon]のデータを取得
		SheetCB cb = new SheetCB(TABLE_LAYOUT_SECTION);
		cb.query().setEqual("section_style", "icon");
		Map<String, SheetCB> conditionMap = new HashMap<>();
		conditionMap.put(cb.getTableName(), cb);
		// [section_item] -- 全件取得
		cb = new SheetCB(TABLE_SECTION_ITEM);
		conditionMap.put(cb.getTableName(), cb);
		Map<String, List<RowDto>> sectionMap = excelLoadBhv.selectList(serviceDto, userSessionDto, conditionMap);

		// layout_section よりsection_style=iconの seq取得
		List<RowDto> layoutSectionList = sectionMap.get(TABLE_LAYOUT_SECTION);
		List<String> seqList = layoutSectionList.stream().map((RowDto row) -> {
			CellDto dto = row.get("seq");
			return dto.getValue();
		}).collect(Collectors.toList());

		// section_style=iconのデータがないとき
		if (seqList.isEmpty()){
			return new ArrayList<RowDto>();
		}
		
		// section_itemよりlayout_section_seqがiconのlayout_sectionのseqであるリストを抽出
		List<RowDto> sectionItemList = sectionMap.get(TABLE_SECTION_ITEM);
		cb = new SheetCB(TABLE_SECTION_ITEM);
		cb.query().setInScope("layout_section_seq", seqList);
		cb.query().addOrderBy_Asc_WithDataType("precedence", DataType.NUMBER);
		sectionItemList = ExcelUtils.extractRowDtoList(sectionItemList, cb);
		return sectionItemList;
	}
	
	/**
	 * layout_sectionマスタのseq取得
	 * 
	 * @param userSessionDto
	 * @param serviceDto
	 * @return layout_section_seq
	 * @throws Exception
	 */
	public String getLayoutSectionSeq(UserSessionDto userSessionDto, ServiceDto serviceDto) throws Exception {		
    	// layout_sectionマスタからsection_style=iconのデータを取得
		SheetCB cb = new SheetCB(TABLE_LAYOUT_SECTION);
		cb.query().setEqual("section_style", "icon");
		Map<String, SheetCB> conditionMap = new HashMap<>();
		conditionMap.put(cb.getTableName(), cb);
		Map<String, List<RowDto>> sectionMap = excelLoadBhv.selectList(serviceDto, userSessionDto, conditionMap);

		// layout_sectionからsection_style=iconの seq取得
		List<RowDto> layoutSectionList = sectionMap.get(TABLE_LAYOUT_SECTION);
		List<String> seqList = layoutSectionList.stream().map((RowDto row) -> {
			CellDto dto = row.get("seq");
			return dto.getValue();
		}).collect(Collectors.toList());

		// section_style=iconのデータが存在しない場合は空文字（実運用上1件しかありえないので、1件目を取得）
		return !CollectionUtils.isEmpty(seqList) ? seqList.get(0) : "";
	}
	
	/**
	 * serviceマスタ(共通グループ)取得
	 * 
	 * @param userSessionDto
	 * @param serviceDto
	 * @return
	 * @throws Exception
	 */
	public List<RowDto> getServiceList(UserSessionDto userSessionDto, ServiceDto serviceDto) throws Exception {
		ServiceDto serviceDtoCommon = serviceDto.clone();
		serviceDtoCommon.setContractGroupId(commonGroupId);
		serviceDtoCommon.setGroupId("");		
		Map<String, List<RowDto>> serviceMasterMap = excelLoadBhv.selectList(serviceDtoCommon, userSessionDto, Arrays.asList(TABLE_SERVICE));
		List<RowDto> serviceList = serviceMasterMap.get(TABLE_SERVICE);
		return serviceList;
	}
	
	 /**
     * コンテンツ表示を示すserviceIDの枝番最大値取得
     * 
     * @param userSessionDto
     * @param serviceDto
     * @return
     * @throws Exception
     */
    public int getMaxServiceIdBranchNo(UserSessionDto userSessionDto, ServiceDto serviceDto) throws Exception {

    	/** 汎用マスタ取得 */
		HospitalConfig hospitalConfig = ThreadLocalUtils.getHospitalConfig();
		String contentsSeviceId = hospitalConfig.getMasterValue(MConManageGeneralBhv.CONTENTS_SERVICE_ID_KEY);

		// serviceマスタ取得
		List<RowDto> serviceList = getServiceList(userSessionDto, serviceDto);
		// 枝番の最大値取得
		int maxBranch = 0;
		for (RowDto serviceMaster : serviceList) {
			CellDto dto = serviceMaster.get("service_id");
			// コンテンツ表示か
			if (checkContentsService(contentsSeviceId, dto.getValue()) && contentsSeviceId.length() < dto.getValue().length()) {
				String branch =  dto.getValue().substring(contentsSeviceId.length() + 1, dto.getValue().length());
				if (!MiscUtils.isEmpty(branch)) {					
					int branchNo = Integer.valueOf(branch);
					if (branchNo > maxBranch) {
						maxBranch = branchNo;
					}
				}
			}
		}
		maxBranch ++;
		return maxBranch;
    }

    /**
     * 編集ボタンの表示可否
     * (コンテンツ表示か否か)
     * 
     * @param contentsSeviceId
     * @param itenValue
     * @return
     */
    public Boolean checkContentsService(String contentsSeviceId, String itenValue) {
    	if (MiscUtils.isEmpty(contentsSeviceId) || contentsSeviceId.length() == 0) {
    		return false;
    	}
    	if (!MiscUtils.isEmpty(itenValue) && itenValue.substring(0, contentsSeviceId.length()).equals(contentsSeviceId)) {
    		return true;
    	}
    	return false;
    }
}
