package net.humanbridge.conmanagement.totp.mapper;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * 指定したユーザーの秘密鍵の登録状況
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class TotpUserStatusMapper implements Serializable {

	/** Serial version UID. (Default) */
	private static final long serialVersionUID = 1L;

	/** 
	 * 登録状況の詳細
	 * active         秘密鍵が有効
	 * inactive       秘密鍵が利用不可
	 * notregistered  秘密鍵が未生成
	 *  */
	@JsonProperty("status")
	private String status;

	/** 確認した時間 */
	@JsonProperty("check_time")
	private String checkTime;

	/** エラーコード */
	@JsonProperty("ErrorCode")
	private String errorCode;

	/** エラーメッセージ */
	@JsonProperty("ErrorMessage")
	private String errorMessage;
}
