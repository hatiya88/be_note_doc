package net.humanbridge.conmanagement.web.service;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.humanbridge.conmanagement.external.call.MasterUploadApiCall;
import net.humanbridge.conmanagement.external.exception.MaintenanceApiCallException;
import net.humanbridge.conmanagement.web.dto.UserSessionDto;
import net.humanbridge.conmanagement.web.dto.UserSessionDto.ServiceDto;
import net.humanbridge.conmanagement.web.exception.UploadException;
import net.humanbridge.maintenance.api.rest.dto.response.MasterUploadResponseDto;

/**
 * アップロードサービス（アップロード）
 */
@Service
public class UploadService {

	@Autowired
	private MasterUploadApiCall masterUploadApiCall;

	/**
	 * マスタアップロードAPIを呼び出します。
	 * 
	 * @param serviceDto
	 * @param userSessionDto
	 * @throws IOException
	 * @throws UploadException 
	 */
	public MasterUploadResponseDto upload(ServiceDto serviceDto,
			UserSessionDto userSessionDto,
			String mode,
			byte[] bytes) throws UploadException, IOException {

		MasterUploadResponseDto uploadResponseDto = null;

		try {
			uploadResponseDto = masterUploadApiCall.call(
				serviceDto,
				userSessionDto,
				mode,
				bytes);
			
		} catch (MaintenanceApiCallException e) {
			throw new UploadException("CMG006_E0007", new String[] { userSessionDto.getLoginUserId() }, "アップロードに失敗しました。user_id:%s", e);
		}
		return uploadResponseDto;
	}

}