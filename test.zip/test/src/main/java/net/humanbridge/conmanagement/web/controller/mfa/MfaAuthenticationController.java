package net.humanbridge.conmanagement.web.controller.mfa;

import static net.humanbridge.conmanagement.constant.AppConstants.SESSION_ATTR_NAME;
import static net.humanbridge.conmanagement.constant.MfaConstants.MFA_MODEL_ATTR_NAME;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import net.humanbridge.conmanagement.totp.model.AuthenticationModel;
import net.humanbridge.conmanagement.web.controller.BaseController;
import net.humanbridge.conmanagement.web.dto.UserSessionDto;
import net.humanbridge.conmanagement.web.helper.AppHelper;
import net.humanbridge.conmanagement.web.helper.MessageHelper;
import net.humanbridge.conmanagement.web.service.totp.TotpService;

/**
 * 二要素認証画面（SST014）
 */
@Controller
@SessionAttributes(SESSION_ATTR_NAME)
@RequestMapping("/mfa")
public class MfaAuthenticationController extends BaseController {

	@Autowired
	private TotpService totpService;

	@Autowired
	private MessageHelper messageHelper;

	/**
	 * 二要素認証画面表示
	 * @param model  モデル
	 * @param userSessionDto  ユーザーセッション情報
	 * @param authenticationModel  二要素認証モデル
	 * @return 遷移先
	 * 
	 * @throws Exception
	 */
	@RequestMapping(method = RequestMethod.GET)
	public String index(
			Model model,
			@ModelAttribute(SESSION_ATTR_NAME)
			UserSessionDto userSessionDto,
			@ModelAttribute(MFA_MODEL_ATTR_NAME)
			AuthenticationModel authenticationModel
			) throws Exception {
		return indexHtml();
	}

	/**
	 * 認証ボタン押下時
	 * 
	 * @param model  モデル
	 * @param userSessionDto  ユーザーセッション情報
	 * @param authenticationModel  二要素認証モデル
	 * @return 遷移先
	 * 
	 * @throws Exception
	 */
	@RequestMapping(value = "/authentication", method = RequestMethod.POST)
	public String authentication(Model model,
			@ModelAttribute(SESSION_ATTR_NAME)
			UserSessionDto userSessionDto,
			@ModelAttribute(MFA_MODEL_ATTR_NAME)
			AuthenticationModel authenticationModel
			) throws Exception {
		try {
			//TOTPサーバに問い合わせて二要素認証を行う
			totpService.authentication(userSessionDto, authenticationModel.getOptCode());
		} catch (Exception e) {
			// エラーメッセージ出力 + 画面再描画
			messageHelper.setCommonErrorMessage(model, e.getMessage());
			return indexHtml();
		}
		return "redirect:" + AppHelper.hospitalUrl(userSessionDto.getGroupId(), "menu");
	}

	/**
	 * 認証コードを取得できない場合は「こちら」押下時
	 * 
	 * @param model  モデル
	 * @param userSessionDto  ユーザーセッション情報
	 * @param authenticationModel  二要素認証モデル
	 * @return 遷移先
	 * 
	 * @throws Exception
	 */
	@RequestMapping(value = "/recovery", method = RequestMethod.GET)
	public String recovery(
			Model model,
			@ModelAttribute(SESSION_ATTR_NAME)
			UserSessionDto userSessionDto,
			HttpSession session
			) throws Exception {
		String accessKey = "";
		try {
			//TOTPサーバに問い合わせて、「TOTPホーム画面呼び出し」に使用するアクセスキーを生成する
			accessKey = totpService.createKey(userSessionDto, session);
		} catch (Exception e) {
			// エラーメッセージ出力 + 画面再描画
			messageHelper.setCommonErrorMessage(model, e.getMessage());
			return indexHtml();
		}
		//TOTPホーム画面呼び出し（外部サイト）
		return "redirect:" + totpService.transfer(userSessionDto, accessKey);
	}

	@Override
	public String indexHtml() {
		return "mfa/index";
	}

	@Override
	public String redirectPath() {
		return "./";
	}
}
