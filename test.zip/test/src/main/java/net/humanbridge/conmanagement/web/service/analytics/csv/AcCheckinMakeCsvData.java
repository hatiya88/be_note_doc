package net.humanbridge.conmanagement.web.service.analytics.csv;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.fjqs.f2.springboot.logger.basic.F2Logger;
import lombok.val;
import net.humanbridge.conmanagement.constant.AnalyticsConstants;
import net.humanbridge.conmanagement.util.MiscUtils;
import net.humanbridge.conmanagement.web.dbflute.exbhv.TDataAnalyticsSumCntAcCheckinBhv;
import net.humanbridge.conmanagement.web.dbflute.exentity.MDataAnalyticsCsvPattern;
import net.humanbridge.conmanagement.web.dbflute.exentity.TDataAnalyticsSumCntAcCheckin;
import net.humanbridge.conmanagement.web.exception.CsvException;
import net.humanbridge.conmanagement.web.service.analytics.graph.AcCheckinMakeGraphData;

/**
 * スマートチェックインのCSVデータ作成クラス
 * @author xonogawa.koichi
 *
 */
@Service("Csv_" + AnalyticsConstants.AC_CHECKIN)
public class AcCheckinMakeCsvData extends AbstractMakeCsvData<TDataAnalyticsSumCntAcCheckin> {

	/** イベントロガー */
	private static final F2Logger logger = F2Logger.getLogger();

	@Autowired
	private TDataAnalyticsSumCntAcCheckinBhv sumCntAcCheckinBhv;

	@Autowired
	private AcCheckinMakeGraphData acCheckinMakeGraphData;
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	protected String getServiceKind() {
		return AnalyticsConstants.AC_CHECKIN;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Map<String, Long> searchPattern1(String groupId, Date fromDate, Date toDate, String deptCode, String sortColumns, String unit, int fetchAmount) {
		return this.sumCntAcCheckinBhv.getTDataAnalyticsSumCntAcCheckinForCsvPattern1(groupId, fromDate, toDate, deptCode, sortColumns, unit, fetchAmount);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void searchPattern2(String groupId, Date fromDate, Date toDate, String deptCode, MDataAnalyticsCsvPattern mDataAnalyticsCsvPattern, String deptListJson, ServletOutputStream outputStream, int fetchAmount) throws IOException {
		this.sumCntAcCheckinBhv.getTDataAnalyticsSumCntAcCheckinForCsvPattern2(groupId, fromDate, toDate, deptCode, mDataAnalyticsCsvPattern, deptListJson, outputStream, fetchAmount);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Map<String, Long> groupingData(List<TDataAnalyticsSumCntAcCheckin> data, String unit, Map<String, Long> groupByAcCheckinMap) {
		return this.acCheckinMakeGraphData.groupingTDataAnalyticsSumCntAcCheckinData(data, unit, groupByAcCheckinMap);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void makeCsv(String groupId, List<TDataAnalyticsSumCntAcCheckin> data, String targetColumns, String deptListJson, ServletOutputStream outputStream) {
		val format = this.getDateFormat();
		val deptMap = this.getDeptMap(deptListJson);

		try {
			// 明細行
			val targetColumn = targetColumns.split(",");
			for (val sumCntAcCheckin: data) {
				val lineData = new ArrayList<String>();
				// 出力項目をCSVパターンマスタに設定された順にセットする
				for (val column: targetColumn) {
					switch (column.trim()) {
						case "seq":
							lineData.add(sumCntAcCheckin.getSeq().toString());
							break;
						case "group_id":
							lineData.add(MiscUtils.defaultIfNull(sumCntAcCheckin.getGroupId()));
							break;
						case "execute_time":
							String executeTime = "";
							if (sumCntAcCheckin.getExecuteTime() != null) {
								executeTime = format.format(sumCntAcCheckin.getExecuteTime());
							}
							lineData.add(executeTime);
							break;
						case "dept_code":
							lineData.add(deptMap.getOrDefault(MiscUtils.defaultIfNull(sumCntAcCheckin.getDeptCode()), ""));
							break;
						case "patient_id":
							lineData.add(MiscUtils.defaultIfNull(sumCntAcCheckin.getPatientId()));
							break;
						case "up_date":
							String upDate = "";
							if (sumCntAcCheckin.getUpDate() != null) {
								upDate = format.format(sumCntAcCheckin.getUpDate());
							}
							lineData.add(upDate);
							break;
					}
				}
				String byteData = '"' + String.join('"' + "," + '"', lineData) + '"' + AnalyticsConstants.LINE_SEPARATOR;
				outputStream.write(byteData.getBytes("MS932"));
			}

		} catch (IOException e) {
			logger.log("ECMG0103", e, e.getMessage());
			throw new CsvException(e.getMessage());
		}
	}
}
