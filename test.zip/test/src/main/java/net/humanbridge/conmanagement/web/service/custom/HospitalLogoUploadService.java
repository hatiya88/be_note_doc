package net.humanbridge.conmanagement.web.service.custom;

import java.io.IOException;

import net.humanbridge.conmanagement.external.call.ConciergeHospitalLogoUploadApiCall;
import net.humanbridge.conmanagement.external.exception.ConciergeApiCallException;
import net.humanbridge.conmanagement.web.dto.UserSessionDto;
import net.humanbridge.conmanagement.web.exception.UploadException;
import net.humanbridge.conmanagement.web.model.custom.HospitalLogoModel;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


/**
 * 病院ロゴアップロードサービス（コンシェルジュ専用）
 */
@Service
public class HospitalLogoUploadService {

	@Autowired
	private ConciergeHospitalLogoUploadApiCall conciergeHospitalLogoUploadApiCall;

	/**
	 * ロゴアップロードAPIを呼び出します。
	 *
	 * @param contractGroupId
	 * @param serviceId
	 * @param userSessionDto
	 * @param hospitalLogoModel
	 * @throws IOException
	 * @throws UploadException
	 */
	public String apiCall(String contractGroupId,
			String serviceId,
			UserSessionDto userSessionDto,
			HospitalLogoModel hospitalLogoModel) throws UploadException, IOException {

		String uploadResponseDto = null;

		try {
			uploadResponseDto = conciergeHospitalLogoUploadApiCall.call(
				userSessionDto.getServiceCached(contractGroupId, serviceId),
				hospitalLogoModel.getUpLoadFile().getBytes());
		} catch (ConciergeApiCallException e) {
			throw new UploadException("CMG003-5_E0006", new String[] {userSessionDto.getLoginUserId() }, "アップロードに失敗しました。user_id:%s");
		}
		return uploadResponseDto;
	}

}
