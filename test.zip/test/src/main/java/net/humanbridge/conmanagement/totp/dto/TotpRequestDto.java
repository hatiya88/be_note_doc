package net.humanbridge.conmanagement.totp.dto;

import lombok.Data;

@Data
public class TotpRequestDto {

	/** ユーザーID */
	private String userId;

	/** クライアントID */
	private String clientId;

	/** クライアントシークレット */
	private String clientSecret;

	/** Webアプリ側で生成するランダムの文字列（クロスサイトリクエストフォージェリ防止用） */
	private String state;

	/** TOTP（トークンアプリに表示された数字6桁） */
	private int totp;
}
