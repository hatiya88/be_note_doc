package net.humanbridge.conmanagement.web.service.analytics.csv;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.humanbridge.conmanagement.constant.AnalyticsConstants;
import net.humanbridge.conmanagement.web.dbflute.exbhv.TDataAnalyticsSumCntPrcDispBhv;
import net.humanbridge.conmanagement.web.dbflute.exentity.MDataAnalyticsCsvPattern;
import net.humanbridge.conmanagement.web.dbflute.exentity.TDataAnalyticsSumCntPrcDisp;
import net.humanbridge.conmanagement.web.service.analytics.graph.PrcDispMakeGraphData;

/**
 * 予約表示のCSVデータ作成クラス
 * @author xonogawa.koichi
 *
 */
@Service("Csv_" + AnalyticsConstants.PRC_DISP)
public class PrcDispMakeCsvData extends AbstractMakeCsvData<TDataAnalyticsSumCntPrcDisp> {

	@Autowired
	private TDataAnalyticsSumCntPrcDispBhv sumCntPrcDispBhv;

	@Autowired
	private PrcDispMakeGraphData prcDispMakeGraphData;

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected String getServiceKind() {
		return AnalyticsConstants.PRC_DISP;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Map<String, Long> searchPattern1(String groupId, Date fromDate, Date toDate, String deptCode, String sortColumns, String unit, int fetchAmount) {
		return this.sumCntPrcDispBhv.getTDataAnalyticsSumCntPrcDispForCsvPattern1(groupId, fromDate, toDate, sortColumns, unit, fetchAmount);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void searchPattern2(String groupId, Date fromDate, Date toDate, String deptCode, MDataAnalyticsCsvPattern mDataAnalyticsCsvPattern, String deptListJson, ServletOutputStream outputStream, int fetchAmount) throws IOException {
		this.sumCntPrcDispBhv.getTDataAnalyticsSumCntPrcDispForCsvPattern2(groupId, fromDate, toDate, mDataAnalyticsCsvPattern, deptListJson, outputStream, fetchAmount);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Map<String, Long> groupingData(List<TDataAnalyticsSumCntPrcDisp> data, String unit, Map<String, Long> groupByPrcDispMap) {
		return prcDispMakeGraphData.groupingTDataAnalyticsSumCntPrcDispData(data, unit, groupByPrcDispMap);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void makeCsv(String groupId, List<TDataAnalyticsSumCntPrcDisp> data, String targetColumns, String deptListJson, ServletOutputStream outputStream) {
		throw new UnsupportedOperationException("予約表示はパターン①以外のCSV出力は存在しません。");
	}
}
