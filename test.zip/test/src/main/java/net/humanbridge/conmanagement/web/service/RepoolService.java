package net.humanbridge.conmanagement.web.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.humanbridge.conmanagement.external.call.MasterRepoolApiCall;
import net.humanbridge.conmanagement.external.exception.MaintenanceApiCallException;
import net.humanbridge.conmanagement.web.dto.UserSessionDto;
import net.humanbridge.conmanagement.web.dto.UserSessionDto.ServiceDto;
import net.humanbridge.conmanagement.web.exception.RepoolException;
import net.humanbridge.conmanagement.web.model.RepoolModel;

/**
 * 再プール処理サービス
 */
@Service
public class RepoolService {

	@Autowired
	private MasterRepoolApiCall masterRepoolApiCall;

	/** コンシェルジュ再プールApi Path */
	private static final String CONCIERGE_REPOOL_PATH = "/clearCache";
	/** コンシェルジュ再プールApi Label */
	private static final String CONCIERGE_REPOOL_LABEL = "マスタキャッシュクリア";
	/** コンシェルジュ再プールApi Method */
	private static final String CONCIERGE_REPOOL_METHOD = "post";
	
	/**
	 * 再プール処理を実行します。
	 *
	 * @param serviceDto
	 *            サービス情報
	 * @param userSessionDto
	 *            ユーザーセッション情報
	 * @param repoolModel
	 *            再プール処理選択モデル
	 * @throws RepoolException 
	 */
	public void repool(ServiceDto serviceDto, UserSessionDto userSessionDto, RepoolModel repoolModel) throws RepoolException {
		/** 再プール処理の実行 **/
		try {
			masterRepoolApiCall.call(
				serviceDto,
				userSessionDto,
				repoolModel.getSelectRepoolApi(),
				repoolModel.getSelectRepoolMethod());
		} catch (MaintenanceApiCallException e) {
			throw new RepoolException("CMG999_E1001", new String[] {
					userSessionDto.getLoginUserId(),
					serviceDto.getContractGroupId(),
					serviceDto.getServiceId(),
					serviceDto.getGroupId(),
					e.getMessage()
				}, "再プール処理が失敗しました。userId:%s, contractGroupId:%s, serviceId:%s, groupId:%s | %s",
				e
			);
		}
	}
	
	/**
	 * コンシェルジュ マスタキャッシュクリア
	 * 
	 * @param serviceDto
	 * @param userSessionDto
	 * @throws RepoolException
	 */
	public void conciergeRepool(ServiceDto serviceDto, UserSessionDto userSessionDto) throws RepoolException {	
		// コンシェルジュ マスタキャッシュクリア
		RepoolModel repoolModel = new RepoolModel();
		repoolModel.setSelectRepoolApi(CONCIERGE_REPOOL_PATH);
		repoolModel.setSelectRepoolLabel(CONCIERGE_REPOOL_LABEL);
		repoolModel.setSelectRepoolMethod(CONCIERGE_REPOOL_METHOD);		
		repool(serviceDto, userSessionDto, repoolModel);
	}
}

