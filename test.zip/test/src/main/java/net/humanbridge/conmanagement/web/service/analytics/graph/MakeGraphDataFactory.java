package net.humanbridge.conmanagement.web.service.analytics.graph;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * グラフ作成クラスのFactoryクラス
 * @author xonogawa.koichi
 *
 */
@Component
public class MakeGraphDataFactory implements IMakeGraphDataFactory {

	/** サービス種別設定のマップ */
	@Autowired
	protected Map<String, IMakeGraphData> graphDataMap;
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public IMakeGraphData create(String serviceKind) {
		return graphDataMap.get("Graph_" + serviceKind);
	}
}
