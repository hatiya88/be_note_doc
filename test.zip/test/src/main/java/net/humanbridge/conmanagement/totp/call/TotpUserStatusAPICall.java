package net.humanbridge.conmanagement.totp.call;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fujitsu.portal.api.exception.HttpRequestException;
import jp.co.fjqs.f2.springboot.http.HttpResponse;
import net.humanbridge.conmanagement.external.exception.TOTPApiCallException;
import net.humanbridge.conmanagement.totp.mapper.TotpUserStatusMapper;

/**
 * 登録状況の取得（OTP-WA04）呼び出しクラス
 */
@Component
public class TotpUserStatusAPICall extends BaseTotpApiCall {

	/** 登録状況の取得（OTP-WA04）パス */
	@Value("${totp.user-status:/totp/webapi/v1/user-status}")
	private String path;

	/** クライアントID */
	@Value("${totp.client.id}")
	private String clientId;

	// スレッドセーフ
	private ObjectMapper mapper = new ObjectMapper();

	/**
	 * 指定したユーザーの秘密鍵の登録状況を返却する（OTP-WA04）
	 * 
	 * @param userId  ユーザID
	 * @return true：認証する / false：認証しない
	 * 
	 * @throws HttpRequestException
	 */
	public Pair<Integer, TotpUserStatusMapper> call(String userId) {
		// 要求パラメータ
		Map<String, String> reqParam = new HashMap<String, String>();
		reqParam.put("client_id", clientId);
		reqParam.put("user_id", userId);

		HttpResponse response = callGet(path, reqParam);

		TotpUserStatusMapper userStatusMapper;
		try {
			userStatusMapper = mapper.readValue(response.responseBody, TotpUserStatusMapper.class);
		} catch (IOException e) {
			logger.log("ECMG0001", e, "TOTPサーバ", e.getMessage());
			throw new TOTPApiCallException("CMG999_E0001");
		}
		return Pair.of(response.responseCode, userStatusMapper);
	}
}