package net.humanbridge.conmanagement.web.service.analytics.csv;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.fjqs.f2.springboot.logger.basic.F2Logger;
import lombok.val;
import net.humanbridge.conmanagement.constant.AnalyticsConstants;
import net.humanbridge.conmanagement.util.MiscUtils;
import net.humanbridge.conmanagement.web.dbflute.exbhv.TDataAnalyticsSumCntMtCallBhv;
import net.humanbridge.conmanagement.web.dbflute.exentity.MDataAnalyticsCsvPattern;
import net.humanbridge.conmanagement.web.dbflute.exentity.TDataAnalyticsSumCntMtCall;
import net.humanbridge.conmanagement.web.exception.CsvException;
import net.humanbridge.conmanagement.web.service.analytics.graph.MtCallMakeGraphData;

/**
 * 診察状況お知らせ(MediTrend)のCSVデータ作成クラス
 * @author xonogawa.koichi
 *
 */
@Service("Csv_" + AnalyticsConstants.MT_CALL)
public class MtCallMakeCsvData extends AbstractMakeCsvData<TDataAnalyticsSumCntMtCall> {

	/** イベントロガー */
	private static final F2Logger logger = F2Logger.getLogger();

	@Autowired
	private TDataAnalyticsSumCntMtCallBhv sumCntMtCallBhv;

	@Autowired
	private MtCallMakeGraphData mtCallMakeGraphData;

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected String getServiceKind() {
		return AnalyticsConstants.MT_CALL;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Map<String, Long> searchPattern1(String groupId, Date fromDate, Date toDate, String deptCode, String sortColumns, String unit, int fetchAmount) {
		return this.sumCntMtCallBhv.getTDataAnalyticsSumCntMtCallForCsvPattern1(groupId, fromDate, toDate, deptCode, sortColumns, unit, fetchAmount);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void searchPattern2(String groupId, Date fromDate, Date toDate, String deptCode, MDataAnalyticsCsvPattern mDataAnalyticsCsvPattern, String deptListJson, ServletOutputStream outputStream, int fetchAmount) throws IOException {
		this.sumCntMtCallBhv.getTDataAnalyticsSumCntMtCallForCsvPattern2(groupId, fromDate, toDate, deptCode, mDataAnalyticsCsvPattern, deptListJson, outputStream, fetchAmount);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Map<String, Long> groupingData(List<TDataAnalyticsSumCntMtCall> data, String unit, Map<String, Long> groupByMtCallMap) {
		return this.mtCallMakeGraphData.groupingTDataAnalyticsSumCntMtCallData(data, unit, groupByMtCallMap);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void makeCsv(String groupId, List<TDataAnalyticsSumCntMtCall> data, String targetColumns, String deptListJson, ServletOutputStream outputStream) {
		val format = this.getDateFormat();
		val deptMap = this.getDeptMap(deptListJson);

		try {
			// 明細行
			val targetColumn = targetColumns.split(",");
			for (val sumCntMtCall: data) {
				val lineData = new ArrayList<String>();
				// 出力項目をCSVパターンマスタに設定された順にセットする
				for (val column: targetColumn) {
					switch (column.trim()) {
						case "seq":
							lineData.add(sumCntMtCall.getSeq().toString());
							break;
						case "group_id":
							lineData.add(MiscUtils.defaultIfNull(sumCntMtCall.getGroupId()));
							break;
						case "execute_time":
							String executeTime = "";
							if (sumCntMtCall.getExecuteTime() != null) {
								executeTime = format.format(sumCntMtCall.getExecuteTime());
							}
							lineData.add(executeTime);
							break;
						case "dept_code":
							lineData.add(deptMap.getOrDefault(MiscUtils.defaultIfNull(sumCntMtCall.getDeptCode()), ""));
							break;
						case "patient_id":
							lineData.add(MiscUtils.defaultIfNull(sumCntMtCall.getPatientId()));
							break;
						case "up_date":
							String upDate = "";
							if (sumCntMtCall.getUpDate() != null) {
								upDate = format.format(sumCntMtCall.getUpDate());
							}
							lineData.add(upDate);
							break;
						}
				}
				String byteData = '"' + String.join('"' + "," + '"', lineData) + '"' + AnalyticsConstants.LINE_SEPARATOR;
				outputStream.write(byteData.getBytes("MS932"));
			}

		} catch (IOException e) {
			logger.log("ECMG0103", e, e.getMessage());
			throw new CsvException(e.getMessage());
		}
	}
}
