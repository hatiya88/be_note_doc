package net.humanbridge.conmanagement.web.service.custom;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import net.humanbridge.conmanagement.excel.cbean.OrderBy.DataType;
import net.humanbridge.conmanagement.excel.cbean.SheetCB;
import net.humanbridge.conmanagement.excel.entity.CellDto;
import net.humanbridge.conmanagement.excel.entity.RowDto;
import net.humanbridge.conmanagement.util.ExcelUtils;
import net.humanbridge.conmanagement.util.PublicURLUtils;
import net.humanbridge.conmanagement.web.dto.UserSessionDto;
import net.humanbridge.conmanagement.web.dto.UserSessionDto.ServiceDto;
import net.humanbridge.conmanagement.web.dto.custom.ListDto;
import net.humanbridge.conmanagement.web.exception.DownloadException;
import net.humanbridge.conmanagement.web.service.ExcelLoadBhv;


/**
 * リスト設定サービス
 */
@Service
public class ListManageService {

	@Autowired
	private ExcelLoadBhv excelLoadBhv;

	/** コンシェルジュの共通グループID */
	@Value("${common-group-id}")
	private String commonGroupId;

	/** マスタメンテテーブル */
	private static final String TABLE_LAYOUT_SECTION = "layout_section";
	private static final String TABLE_SECTION_ITEM = "section_item";
	private static final String TABLE_SERVICE = "service";

	/**
	 * リスト設定画面表示用データ取得
	 * 
	 * @param userSessionDto
	 * @param serviceDto
	 * @return List<ListManageDto> 画面表示項目DTO
	 * @throws Exception
	 */
    public List<ListDto> getListDtoList(UserSessionDto userSessionDto, ServiceDto serviceDto) throws Exception {

    	/** section_itemマスタ取得 */
		List<RowDto> sectionItemList = getSectionItemList(userSessionDto, serviceDto);

		/** 共通グループIDで取得 */
		// [service]マスタ -- 全件取得
		List<RowDto> serviceList = getServiceList(userSessionDto, serviceDto);
		// serviceマスタ
		Map<String, RowDto> serviceMap = serviceList.stream()
			.collect(Collectors.toMap(
			(RowDto r) -> r.get("service_id").getValue(),
			(RowDto r) -> r)
		);

		/** リスト設定データ作成 */
		List<ListDto> listDtoList = new ArrayList<>();
		ListDto listDto;

		for (RowDto sectionItem : sectionItemList) {
			// section_item、serviceマスタの項目
			RowDto service = serviceMap.get(sectionItem.get("item_value").getValue());
			if (service == null) {
				continue;
			}
			listDto = new ListDto(sectionItem, service);
			String url = listDto.getUrl();
			listDto.setUrl(PublicURLUtils.decode(url));
			listDtoList.add(listDto);
		}
		return listDtoList;
	}

	/**
	 * section_itemマスタ取得
	 * 
	 * @param userSessionDto
	 * @param serviceDto
	 * @return
	 * @throws Exception
	 */
	public List<RowDto> getSectionItemList (UserSessionDto userSessionDto, ServiceDto serviceDto) throws Exception {
    	// [layout_section]マスタ -- [section_style=list]のデータを取得
		SheetCB cb = new SheetCB(TABLE_LAYOUT_SECTION);
		cb.query().setEqual("section_style", "list");
		Map<String, SheetCB> conditionMap = new HashMap<>();
		conditionMap.put(cb.getTableName(), cb);
		// [section_item] -- 全件取得
		cb = new SheetCB(TABLE_SECTION_ITEM);
		conditionMap.put(cb.getTableName(), cb);
		Map<String, List<RowDto>> sectionMap = excelLoadBhv.selectList(serviceDto, userSessionDto, conditionMap);

		// layout_section よりsection_style=listの seq取得
		List<RowDto> layoutSectionList = sectionMap.get(TABLE_LAYOUT_SECTION);
		List<String> seqList = layoutSectionList.stream().map((RowDto row) -> {
			CellDto dto = row.get("seq");
			return dto.getValue();
		}).collect(Collectors.toList());

		// section_style=listのデータがないとき
		if (seqList.isEmpty()){
			return new ArrayList<RowDto>();
		}

		// section_itemよりlayout_section_seqがlistのlayout_sectionのseqであるリストを抽出
		List<RowDto> sectionItemList = sectionMap.get(TABLE_SECTION_ITEM);		
		cb = new SheetCB(TABLE_SECTION_ITEM);
		cb.query().setInScope("layout_section_seq", seqList);
		cb.query().addOrderBy_Asc_WithDataType("precedence", DataType.NUMBER);
		sectionItemList = ExcelUtils.extractRowDtoList(sectionItemList, cb);
		return sectionItemList;
	}

	/**
	 * layout_sectionマスタのseq取得
	 * 
	 * @param userSessionDto
	 * @param serviceDto
	 * @return
	 * @throws Exception
	 */
	public String getLayoutSectionSeq(UserSessionDto userSessionDto, ServiceDto serviceDto) throws Exception {
    	// [layout_section]マスタ -- [section_style=list]のデータを取得
		SheetCB cb = new SheetCB(TABLE_LAYOUT_SECTION);
		cb.query().setEqual("section_style", "list");
		Map<String, SheetCB> conditionMap = new HashMap<>();
		conditionMap.put(cb.getTableName(), cb);
		Map<String, List<RowDto>> sectionMap = excelLoadBhv.selectList(serviceDto, userSessionDto, conditionMap);

		// layout_section よりsection_style=listの seq取得
		List<RowDto> layoutSectionList = sectionMap.get(TABLE_LAYOUT_SECTION);
		List<String> seqList = layoutSectionList.stream().map((RowDto row) -> {
			CellDto dto = row.get("seq");
			return dto.getValue();
		}).collect(Collectors.toList());

		// section_style=listのデータが場合は空文字
		return !CollectionUtils.isEmpty(seqList) ? seqList.get(0) : "";
	}

	/**
	 * serviceマスタ(共通グループ)取得
	 * 
	 * @param userSessionDto
	 * @param serviceDto
	 * @return
	 * @throws DownloadException
	 * @throws IOException
	 */
	public List<RowDto> getServiceList (UserSessionDto userSessionDto, ServiceDto serviceDto) throws Exception {
		ServiceDto serviceDtoCommon = serviceDto.clone();
		serviceDtoCommon.setContractGroupId(commonGroupId);
		serviceDtoCommon.setGroupId("");	
		Map<String, List<RowDto>> serviceMasterMap = excelLoadBhv.selectList(serviceDtoCommon, userSessionDto, Arrays.asList(TABLE_SERVICE));
		List<RowDto> serviceList = serviceMasterMap.get(TABLE_SERVICE);
		return serviceList;
	}	
}
