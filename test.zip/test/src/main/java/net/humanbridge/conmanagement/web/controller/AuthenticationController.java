package net.humanbridge.conmanagement.web.controller;

import static net.humanbridge.conmanagement.constant.AppConstants.SESSION_ATTR_NAME;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.fujitsu.portal.api.exception.HttpRequestException;

import jp.co.fjqs.f2.springboot.logger.basic.F2Logger;
import net.humanbridge.conmanagement.constant.AppConstants;
import net.humanbridge.conmanagement.util.AppUtils;
import net.humanbridge.conmanagement.web.annotation.NoAuthentication;
import net.humanbridge.conmanagement.web.dbflute.exbhv.MConManageGeneralBhv;
import net.humanbridge.conmanagement.web.dbflute.exbhv.MUserAuthBhv;
import net.humanbridge.conmanagement.web.dto.UserSessionDto;
import net.humanbridge.conmanagement.web.dto.UserSessionDto.DummyUser;
import net.humanbridge.conmanagement.web.dto.UserSessionDto.HospitalConfig;
import net.humanbridge.conmanagement.web.dto.UserSessionDto.MUserConfig;
import net.humanbridge.conmanagement.web.exception.AuthenticationException;
import net.humanbridge.conmanagement.web.exception.BusinessException;
import net.humanbridge.conmanagement.web.exception.InvalidMasterConfigException;
import net.humanbridge.conmanagement.web.helper.AppHelper;
import net.humanbridge.conmanagement.web.helper.MessageHelper;
import net.humanbridge.conmanagement.web.model.LoginModel;
import net.humanbridge.conmanagement.web.service.AuthenticationService;
import net.humanbridge.conmanagement.web.service.analytics.AnalyticsOnlyService;
import net.humanbridge.conmanagement.web.service.totp.TotpService;

/**
 *
 * 利用者認証コントローラ（ログイン・ログアウト）
 */
@Controller
@SessionAttributes(SESSION_ATTR_NAME)
public class AuthenticationController extends BaseController {

	@Autowired
	private AuthenticationService authenticationService;

	@Autowired
	private MConManageGeneralBhv mConManageGeneralBhv;
	
	@Autowired
	private MUserAuthBhv mUserAuthBhv;

	@Autowired
	private MessageHelper messageHelper;

	@Autowired
	private AnalyticsOnlyService analyticsOnlyService;

	@Autowired
	private TotpService totpService;

	private static final F2Logger logger = F2Logger.getLogger();

	@ModelAttribute(SESSION_ATTR_NAME)
	public UserSessionDto initSessionModel() {
		return new UserSessionDto();
	}
	
	/** ツールサービスID */
	@Value("${conmanagement.param.serviceId}")
	private String toolServiceId;

	/** ログインID補完用ダミードメイン */
	@Value("${dummy.domain}")
	private String dummyDomain;

	/**
	 * ログイン画面を表示します。
	 *
	 * @param loginModel
	 *            認証情報
	 * @return ログイン画面
	 */
	@NoAuthentication
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String index(LoginModel loginModel) {
		return "login/index";
	}

	/**
	 * 利用者認証します。
	 * 
	 * 本ログイン処理で、ログインユーザの他、マスメンAPIユーザ、システム連携PF接続用ユーザの認証を行います。
	 * マスメンAPIユーザはサービスIDがSVC000000000011である必要があるため、他のユーザもSVC000000000011で認証しています。
	 * 認証ユーザ、サービスIDなどの詳細は以下のファイルにまとめいています。
	 * \\10.107.246.10\egmain\60.コンシェルジュ\23.V3開発\05.利用状況確認ツールWeb化\ユーザーごとのAPI使用状況.xlsx
	 * \\10.107.246.10\egmain\60.コンシェルジュ\23.V3開発\05.利用状況確認ツールWeb化\認証サービスIDについて.xlsx
	 *
	 * @param request
	 *            リクエスト
	 * @param model
	 *            モデル
	 * @param loginModel
	 *            認証情報
	 * @param result
	 *            入力チェック結果
	 * @return 認証OKの場合はメインメニュー画面を表示、NGの場合はログイン画面を表示
	 */
	@NoAuthentication
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String login(
			HttpServletRequest request,
			Model model,
			@Validated
			LoginModel loginModel,
			BindingResult result) throws Exception {

		if (result.hasErrors()) {
			// 入力エラー → ログイン画面へ
			return index(loginModel);
		}
		String contractGroupId = "";
		UserSessionDto userSessionDto = null;

		try {
			// ログインIDチェック：ダミードメインの付与
			String loginId = loginModel.getEmail();
			if (!StringUtils.contains(loginId, "@"))
				loginId = loginId + dummyDomain;

			// 利用者認証（authInfoPair：ログインユーザー情報）
			ImmutablePair<UserSessionDto, String> authInfoPair = authenticationService.login(loginId, loginModel.getPassword());
			userSessionDto = authInfoPair.getLeft();
			contractGroupId = authInfoPair.getRight();
			userSessionDto.setGroupId(contractGroupId);

			// 汎用マスタ取得
			HospitalConfig hospitalConfig = mConManageGeneralBhv.getHospitalConfig(contractGroupId);
			userSessionDto.setHospitalConfig(hospitalConfig);
			
			// 利用者管理マスタの取得
			MUserConfig mUserConfig = mUserAuthBhv.getMUserConfig(userSessionDto.getLoginUserId());
			userSessionDto.setMUserConfig(mUserConfig);

			// ツールの利用権限の確認
			// 利用者管理マスタ、利用状況確認ツールグループ汎用マスタのどちらにも登録がないユーザーは使えない
			if (!mUserConfig.isAuthorizedTool(toolServiceId) && !mUserConfig.allowedDataAnalyticsFlag().equals("1")) {
				throw new AuthenticationException("CMG001_W0003", new String[] { userSessionDto.getLoginUserId() },
						"ツールの利用権限がありません。user_id:%s");
			}

			// マスメンAPIユーザ(マスタメンテ組込みjarの共通権限チェック対応)
			DummyUser dummyUser = authenticationService.dummyUserLogin();
			userSessionDto.setDummyUser(dummyUser);

			// 利用状況確認ツール使用時にのみ必要なデータを取得する
			if (mUserConfig.allowedDataAnalyticsFlag().equals("1")) {
				userSessionDto = analyticsOnlyService.getAnalyticsData(userSessionDto, contractGroupId, request);
			}

			// セッションに設定
			model.addAttribute(SESSION_ATTR_NAME, userSessionDto);

			HttpSession session = AppUtils.createNewSession(request);

			// ログインユーザー情報
			session.setAttribute(AppConstants.SESSION_KEY_LOGIN_USER, userSessionDto.getLoginUser());

			// CSRF対策トークン
			session.setAttribute(AppConstants.SESSION_KEY_CSRF_TOKEN, AppUtils.generateCsrfToken());

		} catch (BusinessException e) {
			// ログインエラー → ログイン画面へ
			logger.log("WCMG0008", AppUtils.emailMasking(loginModel.getEmail()), e);
			String displayMsg = StringUtils.isNotEmpty(e.getDisplayErrorMsgs()) ? e.getDisplayErrorMsgs() : e.getDefaultMessage();
			result.reject(e.getErrorMessageId(), e.getErrorMessageArguments(), displayMsg);
			return index(loginModel);
		} catch (HttpRequestException e) {
			// WebApiエラー
			logger.log("ECMG0102", e, e.getMessageCode(), e.getMessage());
			messageHelper.setCommonErrorMessage(model, "CMG999_E0001");
			return classifyException(model, e, "CMG999_E0001");
		} catch (InvalidMasterConfigException e) {
			// 診療科取得失敗
			logger.log("ECMG0102", e, e.getMessage(), "診療科一覧取得エラー");
			messageHelper.setCommonErrorMessage(model, "AVT001-E0003");
			return index(loginModel);
		}
		// TOTPサーバに問い合わせて二要素認証の秘密鍵の登録状況を取得する。有効の場合は認証画面へ遷移
		try {
			if (totpService.isActive(userSessionDto)) return "redirect:mfa";
		} catch (Exception e){
			messageHelper.setCommonErrorMessage(model, e.getMessage());
			return index(loginModel);
		}
		// メインメニュー画面へリダイレクト
		return "redirect:" + AppHelper.hospitalUrl(contractGroupId, "menu");
	}

	/**
	 * ログアウトします。
	 *
	 * @param request
	 *            リクエスト
	 * @param response
	 *            レスポンス
	 * @param userSessionDto
	 *            ユーザーセッション情報
	 * @return ログイン画面にリダイレクト
	 */
	@NoAuthentication
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(
			HttpServletRequest request,
			HttpServletResponse response,
			@ModelAttribute(SESSION_ATTR_NAME)
			UserSessionDto userSessionDto) {

		// ポータルからログアウト
		authenticationService.logout(userSessionDto.getAccessToken());

		// セッションを無効化
		AppUtils.invalidateSession(request, response);

		// ログイン画面へリダイレクト
		return "redirect:/";
	}

	@Override
	public String indexHtml() {
		return "login/index";
	}

	@Override
	public String redirectPath() {
		return "./";
	}

}
