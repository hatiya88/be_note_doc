package net.humanbridge.conmanagement.web.service.analytics.csv;

import java.util.Date;

import javax.servlet.ServletOutputStream;

import net.humanbridge.conmanagement.web.dbflute.exentity.MDataAnalyticsCsvPattern;
import net.humanbridge.conmanagement.web.dto.UserSessionDto;
import net.humanbridge.conmanagement.web.dto.analytics.SearchItemDto;

/**
 * CSVデータ作成インタフェース
 */
public interface IMakeCsvData {

	/**
	 * CSVデータを作成します。
	 * 
	 * @param userSessionDto
	 * @param fromDate
	 * @param toDate
	 * @param searchItemDto
	 * @param mDataAnalyticsCsvPattern
	 * @param deptListJson
	 * @return CSVデータ
	 */
	public abstract void getCsvData(UserSessionDto userSessionDto, Date fromDate, Date toDate, SearchItemDto searchItemDto, MDataAnalyticsCsvPattern mDataAnalyticsCsvPattern, String deptListJson, ServletOutputStream outputStream);
}
