package net.humanbridge.conmanagement.totp.call;

import java.util.HashMap;
import java.util.Map;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import net.humanbridge.conmanagement.web.dto.UserSessionDto;

/**
 * TOTPホーム画面呼び出しクラス
 */
@Component
public class TotpViewCall extends BaseTotpApiCall {

	// TOTPホーム画面パス（OTP-G01）
	@Value("${totp.startup:totp/startup}")
	private String startupPath;

	/** クライアントID */
	@Value("${totp.client.id}")
	private String clientId;

	/**
	 * OTP-G01 ホーム画面を作成する
	 * 二要素認証が未設定の場合は「設定に進む」ボタンが、設定済の場合は「リカバリー画面へ」ボタンが表示される
	 * 
	 * @param userSessionDto
	 * @param accessKey  OTP-WA01で取得したアクセスキー
	 * @return OTP-G01 ホーム画面のURL
	 * 
	 * @throws JsonProcessingException 
	 */
	public String transfer(UserSessionDto userSessionDto, String accessKey) throws JsonProcessingException {
		// ユーザIDとログインユーザ名のJSON形式パラメータをBase64エンコード
		Map<String, String> map = new HashMap<String, String>();
		map.put("user_id", userSessionDto.getLoginUserId());
		map.put("disp_name", userSessionDto.getLoginUserName());
		String json = new ObjectMapper().writeValueAsString(map);
		byte[] encodedBytes = Base64.encodeBase64(json.getBytes());

		// 要求パラメータ
		Map<String, String> reqParam = new HashMap<String, String>();
		reqParam.put("client_id", clientId);
		reqParam.put("access_key", accessKey);
		reqParam.put("key", new String(encodedBytes));
		return createTransferURL(reqParam, startupPath);
	}
}
