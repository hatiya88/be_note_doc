package net.humanbridge.conmanagement.web.service.analytics.graph;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.humanbridge.conmanagement.constant.AnalyticsConstants;
import net.humanbridge.conmanagement.web.dbflute.exbhv.TDataAnalyticsSumCntArPushBhv;
import net.humanbridge.conmanagement.web.dbflute.exentity.TDataAnalyticsSumCntArPush;

/**
 * アラートリマインドのグラフ作成クラス
 * @author xonogawa.koichi
 *
 */
@Service("Graph_" + AnalyticsConstants.AR_PUSH)
public class ArPushMakeGraphData extends AbstractMakeGraphData {
	
	@Autowired
	TDataAnalyticsSumCntArPushBhv tDataAnalyticsSumCntArPushBhv;

	/**
	 * アラートリマインドのグラフデータ作成
	 * @param searchTargetGroupId
	 * @param fromDate
	 * @param toDate
	 * @param unit
	 * @param deptCode
	 * @return
	 */
	public List<Map<String, Long>> getGraphData(String searchTargetGroupId, Date fromDate, Date toDate, String unit, String deptCode, int fetchAmount) {
		// データ取得し、集計単位に合わせてグルーピングする
		Map<String, Long> groupByArPushMap =tDataAnalyticsSumCntArPushBhv.getTDataAnalyticsSumCntArPush(searchTargetGroupId, fromDate, toDate, unit, fetchAmount);
		List<Map<String, Long>> groupByList = new ArrayList<Map<String, Long>>();
		groupByList.add(groupByArPushMap);
		return groupByList;
	}
	
	/**
	 * 集計単位でGroupingする
	 * @param tDataAnalyticsSumCntArPush
	 * @param unit
	 * @param groupByArPushMap
	 * @return
	 */
	public Map<String, Long> groupingTDataAnalyticsSumCntArPush(List<TDataAnalyticsSumCntArPush> tDataAnalyticsSumCntArPushList, String unit, Map<String, Long> groupByArPushMap) {
		Map<String, Long> newGroupByArPushMap = new LinkedHashMap<String, Long>();
		Map<String, Long> margeGroupByArPushMap = new LinkedHashMap<String, Long>();

		if (!tDataAnalyticsSumCntArPushList.isEmpty()) {
			SimpleDateFormat yearMonthFormat = new SimpleDateFormat(getGroupingFormat(unit));
			newGroupByArPushMap = tDataAnalyticsSumCntArPushList.stream()
					.collect(Collectors.groupingBy(p -> yearMonthFormat.format(p.getExecuteTime()), Collectors.counting()));
		}
		// 今回取得データからMapへ
		for (String key : newGroupByArPushMap.keySet()) {
			margeGroupByArPushMap.put(key, newGroupByArPushMap.getOrDefault(key, 0L));
		}
		// 前回取得分を加算する
		for (String key : groupByArPushMap.keySet()) {
			margeGroupByArPushMap.put(key, groupByArPushMap.getOrDefault(key, 0L) + newGroupByArPushMap.getOrDefault(key, 0L));
		}
		return margeGroupByArPushMap;
	}
}
