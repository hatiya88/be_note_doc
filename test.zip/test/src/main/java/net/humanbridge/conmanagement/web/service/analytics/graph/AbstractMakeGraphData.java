package net.humanbridge.conmanagement.web.service.analytics.graph;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import net.humanbridge.conmanagement.constant.AnalyticsConstants;
import net.humanbridge.conmanagement.web.dto.UserSessionDto;

/**
 * グラフデータ作成の抽象化クラス
 * @author xonogawa.koichi
 *
 */
public abstract class AbstractMakeGraphData implements IMakeGraphData {

	@Autowired
	private Environment environment;

	/**
	 * グラフ表示用データ作成
	 */
	public abstract List<Map<String, Long>> getGraphData(String searchTargetGroupId, Date fromDate, Date toDate, String unit, String deptCode, int fetchAmount);

	/**
	 * サービス種別から、検索対象テーブルの検索値となるグループIDを取得
	 * @param serviceKind
	 * @return
	 */
	public String getSearchTargetGroupId(String serviceKind, UserSessionDto userSessionDto) {
		// サービス種別ごとのグループID種別
		String serviceType = environment.getRequiredProperty(AnalyticsConstants.CONCIERGE_ANALYTIES + "." + serviceKind.toLowerCase() + AnalyticsConstants.SERVICE_ID_TYPE);
		
		switch (serviceType) {
		case "1":	// 契約グループID
			return userSessionDto.getGroupId();
		case "2":	// 連携グループID
			return userSessionDto.getProviderGroupIdMap().get(userSessionDto.getGroupId());
		case "3":	// 子サービスグループID
			String serviceId = environment.getRequiredProperty(AnalyticsConstants.CONCIERGE_ANALYTIES + "." + serviceKind.toLowerCase() + AnalyticsConstants.SERVICE_ID);
			return userSessionDto.getChildGroupIdMap().get(serviceId);
		default:
			return "";
		}
	}
	
	/**
	 * グルーピング範囲
	 * @param unit
	 * @return
	 */
	public String getGroupingFormat(String unit) {
		switch (unit) {
		case AnalyticsConstants.UNIT_HOUR:
			// 日時で集計
			return "HH";
		case AnalyticsConstants.UNIT_DAY:
			// 日にちで集計
			return "yyyyMMdd";
		case AnalyticsConstants.UNIT_MONTH:
			// 年月で集計
			return "yyyyMM";
		default:
			return "";
		}
	}
}
