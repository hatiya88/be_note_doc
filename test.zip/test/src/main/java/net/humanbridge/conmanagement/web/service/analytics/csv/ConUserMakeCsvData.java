package net.humanbridge.conmanagement.web.service.analytics.csv;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.fjqs.f2.springboot.logger.basic.F2Logger;
import lombok.val;
import net.humanbridge.conmanagement.constant.AnalyticsConstants;
import net.humanbridge.conmanagement.util.MiscUtils;
import net.humanbridge.conmanagement.web.dbflute.exbhv.TDataAnalyticsSumCntConUserBhv;
import net.humanbridge.conmanagement.web.dbflute.exentity.MDataAnalyticsCsvPattern;
import net.humanbridge.conmanagement.web.dbflute.exentity.TDataAnalyticsSumCntConUser;
import net.humanbridge.conmanagement.web.exception.CsvException;
import net.humanbridge.conmanagement.web.service.analytics.graph.ConUserMakeGraphData;

/**
 * アプリ利用者登録数のCSVデータ作成クラス
 * @author xonogawa.koichi
 *
 */
@Service("Csv_" + AnalyticsConstants.CON_USER)
public class ConUserMakeCsvData extends AbstractMakeCsvData<TDataAnalyticsSumCntConUser> {

	/** イベントロガー */
	private static final F2Logger logger = F2Logger.getLogger();

	@Autowired
	private TDataAnalyticsSumCntConUserBhv sumCntConUserBhv;

	@Autowired
	private ConUserMakeGraphData conUserMakeGraphData;
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	protected String getServiceKind() {
		return AnalyticsConstants.CON_USER;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Map<String, Long> searchPattern1(String groupId, Date fromDate, Date toDate, String deptCode, String sortColumns, String unit, int fetchAmount) {
		return this.sumCntConUserBhv.getTDataAnalyticsSumCntConUserForCsvPattern1(groupId, fromDate, toDate, sortColumns, unit, fetchAmount);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void searchPattern2(String groupId, Date fromDate, Date toDate, String deptCode, MDataAnalyticsCsvPattern mDataAnalyticsCsvPattern, String deptListJson, ServletOutputStream outputStream, int fetchAmount) throws IOException {
		this.sumCntConUserBhv.getTDataAnalyticsSumCntConUserForCsvPattern2(groupId, fromDate, toDate, mDataAnalyticsCsvPattern, deptListJson, outputStream, fetchAmount);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Map<String, Long> groupingData(List<TDataAnalyticsSumCntConUser> data, String unit, Map<String, Long> groupByConUserMap) {
		return this.conUserMakeGraphData.groupingTDataAnalyticsSumCntConUserData(data, unit, groupByConUserMap);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void makeCsv(String groupId, List<TDataAnalyticsSumCntConUser> data, String targetColumns, String deptListJson, ServletOutputStream outputStream) {
		val dateTimeFormat = this.getDateFormat();
		val dateFormat = new SimpleDateFormat("yyyy/MM/dd");

		try {
			// 明細行
			val targetColumn = targetColumns.split(",");
			for (val sumCntConUser: data) {
				val lineData = new ArrayList<String>();
				// 出力項目をCSVパターンマスタに設定された順にセットする
				for (val column: targetColumn) {
					switch (column.trim()) {
						case "seq":
							lineData.add(sumCntConUser.getSeq().toString());
							break;
						case "group_id":
							lineData.add(MiscUtils.defaultIfNull(sumCntConUser.getGroupId()));
							break;
						case "execute_time":
							String executeTime = "";
							if (sumCntConUser.getExecuteTime() != null) {
								executeTime = dateTimeFormat.format(sumCntConUser.getExecuteTime());
							}
							lineData.add(executeTime);
							break;
						case "patient_id":
							lineData.add(MiscUtils.defaultIfNull(sumCntConUser.getPatientId()));
							break;
						case "cancel_date":
							String cancelDate = "";
							if (sumCntConUser.getCancelDate() != null) {
								cancelDate = dateFormat.format(sumCntConUser.getCancelDate());
							}
							lineData.add(cancelDate);
							break;
						case "sex":
							String sex = "";
							switch (MiscUtils.defaultIfNull(sumCntConUser.getSex())) {
							case "1":
								sex = "男";
								break;
							case "2":
								sex = "女";
								break;
							case "":
								sex = "";
								break;
							default :
								sex = "不明";
								break;
							}
							lineData.add(sex);
							break;
						case "birth_day":
							String birthDate = "";
							if (sumCntConUser.getBirthDay() != null) {
								birthDate = dateFormat.format(sumCntConUser.getBirthDay());
							}
							lineData.add(birthDate);
							break;
						case "relationship":
							lineData.add(MiscUtils.defaultIfNull(sumCntConUser.getRelationship()));
							break;
						case "up_date":
							String upDate = "";
							if (sumCntConUser.getUpDate() != null) {
								upDate = dateTimeFormat.format(sumCntConUser.getUpDate());
							}
							lineData.add(upDate);
							break;
					}
				}
				String byteData = '"' + String.join('"' + "," + '"', lineData) + '"' + AnalyticsConstants.LINE_SEPARATOR;
				outputStream.write(byteData.getBytes("MS932"));
			}

		} catch (IOException e) {
			logger.log("ECMG0103", e, e.getMessage());
			throw new CsvException(e.getMessage());
		}
	}
}
