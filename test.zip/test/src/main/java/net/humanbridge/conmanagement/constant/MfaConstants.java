package net.humanbridge.conmanagement.constant;

/**
 * 二要素認証の定数クラス
 */
public class MfaConstants {

	/**
	 * 二要素認証モデル属性名
	 */
	public static final String MFA_MODEL_ATTR_NAME = "authenticationModel";

	/**
	 * 登録状況の取得（OTP-WA04）レスポンス
	 */
	//秘密鍵が有効
	public static final String MFA_KEY_ACTIVE = "active";

	//秘密鍵が未生成
	public static final String MFA_KEY_NOTREGISTERED = "notregistered";

	/**
	 * 二要素認証設定画面
	 */
	//画面表示時にクライアントに渡すラジオボタン初期値
	public static final String IS_MFA_ACTIVE = "isActive";

	//更新ボタン押下時にクライアントから受け取るラジオボタン設定値
	public static final String SELECTIONS_MFA_RADIO = "selections mfa-radio";

	//二要素認証：有効
	public static final String MFA_VALID = "valid";

}
