package net.humanbridge.conmanagement.totp.call;

import java.io.IOException;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fujitsu.portal.api.exception.HttpRequestException;
import jp.co.fjqs.f2.springboot.http.HttpResponse;
import lombok.var;
import net.humanbridge.conmanagement.external.exception.TOTPApiCallException;
import net.humanbridge.conmanagement.totp.dto.TotpRequestDto;
import net.humanbridge.conmanagement.totp.mapper.TotpCreateAccessKeyMapper;

/**
 * アクセスキーの生成（OTP-WA01）呼び出しクラス
 */
@Component
public class TotpCreateAccessKeyAPICall extends BaseTotpApiCall {

	/** アクセスキー取得（OTP-WA01）パス */
	@Value("${totp.create.access-key:/totp/webapi/v1/create/access-key}")
	private String path;

	/** クライアントID */
	@Value("${totp.client.id}")
	private String clientId;

	/** クライアントシークレット */
	@Value("${totp.client.secret}")
	private String clientSecret;

	// スレッドセーフ
	private ObjectMapper mapper = new ObjectMapper();

	/**
	 * TOTPシステムへの画面遷移および、設定手続きを行うために必要となるアクセスキーを発行する。
	 * 
	 * @param userId  ユーザID
	 * @param state  CSRF対策トークン
	 * @return アクセスキーの生成結果
	 * 
	 * @throws HttpRequestException
	 */
	public Pair<Integer, TotpCreateAccessKeyMapper> call(String userId, String state) throws JsonProcessingException {
		// 要求パラメータ
		var reqParam = new TotpRequestDto();
		reqParam.setUserId(userId);
		reqParam.setClientId(clientId);
		reqParam.setClientSecret(clientSecret);
		reqParam.setState(state);
		var json = new ObjectMapper().writeValueAsString(reqParam);

		HttpResponse response = callPost(path, json.toString());

		TotpCreateAccessKeyMapper totpCreateAccessKeyMapper;
		try {
			totpCreateAccessKeyMapper = mapper.readValue(response.responseBody, TotpCreateAccessKeyMapper.class);
		} catch (IOException e) {
			logger.log("ECMG0001", e, "TOTPサーバ", e.getMessage());
			throw new TOTPApiCallException("CMG999_E0001");
		}
		return Pair.of(response.responseCode, totpCreateAccessKeyMapper);
	}
}
