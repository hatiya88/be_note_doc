package net.humanbridge.conmanagement.web.service.analytics.csv;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * CSVデータ作成クラスのFactoryクラス
 * @author xonogawa.koichi
 *
 */
@Component
public class MakeCsvDataFactory implements IMakeCsvDataFactory {

	/** サービス種別設定のマップ */
	@Autowired
	protected Map<String, IMakeCsvData> csvDataMap;
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public IMakeCsvData create(String serviceKind) {
		return csvDataMap.get("Csv_" + serviceKind);
	}
}
