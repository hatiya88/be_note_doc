package net.humanbridge.conmanagement.web.service.custom;

import java.io.IOException;

import net.humanbridge.conmanagement.external.call.ConciergeAgreementUploadApiCall;
import net.humanbridge.conmanagement.external.exception.ConciergeApiCallException;
import net.humanbridge.conmanagement.web.dto.UserSessionDto;
import net.humanbridge.conmanagement.web.exception.UploadException;
import net.humanbridge.conmanagement.web.model.custom.AgreementModel;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 同意書アップロードサービス（コンシェルジュ専用）
 */
@Service
public class AgreementUploadService {

	@Autowired
	private ConciergeAgreementUploadApiCall conciergeAgreementUploadApiCall;

	/**
	 * 同意書アップロードAPIを呼び出します。
	 *
	 * @param contractGroupId
	 * @param serviceId
	 * @param userSessionDto
	 * @param agreementModel
	 * @throws IOException
	 * @throws UploadException
	 */
	public String apiCall(String contractGroupId,
			String serviceId,
			UserSessionDto userSessionDto,
			AgreementModel agreementModel) throws UploadException, IOException {

		String uploadResponseDto = null;

		try {
			uploadResponseDto = conciergeAgreementUploadApiCall.call(
				userSessionDto.getServiceCached(contractGroupId, serviceId),
				agreementModel.getUpLoadFile().getBytes(),
				agreementModel.getUpLoadFile().getOriginalFilename());
		} catch (ConciergeApiCallException e) {
			throw new UploadException("CMG003-6_E0003", new String[] {userSessionDto.getLoginUserId() }, "アップロードに失敗しました。user_id:%s");
		}
		return uploadResponseDto;
	}

}
