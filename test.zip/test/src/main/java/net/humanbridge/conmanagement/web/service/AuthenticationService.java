package net.humanbridge.conmanagement.web.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.fujitsu.portal.api.call.AuthUserListApiCall;
import com.fujitsu.portal.api.call.LogoutApiCall;
import com.fujitsu.portal.api.dxo.request.AuthUserListApiRequestDxo;
import com.fujitsu.portal.api.dxo.request.LogoutApiRequestDxo;
import com.fujitsu.portal.api.dxo.response.AuthUserListApiResponseDxo;
import com.fujitsu.portal.api.exception.HttpRequestException;
import com.fujitsu.portal.api.mapper.User;
import com.fujitsu.portal.api.mapper.UserInfoMapper;

import jp.co.fjqs.f2.springboot.logger.basic.F2Logger;
import lombok.val;
import net.humanbridge.conmanagement.constant.AppConstants;
import net.humanbridge.conmanagement.portal.call.ChildServiceGroupIdListApiCall;
import net.humanbridge.conmanagement.portal.call.ClassAuthorityApiCall;
import net.humanbridge.conmanagement.portal.call.PhrPatientListApiCall;
import net.humanbridge.conmanagement.portal.dxo.request.ChildServiceGroupIdListApiRequestDxo;
import net.humanbridge.conmanagement.portal.dxo.request.ClassAuthorityApiRequestDxo;
import net.humanbridge.conmanagement.portal.dxo.request.PhrPatientListApiRequestDxo;
import net.humanbridge.conmanagement.portal.dxo.request.PhrPatientListApiRequestDxo.AddFieldKeys;
import net.humanbridge.conmanagement.portal.dxo.response.ChildServiceGroupIdListApiResponseDxo;
import net.humanbridge.conmanagement.portal.dxo.response.ClassAuthorityApiResponseDxo;
import net.humanbridge.conmanagement.portal.dxo.response.PhrPatientListApiResponseDxo;
import net.humanbridge.conmanagement.portal.mapper.ChildServiceGroupId;
import net.humanbridge.conmanagement.portal.mapper.GroupAuthority;
import net.humanbridge.conmanagement.portal.mapper.PhrPatient;
import net.humanbridge.conmanagement.portal.mapper.PhrPatientExtensions;
import net.humanbridge.conmanagement.portal.mapper.PhrPatientMapper;
import net.humanbridge.conmanagement.util.AppUtils;
import net.humanbridge.conmanagement.web.dto.UserSessionDto;
import net.humanbridge.conmanagement.web.dto.UserSessionDto.DummyUser;
import net.humanbridge.conmanagement.web.exception.AuthenticationException;
import net.humanbridge.conmanagement.web.exception.ServiceException;

/**
 * 利用者認証サービス（ログイン・ログアウト）
 */
@Service
public class AuthenticationService {

	private static final F2Logger logger = F2Logger.getLogger();

	@Autowired
	private AuthUserListApiCall authUserListApiCall;

	@Autowired
	private ClassAuthorityApiCall classAuthorityApiCall;

	@Autowired
	private PhrPatientListApiCall phrPatientListApiCall;

	@Autowired
	private LogoutApiCall logoutApiCall;

	@Autowired
	private ChildServiceGroupIdListApiCall childServiceGroupIdListApiCall;

	/** コンシェルジュの共通グループID */
	@Value("${common-group-id}")
	private String commonGroupId;
	/** マスメンAPIユーザ(マスタメンテ組込みjarの共通権限チェック対応) */
	@Value("${maintenance-api.login.id}")
	private String maintenanceApiLoginId;
	@Value("${maintenance-api.login.password}")
	private String maintenanceApiLoginPassword;

	/**
	 * ポータルにログインします。
	 *
	 * @param email    メールアドレス（ログインID）
	 * @param password パスワード
	 * @return ログインユーザー情報（セッション未設定）
	 * @throws AuthenticationException 利用者認証エラー、または、利用者権限エラー
	 */
	public ImmutablePair<UserSessionDto, String> login(String email, String password) throws AuthenticationException {
		String contractGroupId = null;

		// ポータルで利用者認証
		ImmutablePair<String, UserInfoMapper> authUser = getAuthUser(email, password);
		String apiKey = authUser.getLeft(); // APIキー
		UserInfoMapper userInfo = authUser.getRight(); // ポータルユーザー情報
		User user = userInfo.getUser(); // ログインユーザー情報
		String userId = user.getUserId(); // ユーザーID
		String accessToken = userInfo.getAccessToken(); // アクセストークン
		F2Logger.getLogger(this.getClass())
				.debug(String.format("user_id:%s access_token:%s api_key:%s", userId, accessToken, apiKey));

		// ポータルからユーザー権限情報を取得
		List<GroupAuthority> groupAuthorityList = getGroupAuthority(userId, accessToken);

		// セッションオブジェクト生成
		UserSessionDto userSessionDto = new UserSessionDto();
		userSessionDto.setApiKey(apiKey);
		userSessionDto.setAccessToken(accessToken);
		userSessionDto.setLoginUser(user);

		// 共通以外の所属病院は単一の前提
		int g = 0;
		// WebAPI25でスタッフ権限以外のアカウントで空返却された場合、PHR情報一覧（患者）を取得
		if (CollectionUtils.isEmpty(groupAuthorityList)) {
			PhrPatientMapper phrPatientMapper = getPhrPatients(userId, accessToken);

			for (PhrPatientExtensions patientExtensions : phrPatientMapper.getPatientExtensions()) {
				if (StringUtils.equals(patientExtensions.getUserId(), userId)
						&& !StringUtils.equals(patientExtensions.getPortalGroupId(), commonGroupId)) {
					// 複数病院所属エラー
					if (g > 0)
						throw new AuthenticationException("CMG001_W0002", new String[] { userId },
								"（患者権限）複数の医療機関に所属している場合ログインできません。user_id:%s");
					contractGroupId = patientExtensions.getPortalGroupId();
					userSessionDto.putGroupCached(patientExtensions.getPortalGroupId(),
							patientExtensions.getProviderGroupName());
					g++;
				}
			}

			// チームIDをMap
			// key: 契約グループID
			// key: チームID
			Map<String, String> teamIdMap = new HashMap<String, String>();
			for (PhrPatient phrPatient: phrPatientMapper.getPatients()) {
				teamIdMap.put(phrPatient.getGroupId(), phrPatient.getTeamId());
			}
			// 連携グループIDをMap
			// key: 契約グループID
			// key: 契約グループID
			Map<String, String> providerGroupIdMap = new HashMap<String, String>();
			for (PhrPatientExtensions phrPatientExtensions: phrPatientMapper.getPatientExtensions()) {
				providerGroupIdMap.put(phrPatientExtensions.getPortalGroupId(), phrPatientExtensions.getProviderGroupId());
			}
			userSessionDto.setTeamIdMap(teamIdMap);						// チームID
			userSessionDto.setProviderGroupIdMap(providerGroupIdMap); 	// 連携グループID

			F2Logger.getLogger(this.getClass()).debug(String.format("WebApi53 スタッフ権限以外で取得 user_id:%s", userId));
			
		} else {
			// WebAPI25でスタッフ権限アカウントの情報を取得できた場合
			for (GroupAuthority groupAuthority : groupAuthorityList) {
				if (!StringUtils.equals(groupAuthority.getGroupId(), commonGroupId)) {
					// 複数病院所属エラー
					if (g > 0)
						throw new AuthenticationException("CMG001_W0002", new String[] { userId },
								"（スタッフ権限）複数の医療機関に所属している場合ログインできません。user_id:%s");
					contractGroupId = groupAuthority.getGroupId();
					userSessionDto.putGroupCached(groupAuthority.getGroupId(), groupAuthority.getGroupName());
					g++;
				}
			}
		}
		return ImmutablePair.of(userSessionDto, contractGroupId);
	}

	/**
	 * ポータルからログアウトします。
	 *
	 * @param accessToken アクセストークン
	 * @return true：ログアウト成功，false：ログアウト失敗
	 */
	public boolean logout(String accessToken) {
		if (StringUtils.isEmpty(accessToken)) {
			// ログアウト済み（ログアウトの必要なし）
			return true;
		}
		try {
			LogoutApiRequestDxo requestDxo = new LogoutApiRequestDxo();
			requestDxo.setAccessToken(accessToken);
			logoutApiCall.call(requestDxo);
		} catch (Exception ignore) {
			// 通常のオペレーションでは発生しない
			logger.log("WCMG9001", "ログアウトに失敗しました。", ignore);
			return false;
		}
		return true;
	}

	/**
	 * ポータルで利用者認証を行います。
	 * 
	 * @param email    メールアドレス
	 * @param password パスワード
	 * @return left：APIキー，right：ユーザー情報
	 * @throws AuthenticationException 利用者認証エラー
	 */
	ImmutablePair<String, UserInfoMapper> getAuthUser(String email, String password) throws AuthenticationException {

		/** パラメータ生成 **/
		AuthUserListApiRequestDxo requestDxo = new AuthUserListApiRequestDxo();
		requestDxo.setEmail(email);
		requestDxo.setPassword(password);

		/** ユーザー認証・ユーザー情報取得 **/
		AuthUserListApiResponseDxo responseDxo = authUserListApiCall.callCreateApiKey(requestDxo);

		/**
		 * レスポンスチェック ・400, 401, 403, 404 （またはあるべき情報がNULLの場合も不正応答とみなす） ※
		 * ログイン情報に誤りがあれば通常は404 => IDまたはメールアドレスかパスワードに誤りがあります。 ・上記および200以外のHPPステータス =>
		 * エラーが発生しました。
		 */
		int status = responseDxo.getPortalhttpResponse().responseCode;
		val replacedEmail = AppUtils.emailMasking(email);
		if (status == HttpStatus.BAD_REQUEST.value() || status == HttpStatus.UNAUTHORIZED.value()
				|| status == HttpStatus.FORBIDDEN.value() || status == HttpStatus.NOT_FOUND.value()
				|| responseDxo.getApiKey() == null || responseDxo.getUserInfo() == null) {
			logger.log("ICMG0004", replacedEmail, status);
			throw new AuthenticationException("CMG001_E1001", new String[] { replacedEmail }, "指定された利用者情報が無効です。email:%s");
		} else if (status != HttpStatus.OK.value()) {
			logger.log("WCMG0006", replacedEmail);
			throw new AuthenticationException("CMG999_E0001", new String[] { replacedEmail }, "予期せぬエラーが発生しました。email:%s");
		}

		return ImmutablePair.of(responseDxo.getApiKey(), responseDxo.getUserInfo());
	}

	/**
	 * ポータルから病院ごとのユーザー権限を取得します。
	 * 
	 * @param userId      ユーザーID
	 * @param accessToken アクセストークン
	 * @return ユーザー権限一覧（病院一覧）
	 * @throws AuthenticationException 利用者権限エラー（一般ユーザーの場合なども含む）
	 */
	List<GroupAuthority> getGroupAuthority(String userId, String accessToken) throws AuthenticationException {

		/** パラメータ生成 **/
		ClassAuthorityApiRequestDxo requestDxo = new ClassAuthorityApiRequestDxo();
		requestDxo.setUserId(userId); // ユーザーID
		requestDxo.setAccessToken(accessToken); // アクセストークン

		/** ユーザー権限判別 **/
		ClassAuthorityApiResponseDxo responseDxo = classAuthorityApiCall.call(requestDxo);

		/** レスポンスチェック **/ // 空返却チェックを削除
		int status = responseDxo.getPortalhttpResponse().responseCode;
		if (status != HttpStatus.OK.value() && status != HttpStatus.NOT_FOUND.value()) {
			logger.log("ICMG0005", userId, status);
			throw new AuthenticationException("CMG001_W0001", new String[] { userId },
					"指定された利用者のスタッフ権限が無効です。user_id:%s");
		}

		return responseDxo.getGroupAuthorityMapper().getGroupAuthority();
	}

	/**
	 * ポータルから指定したサービスとユーザー（患者）に関連するPHRサービス利用者情報の一覧を取得します。
	 * 
	 * @param userId      ユーザーID
	 * @param accessToken アクセストークン
	 * @return PHRサービス利用者情報一覧（病院一覧）
	 * @throws AuthenticationException 利用者権限エラー（一般ユーザーの場合なども含む）
	 */
	PhrPatientMapper getPhrPatients(String userId, String accessToken) throws AuthenticationException {

		/** パラメータ生成 **/
		PhrPatientListApiRequestDxo requestDxo = new PhrPatientListApiRequestDxo();
		requestDxo.setUserId(userId); // ユーザーID
		requestDxo.setAddFields(AddFieldKeys.PATIENT_ID, AddFieldKeys.FAMILY); // サービス利用者（患者）のシステム連携情報(グループIDとグループ名), 本人および、ユーザーに紐づく全ての管理ユーザーの情報
		requestDxo.setAccessToken(accessToken); // アクセストークン

		/** 患者情報・病院グループ情報取得 **/
		PhrPatientListApiResponseDxo responseDxo = phrPatientListApiCall.call(requestDxo);

		/** レスポンスチェック **/
		int status = responseDxo.getPortalhttpResponse().responseCode;
		if (status != HttpStatus.OK.value() || responseDxo.getPhrPatient() == null
				|| CollectionUtils.isEmpty(responseDxo.getPhrPatient().getPatients())) {
			logger.log("ICMG0005", userId, status);
			throw new AuthenticationException("CMG001_W0001", new String[] { userId }, "指定された利用者の権限が無効です。user_id:%s");
		}

		return responseDxo.getPhrPatient();
	}

	/**
	 * ユーザー権限チェック（共通グループに下記の利用者が登録されているか判定します）<br>
	 * ・権限あり＝1:契約者 or 2:代理人 or 3:スタッフ<br>
	 * ・権限なし＝上記以外<br>
	 *
	 * @param groupAuthorityList ユーザー権限一覧
	 * @return true：権限あり，false：権限なし
	 */
	boolean checkClassAuthority(List<GroupAuthority> groupAuthorityList) {
		return checkClassAuthority(groupAuthorityList, false);
	}

	/**
	 * ユーザー権限チェック（共通グループ以外か共通グループを指定し、そのいずれかに下記の利用者が登録されているか判定します）<br>
	 * ・権限あり＝1:契約者 or 2:代理人 or 3:スタッフ<br>
	 * ・権限なし＝上記以外<br>
	 *
	 * @param groupAuthorityList ユーザー権限一覧
	 * @param isCommonGroupUser  共通グループユーザフラグ
	 * @return true：権限あり，false：権限なし
	 */
	boolean checkClassAuthority(List<GroupAuthority> groupAuthorityList, boolean isCommonGroupUser) {

		if (groupAuthorityList != null) {
			for (GroupAuthority groupAuthority : groupAuthorityList) {
				F2Logger.getLogger(this.getClass()).debug("権限情報詳細：" + AppUtils.dumpObject(groupAuthority));

				/** 権限チェック（） **/
				if ((!isCommonGroupUser && !StringUtils.equals(groupAuthority.getGroupId(), commonGroupId))
						|| (isCommonGroupUser && StringUtils.equals(groupAuthority.getGroupId(), commonGroupId))) {

					/** ユーザー権限チェック **/
					return StringUtils.equals(groupAuthority.getClassAuthorityCd(),
							AppConstants.CLASS_AUTHORITY_CONTRACTOR) // 契約者
							|| StringUtils.equals(groupAuthority.getClassAuthorityCd(),
									AppConstants.CLASS_AUTHORITY_ATTORNEY) // 代理人
							|| StringUtils.equals(groupAuthority.getClassAuthorityCd(),
									AppConstants.CLASS_AUTHORITY_STAFF); // スタッフ

				}
			}
		}

		return false;
	}

	/**
	 * マスメンAPIユーザのログイン認証
	 * 
	 * @return
	 * @throws AuthenticationException
	 */
	public DummyUser dummyUserLogin() throws AuthenticationException {
		// ポータルで利用者認証
		DummyUser dummyUser = getAuthDummyUser();

		// ポータルからユーザー権限情報を取得
		List<GroupAuthority> groupAuthorityList = getGroupAuthority(dummyUser.getUser().getUserId(),
				dummyUser.getAccessToken());

		// ユーザー権限チェック
		if (!checkClassAuthority(groupAuthorityList, true)) {
			// 権限なしエラー
			throw new AuthenticationException("CMG999_E0001", new String[] { dummyUser.getUser().getUserId() },
					"マスメンAPIユーザーにマスメンツールの利用者権限がありません。user_id:%s");
		}
		return dummyUser;
	}

	/**
	 * マスメンAPIユーザのログイン認証
	 * 
	 * @return
	 * @throws AuthenticationException
	 */
	public DummyUser getAuthDummyUser() throws AuthenticationException {
		// ポータルで利用者認証
		ImmutablePair<String, UserInfoMapper> authPair = getAuthUser(maintenanceApiLoginId, maintenanceApiLoginPassword);
		DummyUser dummyUser = new DummyUser();
		dummyUser.setUser(authPair.getRight().getUser());
		dummyUser.setApiKey(authPair.getLeft());
		dummyUser.setAccessToken(authPair.getRight().getAccessToken());
		return dummyUser;
	}
	
	/**
	 * 子サービスグループID取得（WebApi34）
	 * 
	 * @param contractGroupId
	 * @return
	 * @throws ServiceException
	 */
	public Map<String, String> getChildServiceGroupIdList(String contractGroupId) throws ServiceException {

		// コンシェルジュの子サービスID・グループIDマップ（key:サービスID，value:グループID）
		Map<String, String> serviceIdGroupIdMap = new HashMap<>();

		/** サービス一覧取得パラメータ **/
		ChildServiceGroupIdListApiRequestDxo requestDxo = new ChildServiceGroupIdListApiRequestDxo();
		requestDxo.setContractGroupId(contractGroupId);		// 契約グループID

		/** コンシェルジュ配下サービス・グループ一覧取得API呼び出し **/
		ChildServiceGroupIdListApiResponseDxo responseDxo = childServiceGroupIdListApiCall.call(requestDxo);

		/** レスポンスチェック **/
		int status = responseDxo.getPortalhttpResponse().responseCode;
		if (status != HttpStatus.OK.value()
		 || responseDxo.getChildServiceGroupIdMapper() == null
		 || responseDxo.getChildServiceGroupIdMapper().getChildServiceGroupIds() == null) {
			logger.log("ICMG0019", contractGroupId, status);
			throw new HttpRequestException("WebApi34でグループ一覧が取得できませんでした。HttpStatus:" + status, new String[] {"サービス・グループ一覧情報"});
		}
		// サービスID・グループID一覧
		List<ChildServiceGroupId> ChildServiceGroupIdList = responseDxo.getChildServiceGroupIdMapper().getChildServiceGroupIds();

		/** サービスID、マスタメンテナンス対象サービスの病院グループIDのマップを作成 **/
		// 対象サービスの病院グループIDをサービスIDに紐づける
		for (ChildServiceGroupId ChildServiceGroupId : ChildServiceGroupIdList) {
			serviceIdGroupIdMap.put(ChildServiceGroupId.getServiceId(), ChildServiceGroupId.getGroupId());
		}
		return serviceIdGroupIdMap;
	}
	
	/**
	 * API52①から、TeamId取得
	 * @param loginId
	 * @param password
	 * @return
	 * @throws AuthenticationException
	 */
	public ImmutablePair<Map<String, String>, Map<String, String>> getTeamIdGroupIdMap(String loginId, String password) throws AuthenticationException {
		// ポータルで利用者認証
		ImmutablePair<String, UserInfoMapper> authPair = getAuthUser(loginId, password);
		// API53①接続
		PhrPatientMapper phrPatientMapper = getPhrPatients(authPair.getRight().getUser().getUserId(), authPair.getRight().getAccessToken());

		/** レスポンスチェック **/
		if (phrPatientMapper.getPatients()== null
		 || phrPatientMapper.getPatientExtensions() == null) {
			logger.log("ECMG0001", loginId);
			throw new AuthenticationException("ECMG0001", new String[] { loginId },
					"WebApi53で患者情報が取得できませんでした。loginId:%s");
		}

		// チームIDをMap
		// key: 契約グループID
		// key: チームID
		Map<String, String> teamIdMap = new HashMap<String, String>();
		for (PhrPatient phrPatient: phrPatientMapper.getPatients()) {
			teamIdMap.put(phrPatient.getGroupId(), phrPatient.getTeamId());
		}

		// 連携グループIDをMap
		// key: 契約グループID
		// key: 契約グループID
		Map<String, String> providerGroupIdMap = new HashMap<String, String>();
		for (PhrPatientExtensions phrPatientExtensions: phrPatientMapper.getPatientExtensions()) {
			providerGroupIdMap.put(phrPatientExtensions.getPortalGroupId(), phrPatientExtensions.getProviderGroupId());
		}

		return ImmutablePair.of(teamIdMap, providerGroupIdMap);
	}
}
