package net.humanbridge.conmanagement.external.exception;

import lombok.Getter;
import lombok.Setter;

/**
 * TOTP APIコールエラー時の例外クラス
 */
@Getter
@Setter
public class TOTPApiCallException extends RuntimeException {

	/** Serial version UID. (Default) */
	private static final long serialVersionUID = 1L;

	/** エラーメッセージ */
	private String message;

	public TOTPApiCallException(String message) {
		this.message = message;
	}
}
