package net.humanbridge.conmanagement.web.service.analytics.graph;

import java.util.Date;
import java.util.List;
import java.util.Map;

import net.humanbridge.conmanagement.web.dto.UserSessionDto;

/**
 * グラフ作成クラス生成interface
 * @author xonogawa.koichi
 *
 */
public interface IMakeGraphData {

	public abstract List<Map<String, Long>> getGraphData(String searchTargetGroupId, Date fromDate, Date toDate, String unit, String deptCode, int fetchAmount);
	public String getSearchTargetGroupId(String serviceKind, UserSessionDto userSessionDto);
}
