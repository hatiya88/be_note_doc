(function(global, namespace, factory) {
/////* DON'T CHANGE CODE BELOW THIS LINE */////////////////////////////////////////////////
    if (namespace) {
        if (!(namespace in global)) {
            global[namespace] = {};
        }
        factory.call(global[namespace], global);
    } else {
        factory.call(global, global);
    }
/////* DON'T CHANGE CODE ABOVE THIS LINE */////////////////////////////////////////////////
})(window, 'AppUtils', function(global) {

    /**
     * 共通 OnLoad 処理
     * @global
     */
    $(function() {

        // submit時に処理中表示を行う（２重押下抑止）
        showLoadingOnSubmit();

        // Enterキーでsubmitされるのを抑止する
        preventEnterSubmit();

        // Spaceキーでラベルを選択する
        selectableLabel();
        
        // ログアウト
        logout();

        // 戻る（orキャンセル）ボタン
        backBtn();
        
        // モーダル閉じるイベント設定
        AppUtils.bindHideModal();
        
        // 数値入力
        inputNumber();
        
        // 日付入力有効化
        AppUtils.setDatePicker();
    });
    
    this.AJAX_TIME_OUT = 30000;

    /**
     * 処理中のグルグルを表示します。
     * @public
     */
    var showLoading = this.showLoading = function() {
        $('#loading').show();
        $('#loading-message').focus().off('keydown keyup keypress').on('keydown keyup keypress', function(event) {
            // TABキーによるフォーカス移動を抑止する
            return [
                9,  // TAB
                16  // Shift + TAB
            ].indexOf(event.which) < 0;
        });
    };

    /**
     * 処理中のグルグルを非表示にします。
     * @public
     */
    var hideLoading = this.hideLoading = function() {
        return $('#loading').hide();
    };

    /**
     * submit時に処理中のグルグルを表示します。
     * @private
     */
    var showLoadingOnSubmit = function() {
        $('form').on('submit', function() {
            showLoading();
        });
    };

    /**
     * form中のテキストでEnterキーを押された際のsubmitを抑止します。
     * ※inputのクラスに allow-submit をつけると除外できます。
     * @private
     */
    var preventEnterSubmit = function() {
        $(document).on('keypress', 'input:not(.allow-submit)', function(event) {
            return event.which !== 13;  // ENTER
        });
    };

    /**
     * Spaceキーでのラベル選択を有効にします。
     * @private
     */
    var selectableLabel = function() {
        $(document).on('keypress', 'label[for]:focus', function(event) {
            if (event.which === 32) {   // SPACE
                $(this).click();
                return false;
            }
        })
    };
    
    /**
     * ブラウザの「戻る」を無効にします。
     * @private
     */
    this.disableHistoryBack = function() {
        // ハッシュ名は何でもよい
        $(window).on('hashchange', function(ev) {
            if (location.hash === '') {
                location.hash = '#page';
            }
        });
        location.hash = '#page';
    };

    /**
     * 日付入力有効化します。
     */
    this.setDatePicker = function() {
    	$.datetimepicker.setLocale('ja');
    	$(".datepicker").datepicker("destroy");
    	$(".datetimepicker").datetimepicker("destroy");
    	$(".datepicker").datepicker({
    	  dateFormat: 'yy/mm/dd', 
    	});
    	$(".datetimepicker").datetimepicker({lang:'ja'});
    };
    
    /**
     * 半角入力制御（全角入力除去）します。
     */
    this.onlySingleByte = function() {
    	$('.only-single-byte').on('keyup', function() {
    		AppUtils.removeNotRegex(this, /[^\x00-\x7E]+/g);
    	});
    };

    /**
     * targetの値で否定正規表現（～以外）に一致する文字を除去します。
     */
    this.removeNotRegex = function(target, notRegex) {
    	var obj = $(target);
    	if(!obj.val().match(notRegex)) return;
    	window.setTimeout(function() {
    		obj.val(obj.val().replace(notRegex, ''));
    	}, 1); 
    };
    	
    /**
     * 独自ファイル選択入力イベントハンドラーの初期化をします。
     * ※input[type="file"]タグの直後にinput[type="text"]タグが必要です。
     *     <input type="file" id="file" accept="image/png,image/jpeg" />
     *     <input type="text" readonly="readonly" />
     *     <label for="file">参照</label>
     * @public
     */
    this.setupCustomInputFile = function() {
        /* ファイル選択内容（ファイルパス）をコピー */
        $(':file').on('change', function(event) {
            var file = $(this), path = file.next(':text');
            // Chrome, Firefox, Edge ではセキュリティ設定上 "C:\fakepath\～" となる
            // ファイル名のみ設定する場合は、this.files[0].name を使用する
            path.val(file.val());
            path.focus();
        });

        /* ファイルパスクリックでファイル選択 */
        $(':file+:text').on('click', function(event) {
            var path = $(this), file = path.prev(':file');
            file.click();
        }).on('keydown keyup', function(event) {
            /* BackSpace, Delete でファイル選択クリア (IEのみ) */
            if ([
                 8, // BackSpaceキー
                 46 // Deleteキー
            ].indexOf(event.which) >= 0) {
                var path = $(this), file = path.prev(':file');
                file.val('');
                return false;
            }
        });
    };
    
    /**
     * 戻るボタン
     */
    var backBtn = function() {
    	$('#back-to-btn').on('click', function(e) {
    		e.target.blur();
    		var backBtn = $(this);
    		var yesCallBack = function() { window.location.href = backBtn.data('back-to'); };
    		// 入力内容変更フラグがON or 削除選択チェックボックスがON
        	if ($('#form-changed-flg').val() === "1" || $('.delete-check:checked').length > 0) {
        		AppUtils.confirmMessageDialog('更新せず前画面に戻ります。よろしいですか？', yesCallBack);
        	} else {
        		yesCallBack();
        	}
    	});
    };
    
    /**
     * ログアウト
     */
    var logout = function() {
		var yesCallBack = function() { window.location.href = App.CONTEXT_ROOT + '/logout'; };
    	$('.button-logout').on('click', function() {
    		var msg = '';
    		if (!!$('#form-changed-flg') && ($('#form-changed-flg').val() === "1" || $('.delete-check:checked').length > 0)) {
        		msg += '更新せず';
    		}
    		msg += 'ログアウトします。';
    		msg += 'よろしいですか？';
			AppUtils.confirmMessageDialog(msg, yesCallBack);
    	});
    }
    
    /**
     * 数値入力
     */
    var inputNumber = function() {
		$('.input-number').on('keypress', function(e) {
			var ele = $('.input-number');
			// 数字以外の不要な文字を削除
			var st = String.fromCharCode(e.which);
			if ("0123456789-\.".indexOf(st, 0) < 0) { 
			  return false; 
			}
			return true;
		});
		$('.input-number').on('keyup', function(e) {
			if(e.keyCode === 9 || e.keyCode === 16) return;
			this.value = this.value.replace(/[^\-0-9\.]+/i,'');
		});
    }

    /**
     * モーダル関連
     */
    /**
     * モーダルウィンドウ閉じるイベント
     */
    this.bindHideModal = function() {
    	$('.modal-footer input[type=button].button-primary,.modal-footer input[type=button].button-secondary').on('click', function(e) {
    		$('#message-modal').fadeOut();
    		$('#confirm-modal').fadeOut();
    		$('#modal-bg').fadeOut();
    		// 追加スタイル削除
    		var rmClass = function() { $('#confirm-modal').removeClass('short-message-modal'); };
    		setTimeout(rmClass, 400);
    	});
    };
    /**
     * メッセージダイアログ
     */
    this.messageDialog = function(html) {
    	$('#message-modal .modal-content').html(html);
		$('#modal-bg').fadeIn();
		$('#message-modal').fadeIn();
    };
    /**
     * 確認メッセージダイアログ
     */
    this.confirmMessageDialog = function(msg, yesCallBack, noCallBack) {
    	// 1行のメッセージは調整レイアウト
    	if (msg.length < 24) {
    		$('#confirm-modal').addClass('short-message-modal');
    	}
    	$('#confirm-modal .modal-content').html(msg);
    	$('#confirm-modal .button-primary').off().on('click', yesCallBack);
    	if (!!noCallBack && typeof noCallBack == 'func') {
        	$('#confirm-modal .button-secondary').off().on('click', noCallBack);
    	}
		$('#modal-bg').fadeIn();
		$('#confirm-modal').fadeIn();
    };
    /**
     * エラーメッセージ表示
     */
    this.errorMessage = function(msg) {
    	$("#message-area").children("ul:first").append("<li>" + msg + "</li>");
    };
    
    /**
     * フォーム関連
     */
    /**
     * フォーム送信
     * ※1) 送信ボタンとformを分けるレイアウトにしてしまった事によるsubmitバインドの手間を共通化しました。
     *       -> 画面タイトル領域(div class="header-sub")とformを分けたのはy方向にoverflowした場合に画面タイトル領域を固定表示するためです。
     * ※2) バリデーション有無制御しか対応していません。カスタマイズ必要であれば個別定義してください。
     */
    this.uploadButton = function(doJsValid, confirmMsg) {
    	if (!confirmMsg) {
    		confirmMsg = '画面の内容で設定を更新します。削除選択された行は削除されます。よろしいですか？';
    	}
    	$('#form-main-upload').on('click', function(e) {
    		e.target.blur();
    		AppUtils.clearMessageArea('#message-area .error');
    		if (!doJsValid || $('#form-main').validationEngine('validate')) {
    			AppUtils.confirmMessageDialog(confirmMsg, function() { $('#form-main').submit(); });
    		}
    	});
    };
    /**
     * メッセージエリア クリア
     */
    this.clearMessageArea = function(msgAreaId) {
    	if (!msgAreaId) {
    		msgAreaId = "#message-area ul";
    	}
    	$(msgAreaId).children().remove();
    };
    /**
     * メッセージ行数に合わせたform-contents部スタイル初期化
     */
    this.formContentStyleInit = function() {
    	var basePaddingTop = 52;
    	$(".form-contents").css("height", "100%");
    	$(".form-contents").css("padding-top", String(basePaddingTop) + "px");
    };
    /**
     * メッセージ行数に合わせたform-contents部スタイル調整
     */
    this.formContentStyleOffset = function(msgAreaId) {
    	if (!msgAreaId) {
    		msgAreaId = "#message-area ul";
    	}
    	var basePaddingTop = 52;
    	var minPaddingTop = 16;
    	var liHeight = 36;
    	var offsetH = $(msgAreaId).children().length * liHeight;
    	if (offsetH > (basePaddingTop - minPaddingTop)) {
        	$(".form-contents").css("padding-top", String(minPaddingTop) + "px");
    	} else {
        	$(".form-contents").css("padding-top", String(basePaddingTop - offsetH) + "px");
    	}
    	$('.form-contents').css('height', 'calc(100% - ' + String(offsetH) + 'px)');
    };
    /**
     * jqueryValidationEngineによるvalidate前処理
     *   1) 初期化処理に追加する関数の代入
     *   2) 入力エラー発見時に追加する関数の代入
     */
    this.beforeValidate = function(formId) {
    	$(formId).validationEngine({listValidInitFunc: AppUtils.formContentStyleInit});
    	$(formId).validationEngine('attach', {listValidErrorFunc: AppUtils.formContentStyleOffset});
    };

    /**
     * 削除選択チェックボックスONOFF
     */
    this.deleteCheck = function() {
    	$('input[type=checkbox].delete-check').off().on('change', function() {
    		var delChk = $(this);
    		var row = delChk.closest('tr.data-row');
    		if (delChk.prop('checked')) {
        		row.find('input:not(.delete-check),textarea,select').prop('disabled', true);
        		row.addClass('disabled');
    		} else {
        		row.find('input:not(.delete-check),textarea,select').prop('disabled', false);
        		row.removeClass('disabled');
    		}
    	});
    };
    /**
     * モーダルフォーム入力内容変更フラグON
     */
    this.formChangedOn = function(formId, changedId) {
    	if (!formId) formId = '#form-main';
    	if (!changedId) changedId = '#form-changed-flg';
    	$(formId).find('input:not(.delete-check),textarea,select').on('change', function() {
        	$(changedId).val("1");
        	// 更新済みメッセージが残る事による誤解の回避
        	AppUtils.clearGuidance();
        	AppUtils.formContentStyleOffset();
    	});
    };
    /**
     * モーダル内容確認ダイアログ表示
     */
    this.modalFormConfirmMessageDialog = function(html, yesCallBack, modalConfirmId, modalConfirmBgId) {
    	$(modalConfirmId + ' .modal-content').html(html);
    	$(modalConfirmId + ' .button-primary').off().on('click', yesCallBack);
    	$(modalConfirmId + ' .button-secondary').off().on('click', function() {
    		$(modalConfirmId).fadeOut();
    		$(modalConfirmBgId).fadeOut();
    	});
		$(modalConfirmBgId).fadeIn();
		$(modalConfirmId).fadeIn();
    };
    /**
     * ガイダンスメッセージクリア
     */
    this.clearGuidance = function() {
    	$('ul.guidance').empty();
    };
        
    /**
     * 汎用部品
     */
    /**
     * ランダム文字列(英数字)を生成します。
     */
    this.randomStr = function(len) {
    	var str = "";
    	// 初期値32バイト
    	if (!len) {
    		len = 32;
    	}
    	var c = "abcdefghijklmnopqrstuvwxyz0123456789";
    	var cl = c.length;
    	for(var i = 0; i < len;i++) {
    	  str += c[Math.floor(Math.random() * cl)];
    	}
    	return str;
    };
    /**
     * 最大値を取得します。
     */
    this.getMaxNum = function(inputAry) {
    	var max = 0;
    	$(inputAry).each(function() {
    		var input = $(this);
    		var val = Number(input.val());
    		if (max < val) {
    			max = val;
    		}
    	});
    	return max;
    };
    
    /**
     * 一覧形式画面 table bodyスクロールイベント
     */
    this.scrollTableBody = function() {
    	$('#list-table-body-area').scroll(function() {
        	$('#list-table-header-area').scrollLeft($('#list-table-body-area').scrollLeft());
    	});
    };
});
