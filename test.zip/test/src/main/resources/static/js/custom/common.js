(function(global, namespace, factory) {
/////* DON'T CHANGE CODE BELOW THIS LINE */////////////////////////////////////////////////
    if (namespace) {
        if (!(namespace in global)) {
            global[namespace] = {};
        }
        factory.call(global[namespace], global);
    } else {
        factory.call(global, global);
    }
/////* DON'T CHANGE CODE ABOVE THIS LINE */////////////////////////////////////////////////
})(window, 'CustomCommon', function(global) {

    /**
     * アップロードファイルのプレビュー表示
     * @public
     */
    this.setupUploadFilePreview = function() {
        // プレビューの表示
        $('form').on('change', 'input[type="file"]', function(e) {
            var file = e.target.files[0],
            reader = new FileReader(),
            $preview = $(".preview");

            //ファイル未選択時はプレビューを非表示
            if (file == null) {
                $preview.empty();
                return false;
            }

            // 画像ファイル以外の場合は何もしない
            if (file.type.indexOf("image") < 0) {
                return false;
            }

            // ファイル読み込みが完了した際のイベント登録
            reader.onload = function(e) {
                // 既存のプレビューを削除
                $preview.empty();
                // .prevewの領域の中にロードした画像を表示するimageタグを追加
                $preview.append($('<img>').attr({
                    src : e.target.result,
                    class : "preview",
                    title : file.name
                }));
            };

            reader.readAsDataURL(file);
        });
    };

});
