(function(global, namespace, factory) {
/////* DON'T CHANGE CODE BELOW THIS LINE */////////////////////////////////////////////////
    if (namespace) {
        if (!(namespace in global)) {
            global[namespace] = {};
        }
        factory.call(global[namespace], global);
    } else {
        factory.call(global, global);
    }
/////* DON'T CHANGE CODE ABOVE THIS LINE */////////////////////////////////////////////////
})(window, 'Agreement', function(global) {

    /**
     * 同意書アップロード OnLoad 処理
     * @global
     */
    $(function() {
        
        // 独自ファイル選択入力フォームの初期化
        AppUtils.setupCustomInputFile();
        
        // アップロードボタン
        AppUtils.uploadButton(true, '同意書ファイルをアップロードします。よろしいですか？');        

        // 入力内容変更フラグ
        AppUtils.formChangedOn();
        
        // 戻るボタン
        backBtn();
    });

    /**
     * 戻るボタン
     */
    var backBtn = function() {
    	$('#back-to-btn').off().on('click', function(e) {
    		e.target.blur();
    		var backBtn = $(this);
    		var yesCallBack = function() { window.location.href = backBtn.data('back-to'); };
    		// 入力内容変更フラグがON or 削除選択チェックボックスがON
        	if ($('#form-changed-flg').val() === "1" || $('.delete-check:checked').length > 0) {
        		AppUtils.confirmMessageDialog('アップロードせず前画面に戻ります。よろしいですか？', yesCallBack);
        	} else {
        		yesCallBack();
        	}
    	});
    };
        
});
