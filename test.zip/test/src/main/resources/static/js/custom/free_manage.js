(function(global, namespace, factory) {
/////* DON'T CHANGE CODE BELOW THIS LINE */////////////////////////////////////////////////
    if (namespace) {
        if (!(namespace in global)) {
            global[namespace] = {};
        }
        factory.call(global[namespace], global);
    } else {
        factory.call(global, global);
    }
/////* DON'T CHANGE CODE ABOVE THIS LINE */////////////////////////////////////////////////
})(window, 'FreeManage', function(global) {

    /**
     * 自由表示設定
     * @global
     */
    $(function() {
    	// ゼロ件時の1行初期表示
    	defaultRow();
    	// 行追加
    	addRow();
    	// 削除チェック
    	AppUtils.deleteCheck();
        // 一括更新
    	uploadButton();
        // 入力内容変更フラグ
        AppUtils.formChangedOn();
        // メッセージ行数に合わせたform-contents部スタイル補正
        AppUtils.formContentStyleOffset();
    });
   
    // 追加ボタンクリック
    var addRow = function() {
    	$('#button-free-manage-add').on('click', function() {
    		addRowExec();
    	});
    }

    /**
     * 行追加処理
     */
    var addRowExec = function() {
    	// 表示順 最大値&カウントアップ取得
	    var maxPrecedence = AppUtils.getMaxNum($('#free-manage-table [name=precedence]'));
	    maxPrecedence++;
	    //最大値を超えたときは、最大値を表示する
	    if (maxPrecedence > 9999){
	    	maxPrecedence = 9999;
	    }
	    // コピー元取得し、表示順の最大値を入れて行追加
	    var hiddenRow = $($('#add-row-area').find('tr.data-row'));
	    $(hiddenRow.find('input[name=precedence]')[0]).val(maxPrecedence);
	    // 行番号取得
	    var rowCount = $('#free-manage-table tbody').children('tr').length;
	    rowCount++;
	    $(hiddenRow.find('[data-row-num]')).each(function(idx, ele) {
	    	$(ele).attr('data-row-num', String(rowCount));
	    });
	    // checkboxのid属性とlabelのfor属性をランダム文字列で一意のペアにする
	    var id = AppUtils.randomStr();
	    var td = $(hiddenRow.find('.free-manage-delete-selection')[0]);
	    $(td.find('[type=checkbox].delete-check')[0]).prop('id', id);
	    $(td.find('label')[0]).prop('for', id);
	    $('#free-manage-table>tbody').append(hiddenRow.clone());
	    // 削除選択
	    AppUtils.deleteCheck();
	    // カレンダー
	    AppUtils.setDatePicker();
    };
    
    /**
     * ゼロ件時の1行初期表示
     */
    var defaultRow = function() {
        if ($('#free-manage-table tbody').children().length === 0) {
        	addRowExec();
        }
    };
    
    /**
     * 一括更新
     */
    var uploadButton = function() {
    	var confirmMsg = '画面の内容で設定を更新します。削除選択された行は削除されます。よろしいですか？';
    	$('#form-main-upload').on('click', function(e) {
    		AppUtils.clearGuidance();
    		e.target.blur();
    		AppUtils.beforeValidate('#form-main');
    		if ($('#form-main').validationEngine('validate')) {
    			AppUtils.confirmMessageDialog(confirmMsg, FreeManage.upload);
    		}
    	});
    }
    
    /**
     * アップロード処理
     */
    this.upload = function() {
    	var form = $('#form-main');
    	var freeDtoAry = [];
    	$('#free-manage-table tbody').children('tr').each(function(idx, ele) {
    		var tr = $(ele);
    		var deleteSelect = tr.find('input[name=deleteSelection]').prop('checked') ? '1' : '0';
    		var freeDto = {
        		deleteSelect: deleteSelect,
    			sectionItemSeq: tr.find('input[name=sectionItemSeq]').val(),
    			precedence: tr.find('input[name=precedence]').val(),
    			itemValue: tr.find('input[name=itemValue]').val(),
    		};
    		freeDtoAry.push(freeDto);
    	});
    	$('#freedto-ary-json').val(JSON.stringify(freeDtoAry));
    	form.submit();
    };
    
});
