(function(global, namespace, factory) {
/////* DON'T CHANGE CODE BELOW THIS LINE */////////////////////////////////////////////////
    if (namespace) {
        if (!(namespace in global)) {
            global[namespace] = {};
        }
        factory.call(global[namespace], global);
    } else {
        factory.call(global, global);
    }
/////* DON'T CHANGE CODE ABOVE THIS LINE */////////////////////////////////////////////////
})(window, 'IconManage', function(global) {

    /**
     * アイコン設定
     * @global
     */
    $(function() {
        // モーダル閉じるイベント設定
        iconManagebindHideModal();
        // 一括更新
        listUploadButton();
        // 入力内容変更フラグ
        AppUtils.formChangedOn();
        // 追加ボタン（モーダル表示）
    	contentModalAdd();
        // コンテンツ確定ボタン
        iconContentDecide();
        // メッセージ行数に合わせたform-contents部スタイル補正
        AppUtils.formContentStyleOffset();
    });

    /**
     * コンテンツ設定モーダル閉じる
     */
	var iconManagebindHideModal = function() {
		$('#button-icon-content-cancel').on('click', function(e) {
			$('#icon-modal-id').fadeOut();
			$('#confirm-modal').fadeOut();
			$('#modal-bg').fadeOut();
			// エラーメッセージクリア
			$("#message-area ul").children().remove();
		});
	}
    
    /**
     * モーダル初期化共通
     */
    this.contentModalInit = function() {
    	// モーダルメッセージクリア
    	AppUtils.clearMessageArea("#modal-message-area ul");
        // モーダル入力内容変更フラグ
        AppUtils.formChangedOn('#form-content', '#modal-form-changed-flg');
        $('#modal-form-changed-flg').val('0');
        // モーダルキャンセルボタン
        modalFormCancel();
    };

    /**
     * コンテンツ追加用モーダル表示
     */
    var contentModalAdd = function() {
    	$('#button-icon-add').off().on('click', function(e) {
        	// フォーカスアウト
        	e.target.blur();
        	// 一覧メッセージクリア
        	AppUtils.clearMessageArea();
            // メッセージ行数に合わせたform-contents部スタイル補正
            AppUtils.formContentStyleOffset();
        	
			$('input:text[name="name"]').val('');		// 表示名
	    	// 表示項目
			$('#icon_file').val('');					// アイコン選択肢クリア
			$('input:text[name="url"]').val('');		// URL
			$('input:text[name="startDate"]').val('');	// 開始日時
			$('input:text[name="endDate"]').val('');	// 終了日時
			// 非表示項目
			$('#currentRecordServiceSeq').val('');
			$('#currentRecordServiceId').val('');
			$('#currentRecordSectionItemSeq').val('');
			$('#currentRecordLayoutSectionSeq').val('');
			// コンテンツ設定モーダル初期化
			IconManage.contentModalInit();
	    	
			$('#modal-bg').fadeIn();
			$('#icon-modal-id').fadeIn();
    	});
    };
    
    /**
     * (モーダル)コンテンツ設定 確定ボタンsubmit
     */
    var iconContentDecide = function() {
    	$('#button-icon-content-decide').on('click', function() {
    		// モーダル内部にバリデーションメッセージ表示
    		$("#form-content").validationEngine({listErrorMsgArea: '#modal-common-error-msg'});
    		if($("#form-content").validationEngine('validate')) {
    			AppUtils.modalFormConfirmMessageDialog('画面の内容で設定を更新します。よろしいですか？',function() { $('#form-content').submit(); }, '#content-modal-confirm', '#content-modal-confirm-bg');
    		};
    	});
    };
    
    /**
     * 一括更新ボタン
     */
    var listUploadButton = function() {
    	$('#form-main-upload').on('click', function(e) {
    		AppUtils.clearGuidance();
    		e.target.blur();
    		AppUtils.beforeValidate('#form-main');
    		// 一覧画面側にバリデーションメッセージ表示
    		$("#form-main").validationEngine({listErrorMsgArea: '#common-error-message'});
    		if ($('#form-main').validationEngine('validate')) {
    			AppUtils.confirmMessageDialog('画面の内容で設定を更新します。表示順が空欄の行は削除されます。よろしいですか？', IconManage.listUpload);
    		}
    	});
    };
    
    /**
     * アップロード処理
     */
    this.listUpload = function() {
    	var form = $('#form-main');
    	var iconDtoAry = [];
    	$('#icon-manage-table tbody').children('tr').each(function(idx, ele) {
    		var tr = $(ele);
    		var iconDto = {
        		sectionItemSeq: tr.find('input[name=sectionItemSeq]').val(),
        		precedence: tr.find('input[name=precedence]').val(),
    		};
    		iconDtoAry.push(iconDto);
    	});
    	$('#icondto-ary-json').val(JSON.stringify(iconDtoAry));
    	form.submit();
    }
    
    /**
     * 設定ボタンonclick
     */
    this.editContent = function(event, sectionItemSeq) {
    	// フォーカスアウト
    	event.target.blur();
    	// 一覧メッセージクリア
    	AppUtils.clearMessageArea();
        // メッセージ行数に合わせたform-contents部スタイル補正
        AppUtils.formContentStyleOffset();
    	// jqueryValidationEngine初期化
    	$("#form-main").validationEngine('init');
    	
        // ローディングサークルON
        AppUtils.showLoading();
        
    	var contentsUrl = $('input:hidden[name="contents_url"]').val();
    	$.ajax({
    		url: contentsUrl + '?sectionItemSeq=' + sectionItemSeq,
    		type: 'GET',
    		timeout: AppUtils.AJAX_TIME_OUT,
    	})
    	.done(function(iconContent) {
          // ローディングサークルOFF
          AppUtils.hideLoading();
          
    	  $('input:text[name="name"]').val(iconContent.name);
    	  $('#icon_file').val(iconContent.iconFile);
    	  $('input:text[name="url"]').val(iconContent.url);
    	  $('input:text[name="startDate"]').val(iconContent.startDate);
    	  $('input:text[name="endDate"]').val(iconContent.endDate);

    	  $('#currentRecordServiceSeq').val(iconContent.serviceSeq);
    	  $('#currentRecordServiceId').val(iconContent.serviceId);
    	  $('#currentRecordSectionItemSeq').val(iconContent.sectionItemSeq);
    	  $('#currentRecordLayoutSectionSeq').val(iconContent.layoutSectionSeq);
    	  
			// コンテンツ設定モーダル初期化
    	  IconManage.contentModalInit();
	    	
          // モーダル表示
    	  $('#modal-bg').fadeIn();
    	  $('#icon-modal-id').fadeIn();
    	})
    	.fail(function() {
          // ローディングサークルOFF
          AppUtils.hideLoading();
    	  AppUtils.errorMessage('コンテンツ設定画面の表示ができませんでした。');
      	  AppUtils.formContentStyleOffset();
    	});
    };
    
    /**
     * モーダルフォーム画面キャンセルボタン
     */
    var modalFormCancel = function() {
    	$('#icon-modal-id .icon-modal-footer #button-icon-content-cancel').off().on('click', function(e) {
    		e.target.blur();
    		var cancelBtn = $(this);
    		var yesCallBack = function() { 
               $('#content-modal-confirm').fadeOut();
               $('#content-modal-confirm-bg').fadeOut();
               $('#icon-modal-id').fadeOut();
               $('#modal-bg').fadeOut();
    		};
    		// 入力内容変更フラグがON or 削除選択チェックボックスがON
        	if ($('#modal-form-changed-flg').val() === "1") {
    			AppUtils.modalFormConfirmMessageDialog('更新せず画面を閉じます。よろしいですか？', yesCallBack, '#content-modal-confirm', '#content-modal-confirm-bg');
        	} else {
        		yesCallBack();
        	}
    	});
    };
    
});
