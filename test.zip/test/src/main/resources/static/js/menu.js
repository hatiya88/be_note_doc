(function(global, namespace, factory) {
/////* DON'T CHANGE CODE BELOW THIS LINE */////////////////////////////////////////////////
    if (namespace) {
        if (!(namespace in global)) {
            global[namespace] = {};
        }
        factory.call(global[namespace], global);
    } else {
        factory.call(global, global);
    }
/////* DON'T CHANGE CODE ABOVE THIS LINE */////////////////////////////////////////////////
})(window, 'Menu', function(global) {

    /**
     * メインメニュー OnLoad 処理
     * @global
     */
    $(function() {
    	
        // ブラウザバックの無効化
        AppUtils.disableHistoryBack();

        // サービス名ボタンクリック時にサービス名、マスタメンテナンス対象サービスの病院グループID、サービスURLをhidden項目に設定
        clickServiceLabel();
    });

    /**
     * サービス選択時にカテゴリマスタ情報をhidden項目に設定しsubmitします。
     * @private
     */
    var clickServiceLabel = function() {
        $('.button-menu').on('click', function(ev) {
            var form = $('#form-main');
            var source = $(this).children('[type=hidden]');
            $('#selectServiceLabel').val(source.eq(0).val());
            $('#selectServiceId').val(source.eq(1).val());
            $('#selectCategorySeq').val(source.eq(2).val());
            $('#selectGroupId').val(source.eq(3).val());
            $('#selectServiceUrl').val(source.eq(4).val());
            form.submit();
        });
        $('#menu-analytics #analytics-button').on('click', function(ev) {
            var form = $('#form-analytics');
            var source = $(this).children('[type=hidden]');
            $('#selectServiceLabel').val(source.eq(0).val());
            $('#selectServiceId').val(source.eq(1).val());
            $('#selectCategorySeq').val(source.eq(2).val());
            $('#selectGroupId').val(source.eq(3).val());
            $('#selectServiceUrl').val(source.eq(4).val());
            form.submit();
        });
        $('#menu-settings #mfa-button').on('click', function(ev) {
            var form = $('#form-mfa');
            var source = $(this).children('[type=hidden]');
            $('#selectServiceLabel').val(source.eq(0).val());
            $('#selectServiceId').val(source.eq(1).val());
            $('#selectCategorySeq').val(source.eq(2).val());
            $('#selectGroupId').val(source.eq(3).val());
            $('#selectServiceUrl').val(source.eq(4).val());
            form.submit();
        });

    };

});
