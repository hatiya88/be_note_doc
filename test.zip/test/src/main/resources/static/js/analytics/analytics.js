(function(global, namespace, factory) {
// ///* DON'T CHANGE CODE BELOW THIS LINE
// */////////////////////////////////////////////////
	if (namespace) {
		if (!(namespace in global)) {
			global[namespace] = {};
		}
		factory.call(global[namespace], global);
	} else {
		factory.call(global, global);
	}
// ///* DON'T CHANGE CODE ABOVE THIS LINE
// */////////////////////////////////////////////////
})(window, 'Analytics', function(global) {

    /**
	 * 利用者状況確認ツール
	 * 
	 * @global
	 */
	$(function() {
		
		// クッキー削除
		var date = new Date();
		date.setTime( date.getTime() - 1 );
		document.cookie = 'fileDownload=true; path=/; expires=' + date.toUTCString();
		document.cookie = 'fileDownload=false; path=/; expires=' + date.toUTCString();

		if ($("#fatalError").val() != "1") {
			// 検索条件エリアを表示する。
			$(".title-left").css('visibility', "visible");
			$(".title-center").css('visibility', "visible");
			$("#searchButton").css('visibility', "visible");
			$("#csvOutputButton").css('visibility', "visible");
			$("#select-searvice-kind").css('visibility', "visible");
			$("#select-unit").css('visibility', "visible");
			$("#select-depertment").css('visibility', "visible");
			$("#select-csv-pattern").css('visibility', "visible");
	
			//集計期間（日付選択欄、日付範囲選択欄、月範囲選択欄は重ねている。いずれかの選択欄ひとつを表示する。）
			searchButtonClick();
			setDatepicker();
	
			// グラフ・集計表エリアを表示する。
			$("#graph-area").css('visibility', 'visible');
			$("#totalling-area").css('visibility', 'visible');
	
			// サービス種別
			var searviceKindOptions = $("#select-searvice-kind option");
			for ( var a="", i=0,l=searviceKindOptions.length; l>i; i++ ) {
				if (searviceKindOptions.eq(i).val() === $("#selectSearviceKindSelected").val()) {
					searviceKindOptions.eq(i).prop("selected", true);
					break;
				}
			}
			serviceKindChanged("0");
			unitChanged(false);
		}

		// 不正日付チェック
		$('#period-date')
		.focusout(function(e) {
			checkInputDate('#period-date');
		});
		$('#period-from-date')
		.focusout(function(e) {
			checkInputDate('#period-from-date');
		});
		$('#period-to-date')
		.focusout(function(e) {
			checkInputDate('#period-to-date');
		});
	});

	/**
	 * 日付入力欄入力値チェック
	 * 不正日付、入力可能期間をチェックします。
	 * 不正日付のとき前日、入力可能期間外のときは入力可能期間の最大(または最小）日を代入します
	 */
	function checkInputDate(id) {
		var yesterday = new Date();
		yesterday.setDate(yesterday.getDate() - 1);
		// 日付形式チェック
		if(!$(id).val().match(/^\d{4}\/\d{1,2}\/\d{1,2}$/)){
			$(id).val(yesterday.getFullYear() + "/" + ('00' + (yesterday.getMonth() + 1)).slice(-2) + "/" + ('00' + yesterday.getDate()).slice(-2));
		}

		// 入力可能期間チェック
		var inputDay = new Date($(id).val());
		var inputDayStr = inputDay.getFullYear() + "/" + ('00' + (inputDay.getMonth() + 1)).slice(-2) + "/" + ('00' + inputDay.getDate()).slice(-2);
		var yesterdayStr = yesterday.getFullYear() + "/" + ('00' + (yesterday.getMonth() + 1)).slice(-2) + "/" + ('00' + yesterday.getDate()).slice(-2);
		if(yesterdayStr < inputDayStr){
			$(id).val(yesterdayStr);
		}
		var retentionPeriod = new Date($('#dataRetentionPeriod').val());
		var retentionPeriodStr = retentionPeriod.getFullYear() + "/" + ('00' + (retentionPeriod.getMonth() + 1)).slice(-2) + "/" + ('00' + retentionPeriod.getDate()).slice(-2);
		if(inputDayStr < retentionPeriodStr){
			$(id).val(retentionPeriodStr);
		}
	}
	// ダイアログ表示
	// CSV取得結果表示用
	if ($("#csvResultDialog").val() != "") {
		AppUtils.messageDialog($("#csvResultDialog").val());
	}

	// エラーのとき、検索項目以下を非表示にし、エラーメッセージを表示する
	if ($("#fatalError").val() == "1") {
		$("#search-panel").css('visibility', 'hidden');
		$("#common-error-message").css('visibility', 'visible');
	}
	

	// 画面初期表示の場合は、「検索条件」初期値のグラフ・表を表示する
	if ($("#firstDisplay").val() == "0") {
		// 初期値を設定してから検索処理を実行する
		$('#loading').show();
		$("#search-panel").css('visibility', 'hidden');
		serviceKindChanged("1");
		submitAnalytics($('#search-url').val());
		$("#search-panel").css('visibility', 'visible');
	}
	
	//--------------------------------
	// 検索処理
	// --------------------------------
	/**
	 * ボタンクリック
	 */
	var searchButtonClick = function() {
		//-------------------------
		// 検索ボタン
		//-------------------------
		$('#searchButton').on('click', function(e) {
			AppUtils.clearGuidance();
			e.target.blur();
			AppUtils.beforeValidate('#form-main');
			var confirmGraphMsg = 'グラフを取得します。よろしいですか？';
			var yesCallBack = function(){submitAnalytics($('#search-url').val());};
			// 入力値チェック
			if (!checkInputData()) {
				return;
			}
			if ($('#form-main').validationEngine('validate')) {
				$('#loading-message-value').text("データ取得中");
				AppUtils.confirmMessageDialog(confirmGraphMsg, yesCallBack);
			}
		});

		//-------------------------
		// CSV出力ボタン
		//-------------------------		
		$('#csvOutputButton').on('click', function(e) {
			AppUtils.clearGuidance();
			AppUtils.beforeValidate('#form-main');
			var confirmCsvMsg = 'CSVファイルを取得します。よろしいですか？';
			var yesCallBack = function(){
				cookeieTimerStart();					// クッキー監視開始
				submitAnalytics($('#csv-url').val());
				$('#confirm-modal').fadeOut();			// 確認画面はここで閉じる
			};
			// 入力値チェック
			if (!checkInputData("1")) {
				return;
			}
			if ($('#form-main').validationEngine('validate')) {
				// クッキー削除
				var date = new Date();
				date.setTime( date.getTime() - 1 );
				document.cookie = 'fileDownload=true; path=/; expires=' + date.toUTCString();
				document.cookie = 'fileDownload=false; path=/; expires=' + date.toUTCString();
				AppUtils.confirmMessageDialog(confirmCsvMsg, yesCallBack);
			}
		});
	}

	/***********************************************
	 * ファイルダウンロード時のグルグルをダウンロード完了後に消す
	 ************************************************/
	var cookeieTimer;
	/**
	 * クッキー監視ストップ
	 */
	function cookeieTimerStop() {
		clearInterval(cookeieTimer);
	}
	
	/**
	 * クッキー監視
	 */
	function cookeieTimerStart() {
		cookeieTimer=setInterval(function () {
			var fileDownloadCookie = document.cookie;
			if (fileDownloadCookie){
				var cookiesArray = fileDownloadCookie.split(';');
				for (let i = 0; i < cookiesArray.length; ++i) {
					var cArray = cookiesArray[i].split('=');
					// CSVダウンロードのレスポンスに[fileDownload=true]を仕込んでいる
					if( cArray[0] == 'fileDownload' && cArray[1] == 'true'){
						// グルグルを消す
						$('#loading').fadeOut();
						$('#modal-bg').fadeOut();
						cookeieTimerStop();
					}
				}
			}
		}, 500);
	}

	/**
	 * Submit処理
	 */
	function submitAnalytics(url){
		
		var form = $('#form-main');
		var searchItemDto = [];
		var searchItemDto = {
				selectServiceKind: $('#select-searvice-kind').val(),
				selectUnit: $('#select-unit').val(),
				selectPeriodFromDate: $('#period-from-date').val(),
				selectPeriodToDate: $('#period-to-date').val(),
				selectPeriodStart: $('#select-period-start').val(),
				selectPeriodEnd: $('#select-period-end').val(),
				selectDepertment: $('#select-depertment').val(),
				selectCsvPattern: $('#select-csv-pattern').val(),
				selectPeriodDate: $('#period-date').val(),
		};
		$('#search-item-json').val(JSON.stringify(searchItemDto));
		form.attr('action',url);
		form.submit();
	}

	/**
	 * 入力値チェック
	 * 
	 * @param submitButton	""：検索ボタン押下
	 * 						 1:CSV出力ボタン押下
	 * 
	 */	
	function checkInputData(submitButton) {
		// エラーメッセージクリア
		AppUtils.clearMessageArea('#message-area .error');
		// 入力値チェック
		switch ($("#select-unit").val()) {
		case "hour":
			// 日付形式チェック
			if (!checkDate($("#period-date").val())) {
				return false;
			};

			// 時間ごとのときは日付範囲なし
			break;

		case "day":
			// 日付形式チェック
			if (!checkDate($("#period-from-date").val())) {
				return false;
			};
			if (!checkDate($("#period-to-date").val())) {
				return false;
			};

			// 利用者登録情報-集計期間の利用者登録を出力など、全期間出力対象のCSVのときは期間のチェックをしない
			// ※<span>タグで非表示にしているため、$("#select-csv-pattern option:selected").attr("searchPeriodType")では
			// 正しく値が取得できないため、以下のLoopでselectedSearchPeriodTypeに選択されたオプションのsearchPeriodTypeを取得する
			var csvPatternOptions = $("#select-csv-pattern option[dfilter='"+$("#select-searvice-kind").val()+"']");
			var selectedSearchPeriodType = "0";
			for ( var a="", i=0,l=csvPatternOptions.length; l>i; i++ ) {
				if (csvPatternOptions.eq(i).val() === $('#select-csv-pattern').val()) {
					selectedSearchPeriodType = csvPatternOptions.eq(i).attr("searchPeriodType");
					break;
				}
			}
			// selectedSearchPeriodType：CSV出力パターンマスタ[検索期間条件タイプ]
			//							（1：日時を検索条件に加える、2：日時を検索条件に入れない）
			//							※2：日時を検索条件に入れない、は利用登録者情報のCSV出力で「前日までの利用登録者情報を出力」のときに、出力する日付範囲を制限しないためのフラグ
			if (submitButton == "1" && selectedSearchPeriodType == "2") {
				return true;
			};

			var fromDate = new Date($("#period-from-date").val());
			var toDate = new Date($("#period-to-date").val());
			
			// 自至が前後しているか
			if (toDate < fromDate) {
				AppUtils.errorMessage('集計期間が不正です。<br>終了日を開始日よりも後に設定して下さい。');
				return false;
			}
			// 最大日付範囲チェック
			var plusDate = fromDate;
			plusDate.setDate(plusDate.getDate() + parseInt($("#searchMaxDays").val() -1));
			if (plusDate < toDate) {
				AppUtils.errorMessage('表示可能な最大期間（' + $("#searchMaxDays").val() + '日）を超えるため、検索条件を見直してください。');
				return false;
			}
			break;

		case "month" :
			// 利用者登録情報-集計期間の利用者登録を出力など、全期間出力対象のCSVのときは期間のチェックをしない
			// ※<span>タグで非表示にしているため、$("#select-csv-pattern option:selected").attr("searchPeriodType")では
			//  正しく値が取得できないため、以下のLoopでselectedSearchPeriodTypeに選択されたオプションのsearchPeriodTypeを取得する
			var csvPatternOptions = $("#select-csv-pattern option[dfilter='"+$("#select-searvice-kind").val()+"']");
			var selectedSearchPeriodType = "0";
			for ( var a="", i=0,l=csvPatternOptions.length; l>i; i++ ) {
				if (csvPatternOptions.eq(i).val() === $('#select-csv-pattern').val()) {
					selectedSearchPeriodType = csvPatternOptions.eq(i).attr("searchPeriodType");
					break;
				}
			}
			// selectedSearchPeriodType：CSV出力パターンマスタ[検索期間条件タイプ]
			//							（1：日時を検索条件に加える、2：日時を検索条件に入れない）
			//							※2：日時を検索条件に入れない、は利用登録者情報のCSV出力で「前日までの利用登録者情報を出力」のときに、出力する日付範囲を制限しないためのフラグ
			if (submitButton == "1" && selectedSearchPeriodType == "2") {
				return true;
			};

			// 自至が前後しているか
			if ($("#select-period-end").val() < $("#select-period-start").val()) {
				AppUtils.errorMessage('集計期間が不正です。<br>終了日を開始日よりも後に設定して下さい。');
				return false;
			}
			var strFromDate = $("#select-period-start").val();
			var fromDate = new Date(strFromDate.slice(0, 4)
					+ "/" + strFromDate.slice(4, 6)
					+ "/" + strFromDate.slice(6, 8));
			var strToDate = $("#select-period-end").val();
			var toDate = new Date(strToDate.slice(0, 4)
					+ "/" + strToDate.slice(4, 6)
					+ "/" + strToDate.slice(6, 8));
			// 最大範囲チェック
			var plusDate = fromDate;
			plusDate.setMonth(plusDate.getMonth() + parseInt($("#searchMaxMonths").val()));
			if (plusDate < toDate) {
				AppUtils.errorMessage('表示可能な最大期間（' + $("#searchMaxMonths").val() + '月）を超えるため、検索条件を見直してください。');
				return false;
			}
			break;
		}
		return true;
	}

	/**
	 * 日付チェック
	 */
	function checkDate(strDate) {
		if (strDate.length == 0) {
			AppUtils.errorMessage('集計期間は必須入力です。');
			return false;
		}
		if (!strDate.match(/^\d{4}\/\d{1,2}\/\d{1,2}$/)) {
			AppUtils.errorMessage('有効な日付を入力してください。');
			return false;
		}
		var y = strDate.split("/")[0];
		var m = strDate.split("/")[1] - 1;
		var d = strDate.split("/")[2];
		var date = new Date(y,m,d);
		if (date.getFullYear() != y || date.getMonth() != m || date.getDate() != d) {
			AppUtils.errorMessage('有効な日付を入力してください。');
			return false;
		}
		return true;
	}

	/**
	 * サービス選択の変更イベント
	 */
	$("#select-searvice-kind").change(function() {
		// 選択した値をクリアする
		crearSelectValue();
		// サービス種別変更イベント
		serviceKindChanged("0");
		unitChanged(false);			// 集計単位変更時の処理も行う
		// グラフ表示
		$('#loading-message-value').text("データ取得中");
		submitAnalytics($('#search-url').val());
	});

	/**
	 * 集計単位の変更イベント
	 */
	$("#select-unit").change(function() {
		unitChanged(true);
	});

	/**
	 * サービス種変更イベント処理
	 */
	function serviceKindChanged(firstDisp){
	/*<![CDATA[*/
		
		// エラーメッセージ部表示
		if ($("#fatalError").val() == "1") {
			$("#common-error-message").css('visibility', "visible");
			return;
		}

		//------------------------------------------------
		// 集計単位、CSV出力パターン選択肢設定
		//------------------------------------------------
		var searviceKind = $("#select-searvice-kind").val();
		if (searviceKind.length == 0){
			//集計単位
			$("#select-unit > span option:not([dfilter])").unwrap();			//名称なし→表示
			$("#select-unit > option[dfilter]").wrap("<span>");					//名称あり→隠す
			//CSV出力パターン
			$("#select-csv-pattern > span option:not([dfilter])").unwrap();		//名称なし→表示
			$("#select-csv-pattern > option[dfilter]").wrap("<span>");			//名称あり→隠す
			//診療科
			$("#select-depertment > option:not([dfilter])").wrap("<span>");		//名称なし  →隔す
			//集計期間
			$("#select-period-start > option:not([dfilter])").wrap("<span>");	//名称なし  →隔す
			$("#select-period-end > option:not([dfilter])").wrap("<span>");		//名称なし  →隔す

		} else {
			//サービス種別が指定されたとき：サービスIDが同じものを表示、違うものを非表示にする
			//集計単位
			$("#select-unit > option:not([dfilter])").wrap("<span>");							//名称なし  →隔す
			$("#select-unit > option:not([dfilter='"+searviceKind+"'])").wrap("<span>");		//名称不一致→隔す
			$("#select-unit > span option[dfilter='"+searviceKind+"']").unwrap();				//名称一致→表示
			//CSV出力パターン
			$("#select-csv-pattern > option:not([dfilter])").wrap("<span>");					//名称なし  →隔す
			$("#select-csv-pattern > option:not([dfilter='"+searviceKind+"'])").wrap("<span>");	//名称不一致→隔す
			$("#select-csv-pattern > span option[dfilter='"+searviceKind+"']").unwrap();		//名称一致→表示
			//診療科
			$("#select-depertment > span option:not([dfilter])").unwrap();						//名称なし→表示
			//集計期間
			$("#select-period-start > span option:not([dfilter])").unwrap();					//名称なし→表示
			$("#select-period-end > span option:not([dfilter])").unwrap();						//名称なし→表示

			//------------------------------------------------
			// 初期値
			// 検索またはCSV出力後で、選択した値があるときは、選択した値にする
			//------------------------------------------------
			var isSet = false;	// 初期値または選択した値がセットされたか
			var dayIndex = 0;
			// 集計単位-初期値（ユーザー汎用マスタ）
			var unitOptions = $("#select-unit option[dfilter='"+searviceKind+"']");
			for ( var a="", i=0,l=unitOptions.length; l>i; i++ ) {
				// ユーザー汎用マスタに初期値が設定されていない場合、dayを初期値とするためindexを退避しておく
				if (unitOptions.eq(i).val() == 'day') {
					dayIndex = i;
				}
				if (unitOptions.eq(i).val() === $("#default_" + searviceKind + "_unit").val()) {
					unitOptions.eq(i).prop("selected", true);
					isSet = true;
					break;
				}
			}
			// ユーザー汎用マスタの初期値で設定できないとき、システム初期値としてdayを選択する
			if (!isSet) {
				unitOptions.eq(dayIndex).prop("selected", true);
				isSet = true;
			}
			// 集計単位-選択した値
			for ( var a="", i=0,l=unitOptions.length; l>i; i++ ) {
				if (unitOptions.eq(i).val() === $("#selectUnitSelected").val()) {
					unitOptions.eq(i).prop("selected", true);
					isSet = true;
					break;
				}
			}
			if (!isSet) {
				//該当する初期値がなければ一番上の項目を選択
				unitOptions.eq(0).prop("selected", true);
			}

			// 診療科-初期値（ユーザー汎用マスタ）
			isSet = false;
			var deptOptions = $("#select-depertment option");
			for ( var a="", i=0,l=deptOptions.length; l>i; i++ ) {
				if (deptOptions.eq(i).val() === $("#default_" + searviceKind + "_dept_code").val()) {
					deptOptions.eq(i).prop("selected", true);
					isSet = true;
					break;
				}
			}
			// 診療科-選択した値
			for ( var a="", i=0,l=deptOptions.length; l>i; i++ ) {
				if (deptOptions.eq(i).val() === $("#selectDepertmentSelected").val()) {
					deptOptions.eq(i).prop("selected", true);
					isSet = true;
					break;
				}
			}
			if (!isSet) {
				//該当する初期値がなければ一番上の項目を選択
				deptOptions.eq(0).prop("selected", true);
			}

			// CSV出力パターン-初期値（ユーザー汎用マスタ）
			isSet = false;
			var csvPatternOptions = $("#select-csv-pattern option[dfilter='"+searviceKind+"']");
			for ( var a="", i=0,l=csvPatternOptions.length; l>i; i++ ) {
				if (csvPatternOptions.eq(i).val() === $("#default_" + searviceKind + "_csv_output").val()) {
					csvPatternOptions.eq(i).prop("selected", true);
					isSet = true;
					break;
				}
			}
			// CSV出力パターン-選択した値
			for ( var a="", i=0,l=csvPatternOptions.length; l>i; i++ ) {
				if (csvPatternOptions.eq(i).val() === $("#selectCsvPatternSelected").val()) {
					csvPatternOptions.eq(i).prop("selected", true);
					isSet = true;
					break;
				}
			}
			if (!isSet) {
				//該当する初期値がなければ一番上の項目を選択
				csvPatternOptions.eq(0).prop("selected", true);//該当する初期値がなければ一番上の項目を選択
			}

			// 月別期間開始-初期値（ユーザー汎用マスタ）
			isSet = false;
			var periodStartOptions = $("#select-period-start option");
			if ($("#default_" + searviceKind + "_unit").val() == 'month') {
				for ( var a="", i=0,l=periodStartOptions.length; l>i; i++ ) {
					if (periodStartOptions.eq(i).val() === $("#default_" + searviceKind + "_period_start").val()) {
						periodStartOptions.eq(i).prop("selected", true);// サービス種別選択時はマスタの初期値
						isSet = true;
						break;
					}
				}
			}
			// 月別期間開始-選択した値
			for ( var a="", i=0,l=periodStartOptions.length; l>i; i++ ) {
				if (periodStartOptions.eq(i).val() === $("#selectPeriodStartSelected").val()) {
					periodStartOptions.eq(i).prop("selected", true);
					isSet = true;
					break;
				}
			}
			// 月別期間開始-システム初期値
			if (!isSet) {
				for ( var a="", i=0,l=periodStartOptions.length; l>i; i++ ) {
					// 先頭より１つ前
					if (i == "1") {
						periodStartOptions.eq(i).prop("selected", true);
						break;
					}
				}
			}

			// 月別期間終了-初期値（ユーザー汎用マスタ）
			isSet = false;
			var periodEndOptions = $("#select-period-end option");
			if ($("#default_" + searviceKind + "_unit").val() == 'month') {
				for ( var a="", i=0,l=periodEndOptions.length; l>i; i++ ) {
					if (periodEndOptions.eq(i).val() === $("#default_" + searviceKind + "_period_end").val()) {
						periodEndOptions.eq(i).prop("selected", true);// サービス種別選択時はマスタの初期値
						isSet = true;
						break;
					}
				}
			}
			// 月別期間終了-選択した値
			for ( var a="", i=0,l=periodEndOptions.length; l>i; i++ ) {
				if (periodEndOptions.eq(i).val() === $("#selectPeriodEndSelected").val()) {
					periodEndOptions.eq(i).prop("selected", true);
					isSet = true;
					break;
				}
			}
			// 月別期間開始-システム初期値
			if (!isSet) {
				for ( var a="", i=0,l=periodStartOptions.length; l>i; i++ ) {
					// 先頭より１つ前
					if (i == "1") {
						periodEndOptions.eq(i).prop("selected", true);
						break;
					}
				}
			}

			// 日別期間開始
			if ($("#selectPeriodFromDate").val() != "") {
				$("#period-from-date").val($("#selectPeriodFromDate").val());
			} else {
				if ($("#default_" + searviceKind + "_unit").val() == 'day') {
					// サービス種別選択時はユーザー汎用マスタの初期値
					$("#period-from-date").val($("#default_" + searviceKind + "_period_start").val());
				} else {
					// 設定するマスタ値がないときはシステムの初期値
					$("#period-from-date").val($("#default_periodFromDate").val());
				}
			}
			// 日別期間終了
			if ($("#selectPeriodToDate").val() != "") {
				$("#period-to-date").val($("#selectPeriodToDate").val());
			} else {
				if ($("#default_" + searviceKind + "_unit").val() == 'day') {
					// サービス種別選択時はユーザー汎用マスタの初期値
					$("#period-to-date").val($("#default_" + searviceKind + "_period_end").val());
				} else {
					// 設定するマスタ値がないときはシステムの初期値
					$("#period-to-date").val($("#default_periodToDate").val());
				}
			}

			// 日付
			if ($("#periodDateSelected").val() != "") {
				$("#period-date").val($("#periodDateSelected").val());
			} else {
				if ($("#default_" + searviceKind + "_unit").val() == 'hour') {
					// サービス種別選択時はユーザー汎用マスタの初期値
					$("#period-date").val($("#default_" + searviceKind + "_period_start").val());
				} else {
					// 設定するマスタ値がないときはシステムの初期値
					$("#period-date").val($("#default_periodDate").val());
				}
			}

			// 初回表示時は、表示の設定をしない
			if (firstDisp == "0") {
				//------------------------------------------------
				// 診療科選択欄表示・非表示切替
				//------------------------------------------------
				var depertmentVisibility = "visible";
				if ($("#deptDisplay_" + searviceKind).val() == "0") {
					depertmentVisibility = "hidden";
				}
				// 診療科選択欄
				$("#label-select-depertment").css('visibility', depertmentVisibility);
				$("#select-depertment").css('visibility', depertmentVisibility);
	
				//------------------------------------------------
				// CSV出力パターン表示・非表示切替
				//------------------------------------------------
				if (searviceKind == "PRC-Disp") {
					$("#label-csv-pattern").css('visibility', "hidden");
					$("#select-csv-pattern").css('visibility', "hidden");
				} else {
					$("#label-csv-pattern").css('visibility', "visible");
					$("#select-csv-pattern").css('visibility', "visible");
				}
	
				//------------------------------------------------
				// 注意書き表示
				//------------------------------------------------
				$("#messageArea").text($("#message_" + searviceKind).val());
			}
		}
	/*]]>*/
	}

	/**
	 * 集計単位変更イベント
	 */
	function unitChanged(unitChangeFlg){
		// 集計単位を変更したときに集計期間の表示を切り替える
		var value = $("#select-unit").val();
		// 日付選択
		if (value == "hour") {
			$("#period-list").css('visibility', "visible");
			$("#period-calendar").css('display', '');			// 日付選択
			$("#period-calenderlist").css('display', 'none');	// 日付範囲選択
			$("#period-list").css('display', 'none');			// 月選択
			// 初期値
			if (unitChangeFlg) {
				$("#period-date").val($("#default_periodDate").val());
			}

		// 日付範囲選択
		} else if (value == "day") {
			$("#period-list").css('visibility', "visible");
			$("#period-calendar").css('display', 'none');
			$("#period-calenderlist").css('display', '');
			$("#period-list").css('display', 'none');
			// 初期値
			if (unitChangeFlg) {
				$("#period-from-date").val($("#default_periodFromDate").val());
				$("#period-to-date").val($("#default_periodToDate").val());
			}

		// 月選択
		} else if (value == "month") {
			$("#period-list").css('visibility', "visible");
			$("#period-calendar").css('display', 'none');
			$("#period-calenderlist").css('display', 'none');
			$("#period-list").css('display', '');
			// 初期値
			if (unitChangeFlg) {
				var periodStartOptions = $("#select-period-start option");
				for ( var a="", i=0,l=periodStartOptions.length; l>i; i++ ) {
					if (periodStartOptions.eq(i).val() === $("#default_selectPeriodStart").val()) {
						periodStartOptions.eq(i).prop("selected", true);
						break;
					}
				}
				var periodStartOptions = $("#select-period-end option");
				for ( var a="", i=0,l=periodStartOptions.length; l>i; i++ ) {
					if (periodStartOptions.eq(i).val() === $("#default_selectPeriodEnd").val()) {
						periodStartOptions.eq(i).prop("selected", true);
						break;
					}
				}
			}

		} else {
			$("#period-list").css('visibility', "visible");
			$("#period-calendar").css('display', 'none');
			$("#period-calenderlist").css('display', 'none');
			$("#period-list").css('display', '');
		}
	}

	/**
	 * Datepicker設定
	 */
	function setDatepicker() {
		var yesterday = new Date();
		yesterday.setDate(yesterday.getDate() - 1);
		$("#period-from-date").datetimepicker({lang:'ja', minDate: $("#dataRetentionPeriod").val(), maxDate: yesterday, timepicker:false, format:'Y/m/d'});
		$("#period-to-date").datetimepicker({lang:'ja', minDate: $("#dataRetentionPeriod").val(), maxDate: yesterday, timepicker:false, format:'Y/m/d'});
		$("#period-date").datetimepicker({lang:'ja', minDate: $("#dataRetentionPeriod").val(), maxDate: yesterday, timepicker:false, format:'Y/m/d'});
	}

	/**
	 * 選択した値をクリアする
	 */
	function crearSelectValue() {
		$("#selectSearviceKindSelected").val("");
		$("#selectUnitSelected").val("");
		$("#periodDateSelected").val("");
		$("#selectPeriodFromDate").val("");
		$("#selectPeriodToDate").val("");
		$("#selectPeriodStartSelected").val("");
		$("#selectPeriodEndSelected").val("");
		$("#selectDepertmentSelected").val("");
		$("#selectCsvPatternSelected").val("");
	}
});