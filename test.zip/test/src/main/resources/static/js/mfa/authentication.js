(function(global, namespace, factory) {
	// ///* DON'T CHANGE CODE BELOW THIS LINE
	// */////////////////////////////////////////////////
	if (namespace) {
		if (!(namespace in global)) {
			global[namespace] = {};
		}
		factory.call(global[namespace], global);
	} else {
		factory.call(global, global);
	}
	// ///* DON'T CHANGE CODE ABOVE THIS LINE
	// */////////////////////////////////////////////////
})(window, 'Authentication', function(global) {

	/**
	 * 二要素認証画面 OnLoad 処理
	 * 
	 * @global
	 */
	$(function() {
		submitauthentication();
		submitFailure();
		messageStyle();
		AppUtils.onlySingleByte();
	});

	/**
	 * 「認証」ボタン押下
	 */
	var submitauthentication = function() {
		$('#button-authentication').on('click', function() {
			AppUtils.clearMessageArea();
			if (authenticationValidation()) {
				$('#form-main').submit();
			}
		});
	};

	/**
	 * ログイン前チェック
	 */
	var authenticationValidation = function() {
		var validated = $('#text_opt-code').val() != '';
		if (validated) {
			return validated;
		}
		AppUtils.errorMessage('認証コードを入力してください。');
		return validated;
	}

	/**
	 * 「こちら」ボタン押下時にHPP作成画面へ遷移する
	 */
	var submitFailure = function() {
		$('#recovery_link').on('click', function() {
			$('#form-recovery').submit();
		});
	};

	/**
	 * メッセージスタイル調整
	 */
	var messageStyle = function() {
		var errorMsgAry = $('#message-area .error li');
		if (errorMsgAry.length > 0) {
			// エラーメッセージ文字数により認証コード入力領域の幅を超えるかチェック
			var loginAreaWidth = 410;
			var fontWidth = 12.8;
			var isExistOverWidth = false;
			$.each(errorMsgAry, function(idx, ele) {
				if (($(ele).text().length * fontWidth) > loginAreaWidth) {
					isExistOverWidth = true;
				}
			});
			// 超える場合は文字列先頭位置固定ではなく中央寄せに変更
			if (isExistOverWidth) {
				$.each(errorMsgAry, function(idx, ele) {
					$(ele).css('padding-left', '0');
					$(ele).css('text-align', 'center');
				});
			}
		}
	}
});
