(function(global, namespace, factory) {
	// ///* DON'T CHANGE CODE BELOW THIS LINE
	// */////////////////////////////////////////////////
	if (namespace) {
		if (!(namespace in global)) {
			global[namespace] = {};
		}
		factory.call(global[namespace], global);
	} else {
		factory.call(global, global);
	}
	// ///* DON'T CHANGE CODE ABOVE THIS LINE
	// */////////////////////////////////////////////////
})(window, 'Mfa', function(global) {

    $(function() {
        // 一括更新
    	uploadButton();
    });

	/**
     * 一括更新
     */
    var uploadButton = function() {
	$('#form-main-upload').click(function() {
		AppUtils.clearMessageArea();
		var defaultValue = $('input[name="defaultValue"]').val();
		var selection = $('input[name="selections mfa-radio"]:checked').val();
		if (defaultValue === selection) {
			AppUtils.errorMessage('設定を変更してから更新してください。');
		} else {
			AppUtils.uploadButton(true, '画面の内容で設定を更新します。よろしいですか？');
		}
	});
    };
//	/**
//	 * アップロード処理
//	 */
//	$('#form-main-upload').click(function() {
//		AppUtils.clearMessageArea();
//		var defaultValue = $('input[name="defaultValue"]').val();
//		var selection = $('input[name="selections mfa-radio"]:checked').val();
//		if (defaultValue === selection) {
//			AppUtils.errorMessage('設定を変更してから更新してください。');
//		} else {
//			AppUtils.uploadButton(true, '画面の内容で設定を更新します。よろしいですか？');
//		}
//	});
});
