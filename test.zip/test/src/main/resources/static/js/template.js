(function(global, namespace, factory) {
/////* DON'T CHANGE CODE BELOW THIS LINE */////////////////////////////////////////////////
    if (namespace) {
        if (!(namespace in global)) {
            global[namespace] = {};
        }
        factory.call(global[namespace], global);
    } else {
        factory.call(global, global);
    }
/////* DON'T CHANGE CODE ABOVE THIS LINE */////////////////////////////////////////////////
})(window, 'Template', function(global) {

    /**
     * テンプレート画面 OnLoad 処理
     * @global
     */
    $(function() {
    	// レイアウト判定
    	Template.checkHorizontal();
    	// 入力ルール追加
    	addValidRules();
    	// 更新ボタン制御
    	Template.uploadButtonControl(Template.isEnableUpload());
    	// 一括更新
    	Template.templateUploadButton();
    	// 削除チェック
    	AppUtils.deleteCheck();
    	// 追加ボタン
    	addRow();
        // 入力内容変更フラグ
        AppUtils.formChangedOn(Template.formId, '#form-changed-flg');
        // メッセージ行数に合わせたform-contents部スタイル補正
        AppUtils.formContentStyleOffset();
        // 横レイアウト データゼロ件レイアウト制御
        Template.noDataHorizontalLayout();
        // 一覧部分のtbodyのYスクロールをtheadと分離したためXスクロールを同期
        AppUtils.scrollTableBody();
    });
    
    /**
     * 横レイアウトの判定(デフォルト縦レイアウト)
     */
    this.isHorizontal = false;
    this.formId = "#form-main";    
    this.checkHorizontal = function() {
    	if ($('#form-main-horizontal').length > 0) {
    		Template.isHorizontal = true;
    		Template.formId = "#form-main-horizontal";
    	}
    };
    
    /**
     * マスタの入力ルール追加
     */
    var addValidRules = function() {
    	for (var rule in MASTER_VALID_RULES) {
    		if (!$.validationEngineLanguage.allRules[rule]) {
    			$.validationEngineLanguage.allRules[rule] = {
    				"func": new Function("field", "rules", "i", "options", MASTER_VALID_RULES[rule].func), 
    				"alertText": MASTER_VALID_RULES[rule].alertText
    			};
    		} else if (!!MASTER_VALID_RULES[rule].alertText) {
    			$.validationEngineLanguage.allRules[rule].alertText = MASTER_VALID_RULES[rule].alertText;
    		}
    	}
    };

    /**
     * 一括更新ボタン
     */
    this.templateUploadButton = function() {
    	// 入力欄なしの場合はイベント制御不要
    	if (!Template.isEnableUpload()) return;
    	
    	var confirmMsg = '画面の内容で設定を更新します。';
    	if ($(Template.formId + ' [type=checkbox].delete-check').length > 0) {
    		confirmMsg += '削除選択された行は削除されます。';
    	}
    	confirmMsg += 'よろしいですか？';
    	$('#form-main-upload').on('click', function(e) {
    		AppUtils.clearMessageArea();
    		e.target.blur();
    		AppUtils.beforeValidate(Template.formId);
    		if ($(Template.formId).validationEngine('validate')) {
    			if (Template.isHorizontal) {
        			AppUtils.confirmMessageDialog(confirmMsg, Template.uploadHorizontal);
    			} else {
        			AppUtils.confirmMessageDialog(confirmMsg, Template.upload);
    			}
    		}
    	});
    }
    
    /**
     * アップロード処理
     */
    this.upload = function() {
    	var uploadForm = $(Template.formId);
    	var btn = $('.button-primary.upload');
    	var inputDtoAry = [];
    	// 1件しか扱えないマスタで主キー値変更は無い前提
    	uploadForm.find('input[type=text],input[type=number],textarea,input[type=radio]:checked,select').each(function(idx, ele) {
    		var obj = $(ele);
    		// マスタの主キーを連想配列にする。
    		var primaryKeyMap = {};
    		var pkNameAry = String(obj.data('primarykey-names')).split(',');
    		var pkVal = obj.data('primarykey-values') === undefined ? '' : String(obj.data('primarykey-values'));
    		var pkValAry = pkVal.split(',');
    		for (var i = 0;i < pkNameAry.length;i++) {
    			primaryKeyMap[pkNameAry[i]] = pkValAry[i];
    		}
    		// name属性=行番号-項目シーケンス、value=入力値、primaryKeyValueMap=key:主キー名、value=主キーの値（※カンマ区切りの主キー値など存在しない前提）
    		var dKeyName = !!obj.data('key-name') ? obj.data('key-name') : '';
    		var inputDto = {
    			tableName: obj.data('table-name'),
    			columnName: obj.data('column-name'),
    			keyName: dKeyName,
        		primaryKeyValueMap: primaryKeyMap,
    			name: obj.attr('name'),
    			value: obj.val()
    		};
    		inputDtoAry.push(inputDto);
    	});
    	
    	// 主キーの入力値を、テーブル名が一致する項目の主キー値にセットする（汎用マスタ以外(キー名が空)を対象）
    	$.each(inputDtoAry, function(i, self) {
    		if (self.primaryKeyValueMap[self.columnName] !== undefined && !self.keyName) {
    	    	$.each(inputDtoAry, function(j, other) {
    				if (self.tableName === other.tableName) {
    					other.primaryKeyValueMap[self.columnName] = self.value; // 主キー入力値
    				}
    			});
    		}
    	});
    	$('#inputdto-ary-json').val(JSON.stringify(inputDtoAry));
    	uploadForm.submit();
    };
    
    /**
     * 追加ボタン
     */
    var addRow = function() {
    	$('#button-add').on('click', function() {
    		var tr = $('#add-row-area tbody').children('tr')[0];
    		var rowCount = $('#template-table tbody').children('tr').length;
    		if (MAX_ROW_COUNT > 1 && rowCount >= MAX_ROW_COUNT) {
    			AppUtils.messageDialog('指定行数の最大値を超えました。');
    			return;
    		}
    		rowCount++;
    		// コピーごとに要素の属性値を適宜変更(主に一意性を保つため)
    		$(tr).find('input:not(.delete-check),label,textarea,select').each(function(index, ele) {
    			if (ele.tagName !== 'LABEL') {
        			var eleNameAry = ele.name.split('-');
        			var eleName = '';
        			var i = 0;
        			$.each(eleNameAry, function() {
        				if (i == 0) {
        					eleName += String(rowCount);
        				} else {
        					eleName += '-' + this;
        				}
        				i++;
        			});
        			ele.name = eleName;
        			$(ele).attr('data-row-num', String(rowCount));
    			}
    			var eleId = '';
        		if ((ele.tagName === 'INPUT' && $(ele).prop('type') === 'radio')
        				|| ele.tagName === 'LABEL') {
        			var attr = ele.tagName === 'LABEL' ? 'for' : 'id';
        			var eleIdAry = $(ele).prop(attr).split('-');
        			var i = 0;
        			$.each(eleIdAry, function() {
        				if (i == 0) {
        					eleId += String(rowCount);
        				} else {
        					eleId += '-' + this;
        				}
        				i++;
        			});
        			$(ele).prop(attr, eleId);
        		} 
    		});
    		$(tr).find('input.delete-check').each(function(index, ele) {
    			$(ele).prop('id', 'delete-row-' + rowCount);
    			$(ele).next('label').prop('for', 'delete-row-' + rowCount)
    		});
    		
    		$('#template-table tbody').append($(tr).clone());
    		
    		AppUtils.deleteCheck();
    	    // カレンダー
    	    AppUtils.setDatePicker();
            // 入力内容変更フラグ
            AppUtils.formChangedOn(Template.formId, '#form-changed-flg');
            
            // 更新ボタン制御
            if ($('#form-main-upload').prop('disabled')) {
            	var isEnableUpload = Template.isEnableUpload();
            	if (isEnableUpload) {
            		Template.uploadButtonControl(isEnableUpload);
            		Template.templateUploadButton();
            	}
            }
    	});
    };

    /**
     * アップロード処理(横レイアウト一覧形式)
     */
    this.uploadHorizontal = function() {
    	var uploadForm = $(Template.formId);
    	var btn = $('.button-primary.upload');
    	var rowAry = [];
    	$('#template-table tbody tr').each(function(r, trEle) {
    		var tr = $(trEle);
    		var row = {};
    		row['inputList'] = [];
    		var cIdx = 0;
    		// 行データ生成
    		tr.find('input[type=text]:not(.hidden-template-primary-column),input[type=number]:not(.hidden-template-primary-column),input[type=checkbox][name=deleteSelection],textarea,input[type=radio]:checked,select').each(function(c, ele) {
        		var obj = $(ele);
    			if (obj.attr('name') === 'deleteSelection') {
    				var deleteSelect = obj.prop('checked') ? '1' : '0';
    				row['deleteSelect'] = deleteSelect;
    			} else {
            		// 主キーのカラム名と値をセットにした連想配列にする
            		var primaryKeyMap = {};
            		var pkNameAry = String(obj.data('primarykey-names')).split(',');
            		var primaryKeyValue = obj.data('primarykey-values') === undefined ? '' : String(obj.data('primarykey-values'));
            		var pkValAry = primaryKeyValue.split(',');
            		for (var i = 0;i < pkNameAry.length;i++) {
            			primaryKeyMap[pkNameAry[i]] = pkValAry[i];
            		}
            		// name属性="行番号-項目シーケンス、value=入力値、primaryKeyValueMap=key:主キー名、value=主キーの値（※カンマ区切りの主キー値など存在しない前提）
            		var inputDto = {
                		primaryKeyValueMap: primaryKeyMap,
            			name: obj.attr('name'),
            			value: obj.val()
            		};
            		row['inputList'][cIdx] = inputDto;
            		row['primaryKeyValue'] = primaryKeyValue;
            		cIdx++;
    			}
    		});
    		rowAry.push(row);
    		
    		// 主キー変更された場合の削除行データ生成
    		row = {};
    		row['inputList'] = [];
    		cIdx = 0;
    		var isChangedPrimarykey = false;
    		tr.find('.hidden-template-primary-column').each(function(c, el) {
        		var obj = $(el);
        		var dataColumnName = obj.data('column-name');
        		var visibleInput = obj.nextAll('input[data-column-name=' + dataColumnName + ']');
        		// 表示された主キー入力値と変更前の値が異なるか
        		if (visibleInput.length != 0 && $(visibleInput).val() !== obj.val()) {
        			isChangedPrimarykey = true;
        		}         			
        		// 主キーのカラム名と値をセットにした連想配列にする
        		var primaryKeyMap = {};
        		var pkNameAry = String(obj.data('primarykey-names')).split(',');
        		var primaryKeyValue = obj.data('primarykey-values') === undefined ? '' : String(obj.data('primarykey-values'));
        		var pkValAry = primaryKeyValue.split(',');
        		for (var i = 0;i < pkNameAry.length;i++) {
        			primaryKeyMap[pkNameAry[i]] = pkValAry[i];
        		}
        		// name属性="行番号-項目シーケンス、value=入力値、primaryKeyValueMap=key:主キー名、value=主キーの値（※カンマ区切りの主キー値など存在しない前提）
        		var inputDto = {
            		primaryKeyValueMap: primaryKeyMap,
        			name: obj.attr('name'),
        			value: obj.val()
        		};
        		row['inputList'][cIdx] = inputDto;
        		row['primaryKeyValue'] = primaryKeyValue;
        		cIdx++;
    		});
    		// 主キー変更判定
    		if (isChangedPrimarykey) {
    			row['deleteSelect'] = '1';
        		rowAry.push(row);
    		}
    	});
    	$('#inputdto-ary-json').val(JSON.stringify(rowAry));
    	uploadForm.submit();
    };
    
    /**
     * 更新可否制御
     */
    this.isEnableUpload = function() {
    	if ($(Template.formId) 
    			&& $(Template.formId).find('input[type=text],input[type=number],input[type=checkbox][name=deleteSelection],textarea,input[type=radio],select').length > 0) {
    		return true;
    	}
    	return false;
    };
    
    /**
     * 更新ボタン制御
     */
    this.uploadButtonControl = function(isEnableUpload) {
    	$('#form-main-upload').prop('disabled', !isEnableUpload);
    };
    
    /**
     * 横レイアウト且つ行数可変且つゼロ件のレイアウト制御
     */
    this.noDataHorizontalLayout = function() {
    	if (Template.isHorizontal && !!$('#add-row-area') && !Template.isEnableUpload()) {
    		var padding = 16;
    		var copyAreaTdAry = $('#add-row-area tbody tr td');
    		var thAry = $('#template-table thead tr th');
    		$.each(copyAreaTdAry, function(idx, td) {
    			if ($(td).css('display') != 'none') {
    				var inputObj = $(td).find('input[type=text],input[type=number],textarea,select');
    				if (inputObj.length < 1) {
    					inputObj = $(td).find('input[type=radio]').closest('div');
    				}
    				// 列ごとの入力要素に合わせた幅補正
    				if (inputObj.length > 0) {
        				var childWidth = $(inputObj[0]).outerWidth();
        				$(thAry[idx]).css('min-width', childWidth + (padding * 2));
    				}
    			}
    		});
    	}
    };
    
});
