(function(global, namespace, factory) {
/////* DON'T CHANGE CODE BELOW THIS LINE */////////////////////////////////////////////////
    if (namespace) {
        if (!(namespace in global)) {
            global[namespace] = {};
        }
        factory.call(global[namespace], global);
    } else {
        factory.call(global, global);
    }
/////* DON'T CHANGE CODE ABOVE THIS LINE */////////////////////////////////////////////////
})(window, 'Login', function(global) {

    /**
     * ログイン OnLoad 処理
     * @global
     */
    $(function() {
    	
    	bindLogin();
    	
    	messageStyle();
    	
    	AppUtils.onlySingleByte();
    });

    /**
     * ログイン送信
     */
    var loginSubmit = function() {
    	$('#form-main').submit();
    };
    
    /**
     * ログイン前チェック
     */
    var loginValidation = function() {
    	var validated = false;
    	validated = $('#text_email').val() != '' && $('#text_password').val() != '';
    	if (validated) {
    		return validated;
    	}
    	if ($('#text_email').val() == '') {
    		AppUtils.errorMessage('IDまたはメールアドレスを入力してください。');
    	}
    	if ($('#text_password').val() == '') {
    		AppUtils.errorMessage('パスワードを入力してください。');
    	}
		return validated;
    }
    
    /**
     * ログインイベントをバインド
     */
    var bindLogin = function() {
    	$('#button-login').on('click', function() {
    		AppUtils.clearMessageArea();
        	if (loginValidation()) {
        		loginSubmit();
        	}
    	});
    	$('#text_email,#text_password').on('keypress', function(e) {
    		if (e.keyCode === 13 && $('#text_email').val() != '' && $('#text_password').val() != '') {
        		AppUtils.clearMessageArea();
        		loginSubmit();
    		}
    	});
    };

    /**
     * メッセージスタイル調整
     */
    var messageStyle = function() {
    	var errorMsgAry = $('#message-area .error li');
    	if (errorMsgAry.length > 0) {
    		// エラーメッセージ文字数によりログイン入力領域の幅を超えるかチェック
    		var loginAreaWidth = 410;
    		var fontWidth = 12.8;
    		var isExistOverWidth = false;
    		$.each(errorMsgAry, function(idx, ele) {
    			if (($(ele).text().length * fontWidth) > loginAreaWidth) {
    				isExistOverWidth = true;
    			}
    		});
    		// 超える場合は文字列先頭位置固定ではなく中央寄せに変更
    		if (isExistOverWidth) {
    			$.each(errorMsgAry, function(idx, ele) {
    				$(ele).css('padding-left', '0');
    				$(ele).css('text-align', 'center');
        		});    			
    		}
    	}
    }
    
});
