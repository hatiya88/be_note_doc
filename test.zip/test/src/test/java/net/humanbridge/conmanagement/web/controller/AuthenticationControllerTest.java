package net.humanbridge.conmanagement.web.controller;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

import com.fujitsu.portal.api.mapper.User;

import lombok.val;
import net.humanbridge.conmanagement.concierge.response.HospitalOptApiResponseDxo;
import net.humanbridge.conmanagement.external.call.HospitalOptionMasterApiCall;
import net.humanbridge.conmanagement.util.AppUtils;
import net.humanbridge.conmanagement.web.dbflute.exbhv.MConManageGeneralBhv;
import net.humanbridge.conmanagement.web.dbflute.exbhv.MUserAuthBhv;
import net.humanbridge.conmanagement.web.dto.UserSessionDto;
import net.humanbridge.conmanagement.web.dto.UserSessionDto.HospitalConfig;
import net.humanbridge.conmanagement.web.dto.UserSessionDto.MUserConfig;
import net.humanbridge.conmanagement.web.dto.analytics.DepartmentDto;
import net.humanbridge.conmanagement.web.exception.AuthenticationException;
import net.humanbridge.conmanagement.web.exception.ServiceException;
import net.humanbridge.conmanagement.web.model.LoginModel;
import net.humanbridge.conmanagement.web.service.AuthenticationService;
import net.humanbridge.conmanagement.web.service.analytics.AnalyticsOnlyService;
import net.humanbridge.conmanagement.web.service.analytics.AnalyticsService;
import net.humanbridge.conmanagement.web.service.totp.TotpService;

@RunWith(PowerMockRunner.class)
@PrepareForTest({AppUtils.class})
public class AuthenticationControllerTest {
	
	/** 利用状況確認ツールの利用許可フラグ */
	private static final String ALLOWED_DATA_ANALYTICS_KEY = "allowed_data_analytics";
	
	@InjectMocks
	private AuthenticationController sut;
	
	@Mock
	private HttpServletRequest httpRequest;
	
	@Mock
	private Model model;
	
	@Mock
	private LoginModel loginModel;
	
	@Mock
	private BindingResult bindingResult;
	
	@Mock
	private AuthenticationService authenticationService;

	@Mock
	private AnalyticsOnlyService analyticsOnlyService;

	@Mock
	private AnalyticsService analyticsService;

	@Mock
	private TotpService totpService;

	@Mock
	private MConManageGeneralBhv mConManageGeneralBhv;
	
	@Mock
	private MUserAuthBhv mUserAuthBhv;
	
	@Mock
	private MUserConfig mUserConfig;
	
	@Mock
	private HospitalOptApiResponseDxo hospitalOptApiResponse;
	
	@Mock
	private HospitalOptionMasterApiCall hospitalOptionMasterApiCall;

	@Mock
	private List<DepartmentDto> departmentList;

	@Mock
	private AppUtils appUtils;
	
	@Mock
	private HttpSession session;
	
	@Mock
	private HttpServletRequest request;
	
	@Mock
	private HttpServletResponse response;
	
	@Mock
	private UserSessionDto userSessionDto;
	
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		PowerMockito.mockStatic(AppUtils.class);
	}

	/**
	 * @see AuthenticationController#login(HttpServletRequest, Model, LoginModel, BindingResult)
	 * @throws AuthenticationException
	 * @throws ServiceException
	 * redirect先へのパスが出力されること。
	 */
	@Test
	public void testLogin() throws AuthenticationException, ServiceException, Exception {
		//Arrange
		UserSessionDto userSessionDto = new UserSessionDto();
		userSessionDto.setApiKey("apiKey");
		userSessionDto.setAccessToken("accessToken");
		userSessionDto.setLoginUser(new User());
		val contractGroupId = "GRP000000001293";
		Map<String, String> map = new HashMap<String, String>();
		map.put("test", "test");
		map.put(ALLOWED_DATA_ANALYTICS_KEY, "1");
		val hospitalConfigMap = new HospitalConfig(map, map);
		Map<String, String> mapProviderGroupId = new HashMap<String, String>();
		mapProviderGroupId.put("GRP000000001293", "test");
		val mUserConfigMap = new MUserConfig(map, map);
		val immutablePair1 = ImmutablePair.of(userSessionDto, contractGroupId);

		doReturn("email").when(this.loginModel).getEmail();
		doReturn("password").when(this.loginModel).getPassword();
		doReturn(immutablePair1).when(this.authenticationService).login(Mockito.anyString(), Mockito.anyString());
		doReturn(hospitalConfigMap).when(this.mConManageGeneralBhv).getHospitalConfig(Mockito.anyString());
		doReturn(mUserConfigMap).when(this.mUserAuthBhv).getMUserConfig(Mockito.any());
		doReturn(userSessionDto).when(this.analyticsOnlyService).getAnalyticsData(Mockito.any(), Mockito.anyString(), Mockito.any());
		doReturn(false).when(this.totpService).isActive(Mockito.any());
		PowerMockito.when(AppUtils.createNewSession(Mockito.any())).thenReturn(this.session);

		//act
		String actual = this.sut.login(httpRequest, model, loginModel, bindingResult);

		//assert
		assertThat(actual, is("redirect:/hospitals/GRP000000001293/menu"));
	}

	/**
	 * @see AuthenticationController#login(HttpServletRequest, Model, LoginModel, BindingResult)
	 * @throws AuthenticationException
	 * @throws ServiceException
	 */
	@Test
	@Ignore
	public void testLogin_exception() throws AuthenticationException, ServiceException, Exception {
		//arrange
		UserSessionDto userSessionDto = new UserSessionDto();
		userSessionDto.setApiKey("apiKey");
		userSessionDto.setAccessToken("accessToken");
		userSessionDto.setLoginUser(new User());
		val contractGroupId = "GRP000000001293";
		Map<String, String> map = new HashMap<String, String>();
		map.put("test", "test");
		val hospitalConfigMap = new HospitalConfig(map, map);
		val mUserConfigMap = new MUserConfig(map, map);
		val immutablePair1 = ImmutablePair.of(userSessionDto, contractGroupId);

		doReturn("email").when(this.loginModel).getEmail();
		doReturn("password").when(this.loginModel).getPassword();
		doReturn(immutablePair1).when(this.authenticationService).login(Mockito.anyString(), Mockito.anyString());
		doReturn(hospitalConfigMap).when(this.mConManageGeneralBhv).getHospitalConfig(Mockito.anyString());
		doReturn(mUserConfigMap).when(this.mUserAuthBhv).getMUserConfig(Mockito.any());
		doReturn(this.hospitalOptApiResponse).when(this.hospitalOptionMasterApiCall).call(Mockito.anyString());
		doThrow(new AuthenticationException()).when(this.authenticationService).getChildServiceGroupIdList(Mockito.anyString());

		//act
		String actual = this.sut.login(httpRequest, model, loginModel, bindingResult);

		//assert
		assertThat(actual, is("login/index"));
	}

	/**
	 * @see AuthenticationController#index(LoginModel)
	 */
	@Test
	public void testIndex() {
		//arrange
		
		//act
		String actual = this.sut.index(loginModel);
		
		//assert
		assertThat(actual, is("login/index"));
		
	}
	
	@Test
	public void testLogout() {
		//arrange
		
		//act
		String actual = this.sut.logout(request, response, userSessionDto);
		
		//assert
		assertThat(actual, is("redirect:/"));
	}

	@Test
	public void testIndexHtml() {
		//arrange
		
		//act
		String actual = this.sut.indexHtml();
		
		//assert
		assertThat(actual, is("login/index"));
	}

	@Test
	public void testRedirectPath() {
		//arrange
		
		//act
		String actual = this.sut.redirectPath();
		
		//assert
		assertThat(actual, is("./"));
	}
}
