package net.humanbridge.conmanagement.web.controller.mfa;

import javax.servlet.http.HttpSession;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.hamcrest.CoreMatchers.*;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.ui.Model;
import lombok.val;
import net.humanbridge.conmanagement.external.exception.TOTPApiCallException;
import net.humanbridge.conmanagement.totp.model.AuthenticationModel;
import net.humanbridge.conmanagement.web.dto.UserSessionDto;
import net.humanbridge.conmanagement.web.helper.MessageHelper;
import net.humanbridge.conmanagement.web.service.totp.TotpService;

public class MfaAuthenticationControllerTest {

	@InjectMocks
	private MfaAuthenticationController sut;

	@Mock
	private TotpService totpService;

	@Mock
	private MessageHelper messageHelper;

	@Mock
	private Model model;

	@Mock
	private HttpSession session;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * @throws Exception
	 * @see MfaAuthenticationController#index(Model, UserSessionDto, AuthenticationModel)
	 * 初期表示("mfa/index"が返ってくること)
	 */
	@Test
	public void testIndex() throws Exception {
		// Arrange
		val userSessionDto = new UserSessionDto();
		val authenticationModel = new AuthenticationModel();
		// act
		val actual = this.sut.index(model, userSessionDto, authenticationModel);
		// assert
		assertThat(actual, is("mfa/index"));
	}

	/**
	 * @throws Exception
	 * @see MfaAuthenticationController#authentication(Model, UserSessionDto, AuthenticationModel)
	 * 二要素認証が成功し、メニュー画面にリダイレクトすること
	 */
	@Test
	public void testAuthentication() throws Exception {
		// Arrange
		val userSessionDto = new UserSessionDto();
		userSessionDto.setGroupId("GRP000000001016");
		val authenticationModel = new AuthenticationModel();
		authenticationModel.setOptCode("123456");
		doNothing().when(this.totpService).authentication(Mockito.any(), Mockito.anyString());
		// act
		val actual = this.sut.authentication(model, userSessionDto, authenticationModel);
		// assert
		assertThat(actual, is("redirect:/hospitals/GRP000000001016/menu"));
	}

	/**
	 * @throws Exception
	 * @see MfaAuthenticationController#authentication(Model, UserSessionDto, AuthenticationModel)
	 * 二要素認証が失敗し、エラーメッセージを出力すること
	 */
	@Test
	public void testAuthentication_Exception() throws Exception {
		// Arrange
		val userSessionDto = new UserSessionDto();
		userSessionDto.setGroupId("GRP000000001016");
		val authenticationModel = new AuthenticationModel();
		authenticationModel.setOptCode("123456");
		doThrow(new TOTPApiCallException("CMG999_E0001")).when(this.totpService).authentication(Mockito.any(), Mockito.anyString());
		// act
		val actual = this.sut.authentication(model, userSessionDto, authenticationModel);
		// assert
		assertThat(actual, is("mfa/index"));
		verify(this.messageHelper, times(1)).setCommonErrorMessage(Mockito.any(), Mockito.anyString());
	}

	/**
	 * @throws Exception
	 * @see MfaAuthenticationController#recovery(Model, UserSessionDto, HttpSession)
	 * アクセスキーを取得し、TOTPホーム画面にリダイレクトすること
	 */
	@Test
	public void testFailure() throws Exception {
		// Arrange
		val userSessionDto = new UserSessionDto();
		doReturn("accessKey").when(this.totpService).createKey(Mockito.any(), Mockito.any());
		doReturn("transferURL").when(this.totpService).transfer(Mockito.any(), Mockito.anyString());
		// act
		val actual = this.sut.recovery(model, userSessionDto, session);
		// assert
		assertThat(actual, is("redirect:transferURL"));
	}

	/**
	 * @throws Exception
	 * @see MfaAuthenticationController#recovery(Model, UserSessionDto, HttpSession)
	 * アクセスキーを取得失敗し、エラーメッセージを出力すること
	 */
	@Test
	public void testFailure_Exception() throws Exception {
		// Arrange
		val userSessionDto = new UserSessionDto();
		doThrow(new TOTPApiCallException("CMG999_E0001")).when(this.totpService).createKey(Mockito.any(), Mockito.any());
		// act
		val actual = this.sut.recovery(model, userSessionDto, session);
		// assert
		assertThat(actual, is("mfa/index"));
		verify(this.messageHelper, times(1)).setCommonErrorMessage(Mockito.any(), Mockito.anyString());
	}

	/**
	 * @see MfaAuthenticationController#indexHtml()
	 * "mfa/index"が返ってくること
	 */
	@Test
	public void testIndexHtml() {
		//act
		val actual = this.sut.indexHtml();
		//assert
		assertThat(actual, is("mfa/index"));
	}

	/**
	 * @see MfaAuthenticationController#redirectPath()
	 * "./"が返ってくること
	 */
	@Test
	public void testRedirectPath() {
		//act
		val actual = this.sut.redirectPath();
		//assert
		assertThat(actual, is("./"));
	}
}
