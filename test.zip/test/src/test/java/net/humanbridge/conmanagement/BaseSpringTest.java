package net.humanbridge.conmanagement;

import org.junit.After;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.seasar.dbflute.AccessContext;
import org.seasar.dbflute.bhv.DeleteOption;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.fujitsu.portal.api.config.PortalApiCallConfiguration;
import com.fujitsu.portal.api.controller.AuthenticateController;

import jp.co.fjqs.f2.springboot.rest.config.F2RestConfiguration;
import jp.co.fjqs.f2.springboot.scanengine.SymantecScanConfiguration;
import net.humanbridge.conmanagement.util.AppUtils;
import net.humanbridge.conmanagement.util.SpringUtils;
import net.humanbridge.conmanagement.web.TestConfig;
import net.humanbridge.conmanagement.web.dbflute.cbean.MCategoryCB;
import net.humanbridge.conmanagement.web.dbflute.cbean.MConManageGeneralCB;
import net.humanbridge.conmanagement.web.dbflute.cbean.MItemValidationCB;
import net.humanbridge.conmanagement.web.dbflute.cbean.MSelectionCB;
import net.humanbridge.conmanagement.web.dbflute.cbean.MTemplateCB;
import net.humanbridge.conmanagement.web.dbflute.cbean.MTemplateItemCB;
import net.humanbridge.conmanagement.web.dbflute.cbean.MValidationRuleCB;
import net.humanbridge.conmanagement.web.dbflute.exbhv.MCategoryBhv;
import net.humanbridge.conmanagement.web.dbflute.exbhv.MConManageGeneralBhv;
import net.humanbridge.conmanagement.web.dbflute.exbhv.MItemValidationBhv;
import net.humanbridge.conmanagement.web.dbflute.exbhv.MSelectionBhv;
import net.humanbridge.conmanagement.web.dbflute.exbhv.MTemplateBhv;
import net.humanbridge.conmanagement.web.dbflute.exbhv.MTemplateItemBhv;
import net.humanbridge.conmanagement.web.dbflute.exbhv.MValidationRuleBhv;

/**
 * {@link SpringUtils#getBean(Class)} を利用する処理を含むテストクラスです。
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = {
	ConManagementApplication.class,
	AuthenticateController.class,
	PortalApiCallConfiguration.class,
	F2RestConfiguration.class,
	SymantecScanConfiguration.class,
	TestConfig.class })
@WebAppConfiguration
@IntegrationTest({ "server.port=0" })
@TransactionConfiguration	// テストケース実行毎に、DBをロールバックします。
@Transactional				// 個別にロールバックを解除したい場合は、@Rollback(false) をテストケースメソッドに明示的に付与してください。
public abstract class BaseSpringTest {

	@Autowired
	protected ApplicationContext ctx;

	@Value("${local.server.port}")
	protected int port;

	@Value("${server.context-path}")
	protected String contextPath;
	
	@Autowired
	private MCategoryBhv mCategoryBhv;
	
	@Autowired
	private MConManageGeneralBhv mConManageGeneralBhv;
	
	@Autowired
	private MItemValidationBhv mItemValidationBhv;
	
	@Autowired
	private MSelectionBhv mSelectionBhv;
	
	@Autowired
	private MTemplateBhv mTemplateBhv;
	
	@Autowired
	private MTemplateItemBhv mTemplateItemBhv;
	
	@Autowired
	private MValidationRuleBhv mValidationRuleBhv;

	@Before
	public void setUp() throws Exception {
		SpringUtils.jUnit = true;
		SpringUtils.setApplicationContext(ctx);
		MockitoAnnotations.initMocks(this);

		// {@see DbAccessContextInterceptor} が呼ばれていない場合、各テストケースメソッド毎に設定します
		if (!AccessContext.isExistAccessContextOnThread()) {
			AccessContext context = new AccessContext();
			context.setAccessTimestamp(AppUtils.getNowTimestamp());
			context.setAccessUser("JUnit Test User");
			AccessContext.setAccessContextOnThread(context);
		}
	}

	@After
	public void tearDown() throws Exception {
		// {@see DbAccessContextInterceptor} が呼ばれていない場合、各テストケースメソッド毎にクリアします
		if (AccessContext.isExistAccessContextOnThread()) {
			AccessContext.clearAccessContextOnThread();
		}
	}
	
	/**
	 * マスタクリア
	 */
	public void masterClear() {
		mCategoryBhv.varyingQueryDelete(new MCategoryCB(), new DeleteOption<MCategoryCB>().allowNonQueryDelete());
		mConManageGeneralBhv.varyingQueryDelete(new MConManageGeneralCB(), new DeleteOption<MConManageGeneralCB>().allowNonQueryDelete());
		mSelectionBhv.varyingQueryDelete(new MSelectionCB(), new DeleteOption<MSelectionCB>().allowNonQueryDelete());
		mItemValidationBhv.varyingQueryDelete(new MItemValidationCB(), new DeleteOption<MItemValidationCB>().allowNonQueryDelete());
		mValidationRuleBhv.varyingQueryDelete(new MValidationRuleCB(), new DeleteOption<MValidationRuleCB>().allowNonQueryDelete());
		mTemplateItemBhv.varyingQueryDelete(new MTemplateItemCB(), new DeleteOption<MTemplateItemCB>().allowNonQueryDelete());
		mTemplateBhv.varyingQueryDelete(new MTemplateCB(), new DeleteOption<MTemplateCB>().allowNonQueryDelete());
	}

}
