package net.humanbridge.conmanagement.web.service.totp;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.doReturn;
import static org.hamcrest.CoreMatchers.*;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.reflect.Whitebox;
import com.fujitsu.portal.api.mapper.User;
import lombok.val;
import net.humanbridge.conmanagement.totp.call.TotpAuthenticationAPICall;
import net.humanbridge.conmanagement.totp.call.TotpCreateAccessKeyAPICall;
import net.humanbridge.conmanagement.totp.call.TotpRevokePrivateKeyAPICall;
import net.humanbridge.conmanagement.totp.call.TotpUserStatusAPICall;
import net.humanbridge.conmanagement.totp.call.TotpViewCall;
import net.humanbridge.conmanagement.totp.mapper.TotpAuthenticationMapper;
import net.humanbridge.conmanagement.totp.mapper.TotpCreateAccessKeyMapper;
import net.humanbridge.conmanagement.totp.mapper.TotpRevokePrivateKeyMapper;
import net.humanbridge.conmanagement.totp.mapper.TotpUserStatusMapper;
import net.humanbridge.conmanagement.web.dto.UserSessionDto;
import net.humanbridge.conmanagement.web.service.totp.TotpService;

public class TotpServiceTest {

	@InjectMocks
	private TotpService sut;

	@Mock
	private TotpCreateAccessKeyAPICall totpCreateAccessKeyAPICall;

	@Mock
	private TotpAuthenticationAPICall totpAuthenticationAPICall;

	@Mock
	private TotpRevokePrivateKeyAPICall totpRevokePrivateKeyAPICall;

	@Mock
	private TotpUserStatusAPICall totpUserStatusAPICall;

	@Spy
	private TotpViewCall totpViewCall;

	@Mock
	private HttpSession session;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * テスト用ユーザセッション作成
	 */
	private UserSessionDto createTestUserSessionDto(){
		val userSessionDto = new UserSessionDto();
		val user = new User();
		user.setFamilyName("富士通");
		user.setFirstName("太郎");
		user.setUserId("userId");
		userSessionDto.setLoginUser(user);
		return userSessionDto;
	}

	/**
	 * @throws Exception
	 * @see TotpService#createKey(UserSessionDto, HttpSession)
	 * 生成したアクセスキーを返却すること
	 */
	@Test
	public void testCreateKey() throws Exception {
		// Arrange
		val userSessionDto = createTestUserSessionDto();
		val totpCreateAccessKeyMapper = new TotpCreateAccessKeyMapper();
		totpCreateAccessKeyMapper.setAccessKey("accessKey");
		val response = Pair.of(HttpServletResponse.SC_OK, totpCreateAccessKeyMapper);
		doReturn(response).when(this.totpCreateAccessKeyAPICall).call(Mockito.anyString(), Mockito.anyString());
		doReturn("state").when(this.session).getAttribute(Mockito.anyString());
		// act
		val actual = this.sut.createKey(userSessionDto, session);
		// assert
		assertThat(actual, is("accessKey"));
	}

	/**
	 * @throws Exception
	 * @see TotpService#createKey(UserSessionDto, HttpSession)
	 * アクセスキー生成時にエラーが発生する(Status:500)
	 * 
	 * メッセージが正しいこと(CMG014-E0001：サーバ処理に失敗しました。)
	 */
	@Test
	public void testCreateKey_Exception() throws Exception {
		// Arrange
		val userSessionDto = createTestUserSessionDto();
		val totpCreateAccessKeyMapper = new TotpCreateAccessKeyMapper();
		totpCreateAccessKeyMapper.setAccessKey("accessKey");
		val response = Pair.of(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, totpCreateAccessKeyMapper);
		doReturn(response).when(this.totpCreateAccessKeyAPICall).call(Mockito.anyString(), Mockito.anyString());
		doReturn("state").when(this.session).getAttribute(Mockito.anyString());
		try {
			// act
			this.sut.createKey(userSessionDto, session);
			Assert.fail();
		} catch (Exception e) {
			// assert
			val actual = e.getMessage();
			assertThat(actual, is("CMG014-E0001"));
		}
	}

	/**
	 * @throws Exception
	 * @see TotpService#authentication(UserSessionDto, String)
	 * 認証時にエラーが発生しないこと
	 */
	@Test
	public void testAuthentication() throws Exception {
		// Arrange
		val userSessionDto = createTestUserSessionDto();
		val optCode = "123456";
		val totpAuthenticationMapper = new TotpAuthenticationMapper();
		val response = Pair.of(HttpServletResponse.SC_OK, totpAuthenticationMapper);
		doReturn(response).when(this.totpAuthenticationAPICall).call(Mockito.anyString(), Mockito.anyInt());
		// act
		this.sut.authentication(userSessionDto,optCode);
	}

	/**
	 * @throws Exception 
	 * @see TotpService#authentication(UserSessionDto, String)
	 * 認証時にエラーが発生する
	 */
	private void testAuthentication_Exception(String optCode, Pair<Integer, TotpAuthenticationMapper> response,
			String message) throws Exception {
		// Arrange
		val userSessionDto = createTestUserSessionDto();
		doReturn(response).when(this.totpAuthenticationAPICall).call(Mockito.anyString(), Mockito.anyInt());
		try {
			// act
			this.sut.authentication(userSessionDto,optCode);
			Assert.fail();
		} catch (Exception e) {
			// assert
			val actual = e.getMessage();
			assertThat(actual, is(message));
		}
	}
	//認証コードが空白(CMG014-E0002:認証コードを入力してください。)
	@Test
	public void testAuthentication_Blank() throws Exception {
		val totpAuthenticationMapper = new TotpAuthenticationMapper();
		val response = Pair.of(HttpServletResponse.SC_OK, totpAuthenticationMapper);
		testAuthentication_Exception("", response, "CMG014-E0002");
	}
	//認証コードが半角英数6文字(CMG014-E0004:半角数字6桁で入力してください。)
	@Test
	public void testAuthentication_Half_Alphanumeric() throws Exception {
		val totpAuthenticationMapper = new TotpAuthenticationMapper();
		val response = Pair.of(HttpServletResponse.SC_OK, totpAuthenticationMapper);
		testAuthentication_Exception("1234ab", response, "CMG014-E0004");
	}
	//認証コードが全角英数6文字(CMG014-E0004:半角数字6桁で入力してください。)
	@Test
	public void testAuthentication_Alphanumeric() throws Exception {
		val totpAuthenticationMapper = new TotpAuthenticationMapper();
		val response = Pair.of(HttpServletResponse.SC_OK, totpAuthenticationMapper);
		testAuthentication_Exception("1234ｂｃ", response, "CMG014-E0004");
	}
	//認証コードに半角記号が含まれる(CMG014-E0004:半角数字6桁で入力してください。)
	@Test
	public void testAuthentication_Half_Symbol() throws Exception {
		val totpAuthenticationMapper = new TotpAuthenticationMapper();
		val response = Pair.of(HttpServletResponse.SC_OK, totpAuthenticationMapper);
		testAuthentication_Exception("1234!?", response, "CMG014-E0004");
	}
	//認証コードに全角記号が含まれる(CMG014-E0004:半角数字6桁で入力してください。)
	@Test
	public void testAuthentication_Symbol() throws Exception {
		val totpAuthenticationMapper = new TotpAuthenticationMapper();
		val response = Pair.of(HttpServletResponse.SC_OK, totpAuthenticationMapper);
		testAuthentication_Exception("1234！？", response, "CMG014-E0004");
	}
	//認証コードに半角スペースが含まれる(CMG014-E0004:半角数字6桁で入力してください。)
	@Test
	public void testAuthentication_Half_Space() throws Exception {
		val totpAuthenticationMapper = new TotpAuthenticationMapper();
		val response = Pair.of(HttpServletResponse.SC_OK, totpAuthenticationMapper);
		testAuthentication_Exception("1234 6", response, "CMG014-E0004");
	}
	//認証コードに全角スペースが含まれる(CMG014-E0004:半角数字6桁で入力してください。)
	@Test
	public void testAuthentication_Space() throws Exception {
		val totpAuthenticationMapper = new TotpAuthenticationMapper();
		val response = Pair.of(HttpServletResponse.SC_OK, totpAuthenticationMapper);
		testAuthentication_Exception("1234　6", response, "CMG014-E0004");
	}
	//認証コードに全角数字が含まれる(CMG014-E0004:半角数字6桁で入力してください。)
	@Test
	public void testAuthentication_Zenkaku() throws Exception {
		val totpAuthenticationMapper = new TotpAuthenticationMapper();
		val response = Pair.of(HttpServletResponse.SC_OK, totpAuthenticationMapper);
		testAuthentication_Exception("1234５6", response, "CMG014-E0004");
	}
	//認証コードが半角数字5文字(CMG014-E0004:半角数字6桁で入力してください。)
	@Test
	public void testAuthentication_Shortage() throws Exception {
		val totpAuthenticationMapper = new TotpAuthenticationMapper();
		val response = Pair.of(HttpServletResponse.SC_OK, totpAuthenticationMapper);
		testAuthentication_Exception("12345", response, "CMG014-E0004");
	}
	//認証コードが半角数字7文字(CMG014-E0004:半角数字6桁で入力してください。)
	@Test
	public void testAuthentication_Excess() throws Exception {
		val totpAuthenticationMapper = new TotpAuthenticationMapper();
		val response = Pair.of(HttpServletResponse.SC_OK, totpAuthenticationMapper);
		testAuthentication_Exception("1234567", response, "CMG014-E0004");
	}
	//TOTPからのレスポンスが(Status:500)(CMG014-E0001:サーバ処理に失敗しました。)
	@Test
	public void testAuthentication_500() throws Exception {
		val totpAuthenticationMapper = new TotpAuthenticationMapper();
		val response = Pair.of(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, totpAuthenticationMapper);
		testAuthentication_Exception("123456", response, "CMG014-E0001");
	}
	//TOTPからのレスポンスが(Status:400, messageId:WA02001)(CMG014-E0001:サーバ処理に失敗しました。)
	@Test
	public void testAuthentication_400_001() throws Exception {
		val totpAuthenticationMapper = new TotpAuthenticationMapper();
		totpAuthenticationMapper.setErrorCode("WA02001");
		val response = Pair.of(HttpServletResponse.SC_BAD_REQUEST, totpAuthenticationMapper);
		testAuthentication_Exception("123456", response, "CMG014-E0001");
	}
	//TOTPからのレスポンスが(Status:400, messageId:WA02006)(CMG014-E0001:サーバ処理に失敗しました。)
	@Test
	public void testAuthentication_400_006() throws Exception {
		val totpAuthenticationMapper = new TotpAuthenticationMapper();
		totpAuthenticationMapper.setErrorCode("WA02006");
		val response = Pair.of(HttpServletResponse.SC_BAD_REQUEST, totpAuthenticationMapper);
		testAuthentication_Exception("123456", response, "CMG014-E0001");
	}
	//TOTPからのレスポンスが(Status:400, messageId:WA02007)(CMG014-E0002:認証コードを入力してください。)
	@Test
	public void testAuthentication_400_007() throws Exception {
		val totpAuthenticationMapper = new TotpAuthenticationMapper();
		totpAuthenticationMapper.setErrorCode("WA02007");
		val response = Pair.of(HttpServletResponse.SC_BAD_REQUEST, totpAuthenticationMapper);
		testAuthentication_Exception("123456", response, "CMG014-E0002");
	}
	//TOTPからのレスポンスが(Status:400, messageId:WA02008)(CMG014-E0003:認証コードに誤りがあります。)
	@Test
	public void testAuthentication_400_008() throws Exception {
		val totpAuthenticationMapper = new TotpAuthenticationMapper();
		totpAuthenticationMapper.setErrorCode("WA02008");
		val response = Pair.of(HttpServletResponse.SC_BAD_REQUEST, totpAuthenticationMapper);
		testAuthentication_Exception("123456", response, "CMG014-E0003");
	}
	//TOTPからのレスポンスが(Status:404)(CMG999_E0001:予期せぬエラーが発生しました。)
	@Test
	public void testAuthentication_404() throws Exception {
		val totpAuthenticationMapper = new TotpAuthenticationMapper();
		val response = Pair.of(HttpServletResponse.SC_NOT_FOUND, totpAuthenticationMapper);
		testAuthentication_Exception("123456", response, "CMG999_E0001");
	}
	//TOTPからのレスポンスが(Status:403)(CMG999_E0001:予期せぬエラーが発生しました。)
	@Test
	public void testAuthentication_403() throws Exception {
		val totpAuthenticationMapper = new TotpAuthenticationMapper();
		val response = Pair.of(HttpServletResponse.SC_FORBIDDEN, totpAuthenticationMapper);
		testAuthentication_Exception("123456", response, "CMG999_E0001");
	}
	//TOTPからのレスポンスが(Status:401)(CMG014-E0003:認証コードに誤りがあります。)
	@Test
	public void testAuthentication_401() throws Exception {
		val totpAuthenticationMapper = new TotpAuthenticationMapper();
		val response = Pair.of(HttpServletResponse.SC_UNAUTHORIZED, totpAuthenticationMapper);
		testAuthentication_Exception("123456", response, "CMG014-E0003");
	}

	/**
	 * @throws Exception
	 * @see TotpService#revokeKey(UserSessionDto)
	 * 秘密鍵の無効化時にエラーが発生しないこと
	 */
	@Test
	public void testRevokeKey() throws Exception {
		// Arrange
		val userSessionDto = createTestUserSessionDto();
		val totpRevokePrivateKeyMapper = new TotpRevokePrivateKeyMapper();
		totpRevokePrivateKeyMapper.setUserId("userId");
		val response = Pair.of(HttpServletResponse.SC_OK, totpRevokePrivateKeyMapper);
		doReturn(response).when(this.totpRevokePrivateKeyAPICall).call(Mockito.anyString());
		// act
		this.sut.revokeKey(userSessionDto);
	}

	/**
	 * @throws Exception
	 * @see TotpService#revokeKey(UserSessionDto)
	 * 秘密鍵の無効化時にエラーが発生する(Status:500)
	 * 
	 * メッセージが正しいこと(CMG014-E0001：サーバ処理に失敗しました。)
	 */
	@Test
	public void testRevokeKey_Exception() throws Exception {
		// Arrange
		val userSessionDto = createTestUserSessionDto();
		val totpRevokePrivateKeyMapper = new TotpRevokePrivateKeyMapper();
		totpRevokePrivateKeyMapper.setUserId("userId");
		val response = Pair.of(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, totpRevokePrivateKeyMapper);
		doReturn(response).when(this.totpRevokePrivateKeyAPICall).call(Mockito.anyString());
		try {
			// act
			this.sut.revokeKey(userSessionDto);
			Assert.fail();
		} catch (Exception e) {
			// assert
			val actual = e.getMessage();
			assertThat(actual, is("CMG014-E0001"));
		}
	}

	/**
	 * @throws Exception
	 * @see TotpService#revokeKey(UserSessionDto)
	 * 秘密鍵の登録状況(true)を返却すること(Status:200, active(秘密鍵が利用可能))
	 */
	@Test
	public void testIsActive_True() throws Exception {
		// Arrange
		val userSessionDto = createTestUserSessionDto();
		val totpUserStatusMapper = new TotpUserStatusMapper();
		totpUserStatusMapper.setStatus("active");
		val response = Pair.of(HttpServletResponse.SC_OK, totpUserStatusMapper);
		doReturn(response).when(this.totpUserStatusAPICall).call(Mockito.anyString());
		// act
		val actual = this.sut.isActive(userSessionDto);
		// assert
		assertThat(actual, is(true));
	}

	/**
	 * @throws Exception
	 * @see TotpService#revokeKey(UserSessionDto)
	 * 秘密鍵の登録状況(false)を返却すること(Status:404, notregistered(秘密鍵が未生成))
	 */
	@Test
	public void testIsActive_False() throws Exception {
		// Arrange
		val userSessionDto = createTestUserSessionDto();
		val totpUserStatusMapper = new TotpUserStatusMapper();
		totpUserStatusMapper.setStatus("notregistered");
		val response = Pair.of(HttpServletResponse.SC_NOT_FOUND, totpUserStatusMapper);
		doReturn(response).when(this.totpUserStatusAPICall).call(Mockito.anyString());
		// act
		val actual = this.sut.isActive(userSessionDto);
		// assert
		assertThat(actual, is(false));
	}

	/**
	 * @throws Exception
	 * @see TotpService#revokeKey(UserSessionDto)
	 * 秘密鍵の登録状況取得時にエラーが発生する(Status:404, inactive(秘密鍵が利用不可))
	 * 
	 * メッセージが正しいこと(CMG014-E0001：サーバ処理に失敗しました。)
	 */
	@Test
	public void testIsActive_Inactive_Exception() throws Exception {
		// Arrange
		val userSessionDto = createTestUserSessionDto();
		val totpUserStatusMapper = new TotpUserStatusMapper();
		totpUserStatusMapper.setStatus("inactive");
		val response = Pair.of(HttpServletResponse.SC_NOT_FOUND, totpUserStatusMapper);
		doReturn(response).when(this.totpUserStatusAPICall).call(Mockito.anyString());
		try {
			// act
			this.sut.isActive(userSessionDto);
			Assert.fail();
		} catch (Exception e) {
			// assert
			val actual = e.getMessage();
			assertThat(actual, is("CMG014-E0001"));
		}
	}

	/**
	 * @throws Exception
	 * @see TotpService#revokeKey(UserSessionDto)
	 * 秘密鍵の登録状況取得時にエラーが発生する(Status:500)
	 * 
	 * メッセージが正しいこと(CMG014-E0001：サーバ処理に失敗しました。)
	 */
	@Test
	public void testIsActive_Exception() throws Exception {
		// Arrange
		val userSessionDto = createTestUserSessionDto();
		val totpUserStatusMapper = new TotpUserStatusMapper();
		totpUserStatusMapper.setStatus("active");
		val response = Pair.of(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, totpUserStatusMapper);
		doReturn(response).when(this.totpUserStatusAPICall).call(Mockito.anyString());
		try {
			// act
			this.sut.isActive(userSessionDto);
			Assert.fail();
		} catch (Exception e) {
			// assert
			val actual = e.getMessage();
			assertThat(actual, is("CMG014-E0001"));
		}
	}

	/**
	 * @throws Exception
	 * @see TotpService#transfer(UserSessionDto, String)
	 * 二要素認証ホーム画面のURLを返却すること
	 * (TOTPサーバホスト、TOTPサーバポート、TOTPホーム画面パス（OTP-G01） はnull)
	 */
	@Test
	public void testTransfer() throws Exception {
		// Arrange
		val userSessionDto = createTestUserSessionDto();
		val accessKey = "accessKey";
		PowerMockito.whenNew(TotpViewCall.class).withNoArguments().thenReturn(totpViewCall);
		Whitebox.setInternalState(totpViewCall, "startupPath", "totp/startup");
		Whitebox.setInternalState(totpViewCall, "clientId", "clientId");
		Whitebox.setInternalState(totpViewCall, "httpHost", "localhost");
		Whitebox.setInternalState(totpViewCall, "httpPort", 8081);
		// act
		val actual = this.sut.transfer(userSessionDto, accessKey);
		// assert
		assertThat(actual,is("http://localhost:8081/totp/startup?access_key=accessKey&client_id=clientId&key=eyJ1c2VyX2lkIjoidXNlcklkIiwiZGlzcF9uYW1lIjoi5a%2BM5aOr6YCaIOWkqumDjiJ9"));
	}
}