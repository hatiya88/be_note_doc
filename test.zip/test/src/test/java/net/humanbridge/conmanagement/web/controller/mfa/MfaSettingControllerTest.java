package net.humanbridge.conmanagement.web.controller.mfa;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.hamcrest.CoreMatchers.*;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.ui.Model;
import lombok.val;
import net.humanbridge.conmanagement.external.exception.TOTPApiCallException;
import net.humanbridge.conmanagement.web.controller.MenuController;
import net.humanbridge.conmanagement.web.dto.UserSessionDto;
import net.humanbridge.conmanagement.web.helper.MessageHelper;
import net.humanbridge.conmanagement.web.model.ServiceModel;
import net.humanbridge.conmanagement.web.service.totp.TotpService;

public class MfaSettingControllerTest {

	@InjectMocks
	private MfaSettingController sut;

	@Mock
	private TotpService totpService;

	@Mock
	private MessageHelper messageHelper;

	@Mock
	private Model model;

	@Mock
	ServiceModel serviceModel;

	@Mock
	private HttpSession session;

	@Mock
	HttpServletRequest request;

	@Mock
	private MenuController menuController;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * @throws Exception
	 * @see MfaSettingController#index(Model, net.humanbridge.conmanagement.web.model.ServiceModel, String, UserSessionDto)
	 * 秘密鍵登録状況の取得に成功し(trueが返ってくる)、二要素認証設定画面へ遷移すること
	 */
	@Test
	public void testIndex_True() throws Exception {
		// Arrange
		val contractGroupId = "GRP000000001016";
		val userSessionDto = new UserSessionDto();
		doReturn(true).when(this.totpService).isActive(Mockito.any());
		// act
		val actual = this.sut.index(model, serviceModel, contractGroupId, userSessionDto);
		// assert
		assertThat(actual, is("mfa_setting/index"));
	}

	/**
	 * @throws Exception
	 * @see MfaSettingController#index(Model, net.humanbridge.conmanagement.web.model.ServiceModel, String, UserSessionDto)
	 * 秘密鍵登録状況の取得に成功し(falseが返ってくる)、二要素認証設定画面へ遷移すること
	 */
	@Test
	public void testIndex_False() throws Exception {
		// Arrange
		val contractGroupId = "GRP000000001016";
		val userSessionDto = new UserSessionDto();
		doReturn(false).when(this.totpService).isActive(Mockito.any());
		// act
		val actual = this.sut.index(model, serviceModel, contractGroupId, userSessionDto);
		// assert
		assertThat(actual, is("mfa_setting/index"));
	}

	/**
	 * @throws Exception
	 * @see MfaSettingController#index(Model, net.humanbridge.conmanagement.web.model.ServiceModel, String, UserSessionDto)
	 * 秘密鍵登録状況の取得に失敗した時にエラーメッセージを出力し、メニュー画面へリダイレクトすること
	 */
	@Test
	public void testIndex_Exception() throws Exception {
		// Arrange
		val contractGroupId = "GRP000000001016";
		val userSessionDto = new UserSessionDto();
		doThrow(new TOTPApiCallException("CMG999_E0001")).when(this.totpService).isActive(Mockito.any());
		// act
		this.sut.index(model, serviceModel, contractGroupId, userSessionDto);
		// assert
		verify(this.messageHelper, times(1)).setCommonErrorMessage(Mockito.any(), Mockito.anyString());
		verify(this.menuController, times(1)).index(Mockito.any(), Mockito.any(), Mockito.anyString(), Mockito.any());
	}

	/**
	 * @throws Exception
	 * @see MfaSettingController#redraw(Model, UserSessionDto)
	 * 
	 * privateメソッドの異常処理テスト（正常処理は次のテストで通るため割愛）
	 * 秘密鍵登録状況の取得に失敗した時にエラーメッセージを出力し、二要素認証設定画面を再描画すること
	 */
	@Test
	public void redraw_Exception() throws Exception {
		// Arrange
		val userSessionDto = new UserSessionDto();
		doReturn("invalid").when(this.request).getParameter(Mockito.anyString());
		doNothing().when(this.totpService).revokeKey(Mockito.any());

		doThrow(new TOTPApiCallException("CMG999_E0001")).when(this.totpService).isActive(Mockito.any());

		// act
		val actual = this.sut.update(model, userSessionDto, session, request);
		// assert
		assertThat(actual, is("mfa_setting/index"));
		verify(this.messageHelper, times(1)).setGuidance(Mockito.any(), Mockito.anyString());
		verify(this.messageHelper, times(1)).setCommonErrorMessage(Mockito.any(), Mockito.anyString());
	}

	/**
	 * @throws Exception
	 * @see MfaSettingController#update(Model, UserSessionDto, HttpSession, javax.servlet.http.HttpServletRequest)
	 * 二要素認証：無効 → 有効
	 * 
	 * アクセスキーを取得し、TOTPホーム画面にリダイレクトすること
	 */
	@Test
	public void testUpdate_Valid() throws Exception {
		// Arrange
		val userSessionDto = new UserSessionDto();
		doReturn("valid").when(this.request).getParameter(Mockito.anyString());
		doReturn("accessKey").when(this.totpService).createKey(Mockito.any(), Mockito.any());
		doReturn("transferURL").when(this.totpService).transfer(Mockito.any(), Mockito.anyString());
		// act
		val actual = this.sut.update(model, userSessionDto, session, request);
		// assert
		assertThat(actual, is("redirect:transferURL"));
	}

	/**
	 * @throws Exception
	 * @see MfaSettingController#update(Model, UserSessionDto, HttpSession, javax.servlet.http.HttpServletRequest)
	 * 二要素認証：無効 → 有効
	 * 
	 * アクセスキーを取得失敗し、エラーメッセージを出力すること
	 */
	@Test
	public void testUpdate_Valid_Exception() throws Exception {
		// Arrange
		val userSessionDto = new UserSessionDto();
		doReturn("valid").when(this.request).getParameter(Mockito.anyString());
		doThrow(new TOTPApiCallException("CMG999_E0001")).when(this.totpService).createKey(Mockito.any(), Mockito.any());

		doReturn(true).when(this.totpService).isActive(Mockito.any());

		// act
		val actual = this.sut.update(model, userSessionDto, session, request);
		// assert
		verify(this.messageHelper, times(1)).setCommonErrorMessage(Mockito.any(), Mockito.anyString());
		assertThat(actual, is("mfa_setting/index"));
	}

	/**
	 * @throws Exception
	 * @see MfaSettingController#update(Model, UserSessionDto, HttpSession, javax.servlet.http.HttpServletRequest)
	 * 二要素認証：有効 → 無効
	 * 
	 * 秘密鍵を無効化し、更新成功メッセージを出力すること
	 */
	@Test
	public void testUpdate_Invalid() throws Exception {
		// Arrange
		val userSessionDto = new UserSessionDto();
		doReturn("invalid").when(this.request).getParameter(Mockito.anyString());
		doNothing().when(this.totpService).revokeKey(Mockito.any());

		doReturn(true).when(this.totpService).isActive(Mockito.any());

		// act
		val actual = this.sut.update(model, userSessionDto, session, request);
		// assert
		verify(this.messageHelper, times(1)).setGuidance(Mockito.any(), Mockito.anyString());
		assertThat(actual, is("mfa_setting/index"));
	}

	/**
	 * @throws Exception
	 * @see MfaSettingController#update(Model, UserSessionDto, HttpSession, javax.servlet.http.HttpServletRequest)
	 * 二要素認証：有効 → 無効
	 * 
	 * 秘密鍵を無効化し、更新成功メッセージを出力すること
	 */
	@Test
	public void testUpdate_Invalid_Exception() throws Exception {
		// Arrange
		val userSessionDto = new UserSessionDto();
		doReturn("invalid").when(this.request).getParameter(Mockito.anyString());
		doThrow(new TOTPApiCallException("CMG999_E0001")).when(this.totpService).revokeKey(Mockito.any());

		doReturn(true).when(this.totpService).isActive(Mockito.any());

		// act
		val actual = this.sut.update(model, userSessionDto, session, request);
		// assert
		verify(this.messageHelper, times(1)).setCommonErrorMessage(Mockito.any(), Mockito.anyString());
		assertThat(actual, is("mfa_setting/index"));
	}

	/**
	 * @see MfaSettingController#indexHtml()
	 * "mfa_setting/index"が返ってくること。
	 */
	@Test
	public void testIndexHtml() {
		//act
		val actual = this.sut.indexHtml();
		//assert
		assertThat(actual, is("mfa_setting/index"));
	}

	/**
	 * @see MfaSettingController#redirectPath()
	 * "./"が返ってくること。
	 */
	@Test
	public void testRedirectPath() {
		//act
		val actual = this.sut.redirectPath();
		//assert
		assertThat(actual, is("./"));
	}
}