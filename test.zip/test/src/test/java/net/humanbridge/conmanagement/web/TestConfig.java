package net.humanbridge.conmanagement.web;

import jp.co.fjqs.f2.springboot.util.F2SpringContainerAccessor;
import jp.co.fjqs.f2.springboot.web.log.F2TraceInterceptor;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * テスト用のConfigクラスです。<br>
 * テストに必要なコンポーネントを設定します。
 *
 * @author Shinya Ishii
 *
 */
@Configuration
public class TestConfig {

	@Bean
	public F2TraceInterceptor f2raceInterceptor() {
		return new F2TraceInterceptor();
	}

	@Bean
	public F2SpringContainerAccessor f2SpringContainerAccessor() {
		return new F2SpringContainerAccessor();
	}

}
